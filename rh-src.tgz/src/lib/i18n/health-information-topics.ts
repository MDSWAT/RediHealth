import type { ComponentType, SVGProps } from "react";
import type { Lang } from "@/lib/i18n/translations";
import { translations } from "@/lib/i18n/translations";
import {
  ActivityIcon,
  AppleIcon,
  BrainIcon,
  DropletIcon,
  HeartIcon,
  NoSmokingIcon,
  SearchIcon,
  ShieldIcon,
} from "@/components/ui/icons";

export type HealthTopicContent = {
  slug: string;
  title: string;
  description: string;
  intro: string;
  keyFacts: string[];
  recommendations: { title: string; description: string }[];
  warningSigns: string[];
};

type HealthTopicDictionary = {
  labels: {
    allTopics: string;
    whyItMatters: string;
    practicalSteps: string;
    seekAdviceTitle: string;
    seekAdviceBody: string;
    relatedTopics: string;
    readMore: string;
    disclaimer: string;
  };
  topics: HealthTopicContent[];
};

const dictionaries: Record<Lang, HealthTopicDictionary> = {
  ru: {
    labels: {
      allTopics:
        "Все темы о здоровье",
      whyItMatters:
        "Почему это важно",
      practicalSteps:
        "Что вы можете сделать",
      seekAdviceTitle:
        "Когда обратиться к врачу",
      seekAdviceBody:
        "Обратитесь к врачу, если заметили любой из этих признаков. В экстренной ситуации сразу звоните 112.",
      relatedTopics:
        "Другие руководства",
      readMore:
        "Подробнее",
      disclaimer:
        "Эта информация не является диагнозом. Поговорите с врачом о своем здоровье.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Здоровье сердца",
        description:
          "Простые привычки для здоровья сердца и нормального давления.",
        intro:
          "Сердце качает кровь по всему телу каждую минуту. Забота о нем снижает риск болезней сердца и инсульта. Помогают даже небольшие привычки.",
        keyFacts: [
          "Высокое давление и холестерин годами незаметно перегружают сосуды и заставляют сердце работать с лишней нагрузкой — без всяких симптомов.",
          "Здоровое сердце и нормальное давление дают больше сил, легкое дыхание и снижают риск инсульта.",
          "Меньше соли в еде, быстрая ходьба почти каждый день и регулярное измерение давления защищают сердце.",
        ],
        recommendations: [
          {
            title: "Двигайтесь почти каждый день",
            description:
              "Ходите в быстром темпе или выберите любое занятие по душе. Короткие прогулки тоже идут на пользу.",
          },
          {
            title: "Питайтесь с пользой для сердца",
            description:
              "Ешьте больше овощей, фруктов и цельнозерновых продуктов. Добавляйте меньше соли и реже берите готовые блюда.",
          },
          {
            title: "Следите за показателями",
            description:
              "Регулярно проверяйте давление и холестерин. На ранней стадии проблемы лечатся проще.",
          },
        ],
        warningSigns: [
          "Боль, давление или сжатие в груди, особенно если они отдают в руку, шею или челюсть.",
          "Внезапная одышка, учащенное или неровное сердцебиение.",
          "Постоянная усталость, которая не проходит, или отеки на ногах.",
        ],
      },
      {
        slug: "diabetes",
        title: "Диабет",
        description:
          "От чего растет риск и как держать сахар в крови в норме.",
        intro:
          "Диабет меняет то, как организм усваивает сахар из крови. Диабет 2 типа часто связан с повседневными привычками. Его нередко можно отсрочить или предотвратить, а при правильной помощи — спокойно с ним жить.",
        keyFacts: [
          "При диабете 2 типа сахар остается в крови, а не попадает в клетки, и может годами незаметно повреждать кровеносные сосуды.",
          "Стабильный уровень сахара в крови дает ровную энергию на весь день и защищает глаза, почки, нервы и сердце.",
          "Простые ежедневные привычки — например, половина тарелки овощей и прогулка после еды — снижают риск.",
        ],
        recommendations: [
          {
            title: "Сбалансируйте тарелку",
            description:
              "Наполните половину тарелки овощами. Выбирайте цельнозерновой хлеб, рис и макароны.",
          },
          {
            title: "Больше двигайтесь",
            description:
              "Регулярное движение помогает организму лучше усваивать сахар из крови.",
          },
          {
            title: "Сдайте анализ",
            description:
              "Если у близких есть диабет или у вас есть факторы риска, попросите врача назначить простой анализ крови.",
          },
        ],
        warningSigns: [
          "Сильная жажда или частое мочеиспускание, чаще обычного.",
          "Потеря веса без причины или постоянная усталость.",
          "Затуманенное зрение или порезы, которые медленно заживают.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Здоровое питание",
        description:
          "Простая и доступная еда на каждый день.",
        intro:
          "Здоровое питание не обязано быть сложным или дорогим. Несколько простых правил на каждый день дадут организму все необходимое.",
        keyFacts: [
          "Клетчатка из овощей и цельнозерновых продуктов помогает держать сахар в крови и давление в норме.",
          "Простая домашняя еда дает ровную энергию в течение дня и избавляет от сонливости после еды.",
          "Сезонные овощи, фасоль и чечевица стоят недорого, а вода вместо сладких напитков сразу приносит пользу.",
        ],
        recommendations: [
          {
            title: "Больше овощей и фруктов",
            description:
              "Добавляйте овощи или фрукты почти к каждому приему пищи. Подойдут и свежие, и замороженные.",
          },
          {
            title: "Готовьте дома",
            description:
              "По возможности выбирайте цельнозерновые продукты и домашнюю еду вместо готовых полуфабрикатов.",
          },
          {
            title: "Пейте воду",
            description:
              "Пусть вода будет вашим главным напитком. Сладкие напитки и соки лучше ограничить.",
          },
        ],
        warningSigns: [
          "Быстрая потеря или набор веса без видимой причины.",
          "Проблемы с желудком, которые не проходят, или потеря аппетита.",
          "Сильная слабость, головокружение или усталость, даже если вы нормально едите.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Физическая активность",
        description:
          "Простые способы двигаться больше при любой подготовке.",
        intro:
          "Больше двигаться — одно из лучших решений для тела и настроения. Спортзал не нужен. Важно любое движение каждый день.",
        keyFacts: [
          "Движение улучшает кровообращение, укрепляет сердце и мышцы и помогает клеткам использовать сахар из крови для энергии.",
          "Регулярное движение дает больше сил, крепкий сон, лучшее равновесие и подвижность.",
          "Спортзал не нужен: вставайте со стула каждый час и гуляйте по 15–30 минут почти каждый день.",
        ],
        recommendations: [
          {
            title: "Начните с малого",
            description:
              "Начните с коротких прогулок или любого занятия по душе. Каждую неделю добавляйте понемногу.",
          },
          {
            title: "Двигайтесь почти каждый день",
            description:
              "Небольшая активность почти каждый день полезнее, чем редкая тяжелая тренировка.",
          },
          {
            title: "Укрепляйте мышцы",
            description:
              "Давайте нагрузку мышцам: носите сумки из магазина, работайте в саду или делайте приседания.",
          },
        ],
        warningSigns: [
          "Боль в груди, головокружение или сильная одышка при нагрузке.",
          "Боль в суставах или отек, которые усиливаются при движении.",
          "Предобморочное состояние или перебои в сердцебиении при движении.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Психическое здоровье",
        description:
          "Как беречь душевное равновесие и когда просить о помощи.",
        intro:
          "Психическое здоровье — важная часть общего здоровья. У каждого бывают хорошие и трудные периоды. Просить о помощи, когда тяжело, — нормально.",
        keyFacts: [
          "Затяжной стресс держит организм в напряжении, напрягает мышцы, учащает пульс и портит сон.",
          "Забота о душевном состоянии помогает лучше спать, легче сосредоточиться днем и сохранять тепло в общении с близкими.",
          "Медленное глубокое дыхание, регулярный сон и откровенный разговор с близким человеком быстро снимают напряжение.",
        ],
        recommendations: [
          {
            title: "Общайтесь с близкими",
            description:
              "Проводите время с людьми, которым доверяете. Поддержка близких бережет психику.",
          },
          {
            title: "Берегите режим дня",
            description:
              "Сон, движение и время на свежем воздухе помогают вам чувствовать себя лучше.",
          },
          {
            title: "Просите о помощи",
            description:
              "Если становится слишком тяжело, поговорите с близким человеком или с врачом.",
          },
        ],
        warningSigns: [
          "Чувство подавленности, беспокойства или безнадежности в течение нескольких недель.",
          "Становится трудно справляться с повседневными делами, работой или общением.",
          "Мысли о том, чтобы причинить себе вред. Если они появились, немедленно обратитесь за помощью.",
        ],
      },
      {
        slug: "smoking",
        title: "Отказ от курения",
        description:
          "Зачем бросать курить и что помогает справиться.",
        intro:
          "Отказ от курения — лучшее, что вы можете сделать для своего здоровья. Организм начинает восстанавливаться очень быстро. Многие пробуют несколько раз, прежде чем бросить окончательно.",
        keyFacts: [
          "Уже через несколько часов после последней сигареты уровень кислорода растет, сосуды расслабляются, а легкие начинают очищаться.",
          "По мере восстановления легких и сосудов вам легче подниматься по лестнице, уменьшается кашель, возвращаются вкус и обоняние.",
          "Если выбрать дату отказа, переждать трехминутный порыв закурить и попросить поддержки у врача, шансы бросить удваиваются.",
        ],
        recommendations: [
          {
            title: "Выберите день отказа",
            description:
              "Наметьте день и скажите об этом близким. Заранее решите, чем займетесь, когда потянет закурить.",
          },
          {
            title: "Обратитесь за помощью",
            description:
              "Программы помощи и одобренные средства от курения повышают шансы бросить насовсем.",
          },
          {
            title: "Не сдавайтесь",
            description:
              "Если сорвались и закурили снова — не опускайте руки. Сделайте вывод и попробуйте еще раз.",
          },
        ],
        warningSigns: [
          "Кашель, который не проходит, или изменение привычного долгого кашля.",
          "Кашель с кровью или боль в груди, которая не проходит.",
          "Нарастающая одышка при обычных повседневных делах.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Проверка здоровья",
        description:
          "Анализы и осмотры, которые находят болезнь раньше симптомов.",
        intro:
          "Профилактическая проверка ищет первые признаки болезни еще до того, как вы почувствуете недомогание. Ранние проблемы лечить намного проще.",
        keyFacts: [
          "Многие болезни — высокое давление, диабет или ранние стадии рака — долго развиваются незаметно, пока ничего не болит.",
          "Даже если вы каждый день чувствуете себя хорошо, плановый осмотр дает спокойствие и выявляет изменения, пока лечение простое.",
          "Узнайте у семейного врача, какие бесплатные осмотры и обследования по возрасту вы можете пройти в этом году.",
        ],
        recommendations: [
          {
            title: "Узнайте, что вам подходит",
            description:
              "Спросите врача, какие обследования подходят для вашего возраста и состояния здоровья.",
          },
          {
            title: "Проходите плановые осмотры",
            description:
              "Приходите по приглашениям на обследование и не пропускайте регулярные осмотры.",
          },
          {
            title: "Расскажите о болезнях в семье",
            description:
              "Сообщите врачу, какими болезнями болели ваши близкие. Это поможет выбрать нужные анализы.",
          },
        ],
        warningSigns: [
          "Новое уплотнение, необычное кровотечение или родинка, которая меняет форму или цвет.",
          "Любой новый симптом, который не проходит без понятной причины.",
          "Результат анализа, после которого просят прийти повторно. Не откладывайте.",
        ],
      },
      {
        slug: "womens-health",
        title: "Женское здоровье",
        description:
          "Здоровье женщины в любом возрасте — от цикла до менопаузы.",
        intro:
          "Задачи женского здоровья меняются с возрастом: от месячных и беременности до менопаузы и позже. Когда вы знаете, что для вас норма, легче сразу заметить перемены.",
        keyFacts: [
          "Организм женщины проходит естественные гормональные этапы от месячных и беременности до менопаузы — это влияет на кости, сердце и настроение.",
          "Знание особенностей своего тела помогает вовремя заметить изменения в груди, необычные кровотечения или тянущую боль внизу живота.",
          "Регулярный мазок шейки матки, ежемесячный самоосмотр груди и плановые осмотры при беременности выявляют проблемы рано, когда их легче лечить.",
        ],
        recommendations: [
          {
            title: "Знайте, что для вас норма",
            description:
              "Наблюдайте за своим обычным циклом и самочувствием, чтобы сразу замечать перемены.",
          },
          {
            title: "Проходите регулярные осмотры",
            description:
              "Приходите на осмотры и обследования, рекомендованные для вашего возраста.",
          },
          {
            title: "Обращайтесь к врачу вовремя",
            description:
              "Поговорите с врачом о любом симптоме, который вас беспокоит.",
          },
        ],
        warningSigns: [
          "Необычные кровотечения между менструациями или после менопаузы.",
          "Сильная или продолжительная боль в нижней части живота или таза.",
          "Новые изменения в груди: уплотнение, втяжение или изменение кожи.",
        ],
      },
    ],
  },

  en: {
    labels: {
      allTopics:
        "All health topics",
      whyItMatters:
        "Why it matters",
      practicalSteps:
        "What you can do",
      seekAdviceTitle:
        "When to see a doctor",
      seekAdviceBody:
        "See a doctor if you notice any of these signs. In an emergency, call 112 straight away.",
      relatedTopics:
        "Other guides",
      readMore:
        "Read more",
      disclaimer:
        "This information is not a diagnosis. Talk to a doctor about your own health.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Heart health",
        description:
          "Everyday habits for a healthy heart and blood pressure.",
        intro:
          "Your heart pumps blood around your body every minute of the day. Looking after it lowers your risk of heart disease and stroke. Most of the habits that help are small.",
        keyFacts: [
          "High blood pressure and cholesterol quietly strain your arteries and make your heart work harder for years without signs.",
          "A healthy heart and normal blood pressure give you better stamina, steadier breathing and lower risk of stroke.",
          "Using less salt, walking briskly most days and checking your blood pressure regularly protect your heart.",
        ],
        recommendations: [
          {
            title: "Move most days",
            description:
              "Walk briskly or do any activity you like. Short walks count too.",
          },
          {
            title: "Eat for your heart",
            description:
              "Eat more vegetables, fruit and whole grains. Use less salt and eat fewer ready-made foods.",
          },
          {
            title: "Check your numbers",
            description:
              "Have your blood pressure and cholesterol checked. Problems are easier to treat when found early.",
          },
        ],
        warningSigns: [
          "Chest pain, pressure or tightness, especially if it spreads to your arm, neck or jaw.",
          "Sudden shortness of breath, or a fast or irregular heartbeat.",
          "Tiredness that does not go away, or swollen legs.",
        ],
      },
      {
        slug: "diabetes",
        title: "Diabetes",
        description:
          "What raises your risk and how to keep your blood sugar steady.",
        intro:
          "Diabetes affects how your body handles sugar in the blood. Type 2 diabetes is often linked to daily habits. You can often delay or prevent it, and with the right help you can live well with it.",
        keyFacts: [
          "In type 2 diabetes, sugar stays in the blood instead of entering your cells, and can quietly harm blood vessels for years.",
          "Keeping your blood sugar steady gives you even energy through the day and protects your eyes, kidneys, nerves and heart.",
          "Small daily habits like filling half your plate with vegetables and walking after meals lower your risk.",
        ],
        recommendations: [
          {
            title: "Balance your plate",
            description:
              "Fill half your plate with vegetables. Choose wholegrain bread, rice and pasta.",
          },
          {
            title: "Stay active",
            description:
              "Moving regularly helps your body use blood sugar better.",
          },
          {
            title: "Get checked",
            description:
              "If diabetes runs in your family or you have other risk factors, ask your doctor for a simple blood test.",
          },
        ],
        warningSigns: [
          "Being very thirsty or needing to pee more often than usual.",
          "Losing weight without trying, or feeling tired all the time.",
          "Blurred vision, or cuts that heal slowly.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Healthy eating",
        description:
          "Low-cost, simple food choices for every day.",
        intro:
          "Eating well does not have to be hard or expensive. A few simple rules, followed most days, give your body what it needs.",
        keyFacts: [
          "Fiber from vegetables and whole grains keeps your blood sugar and blood pressure steady.",
          "Simple home-cooked food gives you steady energy through the day and prevents tiredness after meals.",
          "Seasonal vegetables, beans and lentils are cheap, and drinking water instead of sugary drinks helps straight away.",
        ],
        recommendations: [
          {
            title: "More vegetables and fruit",
            description:
              "Add vegetables or fruit to most meals. Fresh or frozen are both fine.",
          },
          {
            title: "Cook at home",
            description:
              "Choose whole grains and home-cooked meals over ready-made food when you can.",
          },
          {
            title: "Drink water",
            description:
              "Make water your main drink. Limit sugary drinks and fruit juice.",
          },
        ],
        warningSigns: [
          "Losing or gaining weight quickly without trying.",
          "Stomach problems that do not go away, or loss of appetite.",
          "Feeling faint, weak or very tired even though you eat.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Physical activity",
        description:
          "Easy ways to move more, whatever your fitness.",
        intro:
          "Moving more is one of the best things you can do for your body and mind. You do not need a gym. Everyday movement counts.",
        keyFacts: [
          "Movement gets your blood flowing, strengthens your heart and muscles, and helps your cells use blood sugar for energy.",
          "Moving regularly gives you steadier energy, deeper sleep at night, and better balance and mobility.",
          "You do not need a gym: stand up every hour and take a 15–30 minute walk on most days.",
        ],
        recommendations: [
          {
            title: "Start small",
            description:
              "Begin with short walks or something you enjoy. Do a little more each week.",
          },
          {
            title: "Move most days",
            description:
              "A little movement most days does more than a hard workout now and then.",
          },
          {
            title: "Build strength",
            description:
              "Do things that work your muscles, like carrying bags, gardening or squats.",
          },
        ],
        warningSigns: [
          "Chest pain, dizziness or unusual breathlessness when you are active.",
          "Joint pain or swelling that gets worse when you move.",
          "Feeling faint, or an irregular heartbeat, when you exercise.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Mental health",
        description:
          "Look after your mind and know when to ask for help.",
        intro:
          "Your mental health is part of your health. Everyone has good and bad times. Asking for help when you need it is normal.",
        keyFacts: [
          "Long-term stress keeps stress hormones high, tightening your muscles, raising your pulse and disturbing your sleep.",
          "Looking after your mind helps you sleep better, focus during the day and stay connected with the people around you.",
          "Slow breathing exercises, regular sleep hours and talking openly with someone you trust ease tension quickly.",
        ],
        recommendations: [
          {
            title: "Stay in touch",
            description:
              "Spend time with people you trust. Being close to others protects your mind.",
          },
          {
            title: "Look after the basics",
            description:
              "Sleep, moving your body and time outdoors all help you feel better.",
          },
          {
            title: "Ask for help",
            description:
              "If things feel too much, talk to someone you trust or to a doctor.",
          },
        ],
        warningSigns: [
          "Feeling low, worried or hopeless for weeks.",
          "Finding it hard to cope with daily life, work or the people close to you.",
          "Thoughts of hurting yourself. If this happens, get help straight away.",
        ],
      },
      {
        slug: "smoking",
        title: "Quitting smoking",
        description:
          "Why quitting is worth it and what makes it easier.",
        intro:
          "Stopping smoking is one of the best things you can do for your health. Your body starts to recover quickly. Most people try several times before they stop for good.",
        keyFacts: [
          "Within hours of your last cigarette, oxygen levels rise, blood vessels relax and your lungs begin clearing themselves.",
          "As your lungs and circulation recover, you breathe more easily on stairs, cough less and regain your sense of taste.",
          "Setting a quit date, waiting out 3-minute cravings and asking your doctor for support double your chances of stopping.",
        ],
        recommendations: [
          {
            title: "Pick a quit date",
            description:
              "Choose a day and tell people you trust. Plan what you will do when you want to smoke.",
          },
          {
            title: "Get help",
            description:
              "Stop-smoking services and approved aids make it more likely you stay smoke-free.",
          },
          {
            title: "Keep trying",
            description:
              "If you smoke again, do not give up. Learn from it and try again.",
          },
        ],
        warningSigns: [
          "A cough that will not go away, or a change in a cough you have had for a long time.",
          "Coughing up blood, or chest pain that does not go away.",
          "Getting more and more out of breath doing everyday things.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Health screening",
        description:
          "Tests that catch health problems early, before you feel ill.",
        intro:
          "Screening looks for early signs of illness before you notice anything wrong. Problems found early are often easier to treat.",
        keyFacts: [
          "Many conditions like high blood pressure, diabetes or early cancers start quietly in the body long before any pain appears.",
          "Even when you feel well every day, a routine check gives you peace of mind and catches changes while treatment is simple.",
          "Ask your family doctor which free check-ups and age-appropriate screening tests you can book this year.",
        ],
        recommendations: [
          {
            title: "Ask what you need",
            description:
              "Ask your doctor which checks are right for your age and history.",
          },
          {
            title: "Go to your checks",
            description:
              "Reply to screening invitations and keep up with your regular check-ups.",
          },
          {
            title: "Share your family history",
            description:
              "Tell your doctor about illnesses in your family. It helps decide which tests you need.",
          },
        ],
        warningSigns: [
          "A new lump, unusual bleeding, or a mole that changes shape or colour.",
          "Any new symptom that does not go away and has no clear cause.",
          "A screening result that asks you to come back. Do not wait.",
        ],
      },
      {
        slug: "womens-health",
        title: "Women's health",
        description:
          "Your health at every age, from periods to menopause.",
        intro:
          "Women's health needs change through life, from periods and pregnancy to menopause and after. Knowing what is normal for you helps you notice when something changes.",
        keyFacts: [
          "A woman's body goes through natural hormone shifts from menstruation and pregnancy to menopause, affecting bones, heart and mood.",
          "Knowing what is normal for your body helps you spot breast changes, unusual bleeding or persistent pelvic pain early.",
          "Regular cervical screening, monthly breast self-checks and routine pregnancy visits find problems early when they are easiest to treat.",
        ],
        recommendations: [
          {
            title: "Know your normal",
            description:
              "Notice your usual cycle and body, so changes stand out.",
          },
          {
            title: "Keep up with check-ups",
            description:
              "Go to the screenings and appointments recommended for your age.",
          },
          {
            title: "Get help early",
            description:
              "Talk to a doctor about any symptom that worries you.",
          },
        ],
        warningSigns: [
          "Unusual bleeding, between periods or after menopause.",
          "Strong or long-lasting pain in your lower belly or pelvis.",
          "A new change in your breast, such as a lump, a dent or a change in the skin.",
        ],
      },
    ],
  },
  ro: {
    labels: {
      allTopics:
        "Toate ghidurile de sănătate",
      whyItMatters:
        "De ce contează",
      practicalSteps:
        "Ce poți face",
      seekAdviceTitle:
        "Când mergi la medic",
      seekAdviceBody:
        "Mergi la medic dacă observi unul dintre semnele de mai jos. Dacă e o urgență, sună imediat la 112.",
      relatedTopics:
        "Alte ghiduri",
      readMore:
        "Citește mai mult",
      disclaimer:
        "Aceste informații nu sunt un diagnostic. Pentru sănătatea ta, vorbește cu medicul.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Sănătatea inimii",
        description:
          "Obiceiuri simple pentru o inimă sănătoasă și o tensiune bună.",
        intro:
          "Inima pompează sângele prin corp în fiecare minut. Dacă ai grijă de ea, scade riscul de boli de inimă și de accident vascular.",
        keyFacts: [
          "Tensiunea mare și colesterolul crescut apasă în tăcere pe pereții arterelor și obosesc inima fără să dea semne.",
          "O inimă puternică și o tensiune bună îți dau rezistență la efort, respirație ușoară și risc mai mic de accident vascular.",
          "Mai puțină sare în mâncare, mersul pe jos în fiecare zi și măsurarea regulată a tensiunii îți protejează inima.",
        ],
        recommendations: [
          {
            title: "Mișcă-te des",
            description:
              "Mergi pe jos în pas vioi cât de des poți.",
          },
          {
            title: "Mănâncă sănătos",
            description:
              "Pune în farfurie mai multe legume, fructe și cereale integrale.",
          },
          {
            title: "Fă-ți controalele",
            description:
              "Verifică regulat tensiunea și colesterolul.",
          },
        ],
        warningSigns: [
          "Durere sau apăsare în piept, mai ales dacă se întinde spre braț sau maxilar.",
          "Lipsă bruscă de aer sau bătăi neregulate ale inimii.",
          "Oboseală care nu trece sau picioare umflate.",
        ],
      },
      {
        slug: "diabetes",
        title: "Diabet",
        description:
          "Ce crește riscul și cum ții zahărul din sânge sub control.",
        intro:
          "Diabetul schimbă felul în care corpul folosește zahărul din sânge. Cu ajutorul potrivit, poate fi prevenit sau ținut sub control.",
        keyFacts: [
          "În diabetul de tip 2, zahărul rămâne în sânge în loc să intre în celule și poate afecta vasele de sânge ani de zile fără semne clare.",
          "Când ții zahărul din sânge în echilibru, ai energie constantă peste zi și îți protejezi ochii, rinichii, nervii și inima.",
          "Schimbările mici făcute zi de zi, cum ar fi jumătate de farfurie cu legume și o plimbare după masă, scad riscul.",
        ],
        recommendations: [
          {
            title: "Echilibrează farfuria",
            description:
              "Umple jumătate din farfurie cu legume. Alege pâine și cereale integrale.",
          },
          {
            title: "Mișcă-te",
            description:
              "Mișcarea regulată ajută corpul să folosească mai bine zahărul din sânge.",
          },
          {
            title: "Fă analize",
            description:
              "Dacă ai factori de risc, cere medicului o analiză de sânge.",
          },
        ],
        warningSigns: [
          "Sete mare sau urinat des.",
          "Slăbești fără să vrei sau ești mereu obosit.",
          "Vezi încețoșat sau rănile se vindecă greu.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Alimentație sănătoasă",
        description:
          "Mâncare simplă și ieftină, pentru fiecare zi.",
        intro:
          "Ca să mănânci sănătos, nu ai nevoie de rețete grele sau scumpe. Câteva reguli simple, respectate zilnic, te ajută mult.",
        keyFacts: [
          "Fibrele din legume și cereale integrale țin zahărul din sânge și tensiunea în limite normale.",
          "Mâncarea gătită simplu îți dă energie peste zi și te ferește de oboseala de după masă.",
          "Legumele de sezon, fasolea și lintea sunt ieftine, iar apa în loc de sucuri dulci ajută imediat.",
        ],
        recommendations: [
          {
            title: "Mai multe legume și fructe",
            description:
              "Pune legume sau fructe la cele mai multe mese.",
          },
          {
            title: "Gătește acasă",
            description:
              "Alege cereale integrale și mâncare gătită acasă.",
          },
          {
            title: "Bea apă",
            description:
              "Bea mai ales apă și cât mai puține sucuri dulci.",
          },
        ],
        warningSigns: [
          "Te îngrași sau slăbești mult în scurt timp.",
          "Probleme cu digestia care nu trec sau lipsa poftei de mâncare.",
          "Slăbiciune, amețeală sau oboseală neobișnuită.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Activitate fizică",
        description:
          "Cum te miști mai mult, chiar dacă nu ai făcut sport.",
        intro:
          "Mișcarea regulată face bine corpului și minții. Nu ai nevoie de sală. Contează și mersul pe jos.",
        keyFacts: [
          "Mișcarea pune sângele în circulație, întărește inima și mușchii și ajută celulele să folosească zahărul din sânge.",
          "Când te miști regulat, ai mai multă energie, dormi mai bine noaptea și îți păstrezi echilibrul și mobilitatea.",
          "Nu ai nevoie de sală: ridică-te de pe scaun la fiecare oră și mergi pe jos 15–30 de minute în majoritatea zilelor.",
        ],
        recommendations: [
          {
            title: "Începe ușor",
            description:
              "Pornește cu plimbări scurte. Mergi puțin mai mult în fiecare săptămână.",
          },
          {
            title: "Mișcă-te regulat",
            description:
              "Puțină mișcare în fiecare zi ajută mai mult decât un efort mare din când în când.",
          },
          {
            title: "Lucrează mușchii",
            description:
              "Cară sacoșe, lucrează în grădină sau fă genuflexiuni.",
          },
        ],
        warningSigns: [
          "Durere în piept, amețeală sau lipsă de aer când faci efort.",
          "Dureri de încheieturi care se agravează când te miști.",
          "Simți că leșini sau inima bate neregulat în timpul exercițiilor.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Echilibru emoțional",
        description:
          "Ai grijă de mintea ta și cere ajutor când ai nevoie.",
        intro:
          "Sănătatea minții face parte din sănătatea ta. E normal să ai și perioade grele.",
        keyFacts: [
          "Stresul prelungit ține corpul în încordare, grăbește bătăile inimii, strânge mușchii și tulbură somnul.",
          "Când ai grijă de echilibrul emoțional, dormi mai liniștit, te concentrezi mai ușor și faci față mai bine grijilor.",
          "Respirația rară și adâncă, programul regulat de somn și o discuție deschisă cu cineva apropiat liniștesc corpul.",
        ],
        recommendations: [
          {
            title: "Păstrează legătura",
            description:
              "Vorbește des cu oamenii în care ai încredere.",
          },
          {
            title: "Ai grijă de lucrurile de bază",
            description:
              "Somnul, mișcarea și timpul petrecut afară te ajută.",
          },
          {
            title: "Cere ajutor",
            description:
              "Vorbește cu cineva de încredere sau cu un medic.",
          },
        ],
        warningSigns: [
          "Tristețe, griji sau lipsă de speranță care țin mai multe săptămâni.",
          "Nu mai faci față la muncă, acasă sau în relațiile cu ceilalți.",
          "Dacă te gândești să îți faci rău, cere ajutor imediat.",
        ],
      },
      {
        slug: "smoking",
        title: "Renunțarea la fumat",
        description:
          "De ce merită să te lași și ce te ajută.",
        intro:
          "Când te lași de fumat, faci unul dintre cele mai bune lucruri pentru sănătatea ta. Corpul începe repede să se refacă.",
        keyFacts: [
          "Din primele ore după ultima țigară, nivelul de oxigen din sânge urcă, vasele se relaxează și plămânii încep să se curețe.",
          "Pe măsură ce corpul se reface, respiri mai ușor când urci scările, tușești mai puțin și îți revin gustul și mirosul.",
          "Dacă îți alegi o zi de oprire, lași să treacă cele 3 minute de poftă și ceri sprijinul medicului, îți dublezi șansele de reușită.",
        ],
        recommendations: [
          {
            title: "Alege o zi",
            description:
              "Alege ziua în care te lași. Gândește-te dinainte ce faci când ai poftă de țigară.",
          },
          {
            title: "Cere ajutor",
            description:
              "Programele de renunțare la fumat și tratamentele aprobate te ajută.",
          },
          {
            title: "Nu renunța",
            description:
              "Dacă ai fumat din nou, încearcă iar.",
          },
        ],
        warningSigns: [
          "Tuse care nu trece sau tuse obișnuită care se schimbă.",
          "Tuși cu sânge sau ai durere în piept care nu trece.",
          "Rămâi tot mai des fără aer la treburile de zi cu zi.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Screening preventiv",
        description:
          "Controale care găsesc bolile devreme, înainte să ai semne.",
        intro:
          "Screeningul caută primele semne ale unei boli, chiar dacă te simți bine.",
        keyFacts: [
          "Multe afecțiuni, cum ar fi tensiunea mare, diabetul sau unele forme de cancer, încep în tăcere în corp, cu mult înainte să doară.",
          "Chiar când te simți în putere zi de zi, un control de rutină îți dă liniște și descoperă schimbările când se tratează ușor.",
          "Cere medicului de familie analizele gratuite și controalele decontate de CNAS potrivite pentru vârsta ta.",
        ],
        recommendations: [
          {
            title: "Întreabă ce îți trebuie",
            description:
              "Întreabă medicul de familie ce controale sunt potrivite pentru tine.",
          },
          {
            title: "Mergi la controale",
            description:
              "Mergi când ești chemat la screening și la controalele obișnuite.",
          },
          {
            title: "Spune ce boli sunt în familie",
            description:
              "Spune-i medicului ce boli au avut părinții, frații sau bunicii.",
          },
        ],
        warningSigns: [
          "Un nodul nou, o sângerare neobișnuită sau o aluniță care își schimbă forma.",
          "Orice semn nou care nu trece și nu știi de unde vine.",
          "Un rezultat la screening după care trebuie să mai faci analize.",
        ],
      },
      {
        slug: "womens-health",
        title: "Sănătatea femeii",
        description:
          "Sănătatea ta la fiecare vârstă, de la menstruație la menopauză.",
        intro:
          "Nevoile tale de sănătate se schimbă de-a lungul vieții. Dacă știi ce e normal pentru tine, observi mai ușor când ceva se schimbă.",
        keyFacts: [
          "Corpul femeii trece prin etape firești, de la menstruație și sarcină până la menopauză, ghidate de hormoni care influențează oasele și inima.",
          "Când îți cunoști corpul, observi din timp orice schimbare la sâni, sângerare neobișnuită sau durere care nu trece.",
          "Testul Babeș-Papanicolau, autoexaminarea lunară a sânilor și controalele regulate în sarcină depistează problemele devreme.",
        ],
        recommendations: [
          {
            title: "Cunoaște-ți corpul",
            description:
              "Fii atentă la ciclul tău și la corpul tău, ca să observi schimbările.",
          },
          {
            title: "Mergi la controale",
            description:
              "Mergi la consultațiile și screeningurile recomandate pentru vârsta ta.",
          },
          {
            title: "Cere ajutor din timp",
            description:
              "Vorbește devreme cu medicul despre orice semn care te îngrijorează.",
          },
        ],
        warningSigns: [
          "Sângerări neobișnuite, între menstruații sau după menopauză.",
          "Durere puternică sau care nu trece în partea de jos a burții.",
          "O schimbare nouă la sân, de exemplu un nodul sau pielea schimbată.",
        ],
      },
    ],
  },
  sq: {
    labels: {
      allTopics:
        "Të gjitha temat e shëndetit",
      whyItMatters:
        "Pse ka rëndësi",
      practicalSteps:
        "Çfarë mund të bësh",
      seekAdviceTitle:
        "Kur të shkosh te mjeku",
      seekAdviceBody:
        "Shko te mjeku nëse vë re një nga këto shenja. Në rast urgjence, telefono menjëherë 112.",
      relatedTopics:
        "Tema të tjera",
      readMore:
        "Lexo më shumë",
      disclaimer:
        "Ky informacion nuk është diagnozë. Për shëndetin tënd, fol me mjekun.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Shëndeti i zemrës",
        description:
          "Zakone të thjeshta për një zemër të shëndetshme dhe tension normal.",
        intro:
          "Zemra pompon gjakun në trup çdo minutë. Kur kujdesesh për të, ulet rreziku i sëmundjeve të zemrës dhe i goditjes në tru.",
        keyFacts: [
          "Tensioni i lartë dhe kolesteroli i shtuar rëndojnë në heshtje muret e arterieve dhe e lodhin zemrën pa dhënë shenja.",
          "Një zemër e fortë dhe tension normal të japin më shumë qëndrueshmëri, frymëmarrje të lehtë dhe rrezik më të ulët për goditje në tru.",
          "Më pak kripë në ushqim, ecja e përditshme dhe matja e rregullt e tensionit e mbrojnë zemrën.",
        ],
        recommendations: [
          {
            title: "Lëviz shpesh",
            description:
              "Ec me hap të shpejtë sa më shpesh që mundesh.",
          },
          {
            title: "Ha shëndetshëm",
            description:
              "Ha më shumë perime, fruta dhe drithëra integrale.",
          },
          {
            title: "Kontrollo vlerat",
            description:
              "Mat rregullisht tensionin dhe kontrollo kolesterolin.",
          },
        ],
        warningSigns: [
          "Dhimbje ose shtrëngim në gjoks, sidomos nëse shtrihet në krah ose në nofull.",
          "Mungesë e papritur ajri ose rrahje të parregullta të zemrës.",
          "Lodhje që nuk kalon ose këmbë të ënjtura.",
        ],
      },
      {
        slug: "diabetes",
        title: "Diabeti",
        description:
          "Çfarë e rrit rrezikun dhe si ta mbash sheqerin nën kontroll.",
        intro:
          "Diabeti ndikon në mënyrën si trupi përdor sheqerin në gjak. Me ndihmën e duhur, mund të parandalohet ose të mbahet nën kontroll.",
        keyFacts: [
          "Te diabeti i tipit 2, sheqeri mbetet në gjak në vend që të hyjë në qeliza dhe mund të dëmtojë enët e gjakut për vite pa shenja të qarta.",
          "Kur e mban sheqerin në ekuilibër, ke energji të qëndrueshme gjatë ditës dhe mbron sytë, veshkat, nervat dhe zemrën.",
          "Ndryshimet e vogla çdo ditë, si gjysma e pjatës me perime dhe një shëtitje pas vaktit, e ulin rrezikun.",
        ],
        recommendations: [
          {
            title: "Balanco pjatën",
            description:
              "Mbush gjysmën e pjatës me perime dhe zgjidh drithëra integrale.",
          },
          {
            title: "Lëviz rregullisht",
            description:
              "Lëvizja e rregullt e ndihmon trupin të përdorë më mirë sheqerin.",
          },
          {
            title: "Bëj analizat",
            description:
              "Nëse ke faktorë rreziku, kërkoji mjekut një analizë gjaku.",
          },
        ],
        warningSigns: [
          "Etje e madhe ose urinim i shpeshtë.",
          "Humb peshë pa dashur ose je gjithmonë i lodhur.",
          "Shikim i turbullt ose plagë që shërohen ngadalë.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Ushqyerja e shëndetshme",
        description:
          "Ushqime të shëndetshme dhe të lira për çdo ditë.",
        intro:
          "Të hash mirë nuk është e vështirë as e shtrenjtë. Disa rregulla të thjeshta, çdo ditë, të ndihmojnë shumë.",
        keyFacts: [
          "Fibrat nga perimet dhe drithërat integrale mbajnë sheqerin në gjak dhe tensionin në kufij normalë.",
          "Ushqimi i gatuar thjesht të jep energji gjatë ditës dhe shmang lodhjen pas ngrënies.",
          "Perimet e stinës, fasulet dhe thjerrëzat janë të lira, ndërsa uji në vend të pijeve me sheqer ndihmon menjëherë.",
        ],
        recommendations: [
          {
            title: "Më shumë perime dhe fruta",
            description:
              "Shto perime ose fruta në shumicën e vakteve.",
          },
          {
            title: "Gatuaj në shtëpi",
            description:
              "Zgjidh drithëra integrale dhe ushqime të gatuara në shtëpi.",
          },
          {
            title: "Pi ujë",
            description:
              "Pi kryesisht ujë dhe sa më pak pije të ëmbla.",
          },
        ],
        warningSigns: [
          "Shton ose humb shumë peshë në pak kohë.",
          "Probleme me tretjen që nuk kalojnë ose s'ke oreks.",
          "Dobësi, marramendje ose lodhje e pazakontë.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Aktiviteti fizik",
        description:
          "Mënyra të thjeshta për të lëvizur më shumë.",
        intro:
          "Lëvizja e rregullt i bën mirë trupit dhe mendjes. Nuk të duhet palestër. Edhe ecja ka vlerë.",
        keyFacts: [
          "Lëvizja vë gjakun në qarkullim, forcon zemrën dhe muskujt dhe ndihmon qelizat të përdorin sheqerin në gjak.",
          "Kur lëviz rregullisht, ke më shumë energji, fle më mirë natën dhe ruan ekuilibrin dhe lëvizshmërinë.",
          "Nuk të duhet palestër: çohu nga karrigia çdo orë dhe ec 15–30 minuta në shumicën e ditëve.",
        ],
        recommendations: [
          {
            title: "Fillo ngadalë",
            description:
              "Nis me ecje të shkurtra dhe shto pak nga pak.",
          },
          {
            title: "Lëviz çdo ditë",
            description:
              "Pak lëvizje çdo ditë vlen më shumë se një përpjekje e madhe herë pas here.",
          },
          {
            title: "Forco muskujt",
            description:
              "Mbaj çanta, puno në kopsht ose bëj mbledhje këmbësh.",
          },
        ],
        warningSigns: [
          "Dhimbje gjoksi, marramendje ose mungesë e pazakontë ajri kur lëviz.",
          "Dhimbje kyçesh që përkeqësohen kur lëviz.",
          "Të vjen të fikët ose zemra rreh e parregullt gjatë ushtrimeve.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Ekuilibri emocional",
        description:
          "Kujdesu për mendjen dhe kërko ndihmë kur të duhet.",
        intro:
          "Shëndeti mendor është pjesë e shëndetit tënd. Është normale të kesh edhe periudha të vështira.",
        keyFacts: [
          "Stresi i zgjatur e mban trupin të tendosur, shpejton rrahjet e zemrës, shtrëngon muskujt dhe prish gjumin.",
          "Kur kujdesesh për ekuilibrin emocional, fle më qetë, përqendrohesh më lehtë dhe i përballon më mirë shqetësimet.",
          "Frymëmarrja e ngadaltë e e thellë, orari i rregullt i gjumit dhe një bisedë e hapur me dikë të afërt e qetësojnë trupin.",
        ],
        recommendations: [
          {
            title: "Mos u izolo",
            description:
              "Mbaj lidhje me njerëzit që u beson.",
          },
          {
            title: "Kujdesu për bazat",
            description:
              "Gjumi, lëvizja dhe koha jashtë të ndihmojnë.",
          },
          {
            title: "Kërko ndihmë",
            description:
              "Fol me dikë që i beson ose me mjekun.",
          },
        ],
        warningSigns: [
          "Trishtim, ankth ose mungesë shprese që zgjat disa javë.",
          "Nuk po ia del me jetën e përditshme, punën ose marrëdhëniet.",
          "Nëse mendon të lëndosh veten, kërko ndihmë menjëherë.",
        ],
      },
      {
        slug: "smoking",
        title: "Lënia e duhanit",
        description:
          "Pse ia vlen ta lësh duhanin dhe çfarë të ndihmon.",
        intro:
          "Lënia e duhanit është një nga gjërat më të mira që mund të bësh për shëndetin. Trupi fillon të rimëkëmbet shpejt.",
        keyFacts: [
          "Që në orët e para pas cigares së fundit, niveli i oksigjenit rritet, enët e gjakut çlirohen dhe mushkëritë nisin të pastrohen.",
          "Ndërsa trupi rimëkëmbet, merr frymë më lehtë në shkallë, kollitesh më pak dhe të kthehen shija e nuhatja.",
          "Nëse zgjedh një ditë për ta lënë, kalon 3 minutat e dëshirës dhe kërkon mbështetjen e mjekut, i dyfishon shanset për t'ia dalë.",
        ],
        recommendations: [
          {
            title: "Zgjidh një datë",
            description:
              "Vendos ditën kur e lë. Mendo që më parë çfarë do të bësh kur të vijë dëshira për cigare.",
          },
          {
            title: "Kërko ndihmë",
            description:
              "Programet për lënien e duhanit dhe mjetet e miratuara e bëjnë më të lehtë.",
          },
          {
            title: "Mos u dorëzo",
            description:
              "Nëse e ndez sërish, provo përsëri.",
          },
        ],
        warningSigns: [
          "Kollë që nuk kalon ose ndryshim i kollës së zakonshme.",
          "Kollë me gjak ose dhimbje gjoksi që nuk kalon.",
          "Të mungon ajri gjithnjë e më shumë në punët e përditshme.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Kontrollet parandaluese",
        description:
          "Kontrolle që zbulojnë problemet herët, para shenjave.",
        intro:
          "Kontrollet parandaluese kërkojnë shenjat e para të një sëmundjeje, edhe kur ndihesh mirë.",
        keyFacts: [
          "Shumë probleme, si tensioni i lartë, diabeti apo disa lloje kanceri, nisin në heshtje në trup shumë kohë para se të dhembin.",
          "Edhe kur ndihesh mirë çdo ditë, një kontroll i rregullt të jep qetësi dhe i kap ndryshimet kur mjekohen lehtë.",
          "Kërkoji mjekut të familjes analizat falas dhe kontrollet e rekomanduara për moshën tënde.",
        ],
        recommendations: [
          {
            title: "Pyet çfarë të duhet",
            description:
              "Pyet mjekun cilat kontrolle rekomandohen për ty.",
          },
          {
            title: "Shko në kontrolle",
            description:
              "Mos i humb ftesat për kontroll dhe analizat e zakonshme.",
          },
          {
            title: "Trego sëmundjet në familje",
            description:
              "Tregoji mjekut çfarë sëmundjesh kanë pasur prindërit, vëllezërit, motrat ose gjyshërit.",
          },
        ],
        warningSigns: [
          "Një gungë e re, gjakderdhje e pazakontë ose nishan që ndryshon formë.",
          "Çdo shenjë e re që nuk kalon dhe nuk e di nga vjen.",
          "Një rezultat kontrolli që kërkon analiza të tjera.",
        ],
      },
      {
        slug: "womens-health",
        title: "Shëndeti i gruas",
        description:
          "Shëndeti yt në çdo moshë, nga cikli te menopauza.",
        intro:
          "Nevojat e tua për shëndetin ndryshojnë gjatë jetës. Kur di çfarë është normale për ty, e vë re më lehtë një ndryshim.",
        keyFacts: [
          "Trupi i gruas kalon nëpër faza të natyrshme nga cikli dhe shtatzënia deri te menopauza, të udhëhequra nga hormonet që ndikojnë kockat dhe zemrën.",
          "Kur e njeh trupin tënd, vë re me kohë çdo ndryshim në gji, gjakderdhje të pazakontë ose dhimbje që nuk kalon.",
          "Pap-testi, vetëkontrolli mujor i gjirit dhe vizitat e rregullta në shtatzëni i zbulojnë problemet herët.",
        ],
        recommendations: [
          {
            title: "Njih trupin tënd",
            description:
              "Ki parasysh ciklin dhe trupin tënd, që të vësh re ndryshimet.",
          },
          {
            title: "Shko në kontrolle",
            description:
              "Shko në vizitat dhe kontrollet e rekomanduara për moshën tënde.",
          },
          {
            title: "Kërko ndihmë herët",
            description:
              "Fol me mjekun për çdo shenjë që të shqetëson.",
          },
        ],
        warningSigns: [
          "Gjakderdhje e pazakontë, mes cikleve ose pas menopauzës.",
          "Dhimbje e fortë ose që nuk kalon në fund të barkut.",
          "Ndryshim i ri në gji, si gungë ose ndryshim i lëkurës.",
        ],
      },
    ],
  },
  it: {
    labels: {
      allTopics:
        "Tutte le guide sulla salute",
      whyItMatters:
        "Perché è importante",
      practicalSteps:
        "Cosa puoi fare",
      seekAdviceTitle:
        "Quando andare dal medico",
      seekAdviceBody:
        "Vai dal medico se noti uno di questi segnali. In caso di emergenza, chiama subito il 112.",
      relatedTopics:
        "Altre guide",
      readMore:
        "Leggi di più",
      disclaimer:
        "Queste informazioni non sono una diagnosi. Per la tua salute, parla con il medico.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Salute del cuore",
        description:
          "Abitudini semplici per un cuore sano e una pressione nella norma.",
        intro:
          "Il cuore pompa il sangue in tutto il corpo, ogni minuto. Se te ne prendi cura, riduci il rischio di malattie del cuore e di ictus.",
        keyFacts: [
          "La pressione alta e il colesterolo elevato affaticano in silenzio le arterie e il cuore per anni senza dare sintomi.",
          "Un cuore forte e una pressione normale ti danno più resistenza allo sforzo, respiro migliore e minor rischio di ictus.",
          "Usare meno sale a tavola, camminare ogni giorno e misurare regolarmente la pressione proteggono il cuore.",
        ],
        recommendations: [
          {
            title: "Muoviti spesso",
            description:
              "Cammina a passo svelto ogni volta che puoi.",
          },
          {
            title: "Mangia meglio",
            description:
              "Mangia più verdura, frutta e cereali integrali.",
          },
          {
            title: "Controlla i valori",
            description:
              "Fatti controllare spesso pressione e colesterolo.",
          },
        ],
        warningSigns: [
          "Dolore o peso al petto, soprattutto se arriva al braccio o alla mandibola.",
          "Fiato corto all'improvviso o battito irregolare.",
          "Stanchezza che non passa o gambe gonfie.",
        ],
      },
      {
        slug: "diabetes",
        title: "Diabete",
        description:
          "Cosa aumenta il rischio e come tenere stabile lo zucchero nel sangue.",
        intro:
          "Il diabete cambia il modo in cui il corpo usa lo zucchero nel sangue. Con l'aiuto giusto, si può prevenire o tenere sotto controllo.",
        keyFacts: [
          "Nel diabete di tipo 2 lo zucchero resta nel sangue invece di entrare nelle cellule e può danneggiare i vasi per anni senza sintomi chiari.",
          "Tenere in equilibrio lo zucchero nel sangue ti dà energia costante durante il giorno e protegge occhi, reni, nervi e cuore.",
          "Piccoli cambiamenti ogni giorno, come metà piatto di verdure e una passeggiata dopo i pasti, riducono il rischio.",
        ],
        recommendations: [
          {
            title: "Bilancia il piatto",
            description:
              "Riempi metà piatto di verdura e scegli cereali integrali.",
          },
          {
            title: "Resta attivo",
            description:
              "Muoverti con regolarità aiuta il corpo a usare meglio lo zucchero.",
          },
          {
            title: "Fai le analisi",
            description:
              "Se hai fattori di rischio, chiedi al medico un esame del sangue.",
          },
        ],
        warningSigns: [
          "Molta sete o bisogno di urinare spesso.",
          "Perdi peso senza motivo o sei sempre stanco.",
          "Vista annebbiata o ferite che guariscono lentamente.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Alimentazione sana",
        description:
          "Cibo sano ed economico, per tutti i giorni.",
        intro:
          "Mangiare bene non deve essere complicato o costoso. Poche regole semplici, ogni giorno, ti aiutano molto.",
        keyFacts: [
          "Le fibre di verdure e cereali integrali tengono stabili lo zucchero nel sangue e la pressione.",
          "Il cibo cucinato in modo semplice ti dà energia costante e ti evita la stanchezza dopo i pasti.",
          "Verdure di stagione, fagioli e lenticchie costano poco, e bere acqua al posto delle bibite zuccherate aiuta subito.",
        ],
        recommendations: [
          {
            title: "Più verdura e frutta",
            description:
              "Aggiungi verdura o frutta alla maggior parte dei pasti.",
          },
          {
            title: "Cucina a casa",
            description:
              "Preferisci cereali integrali e piatti cucinati a casa.",
          },
          {
            title: "Bevi acqua",
            description:
              "Bevi soprattutto acqua e poche bibite zuccherate.",
          },
        ],
        warningSigns: [
          "Aumento o perdita di peso in poco tempo.",
          "Problemi di digestione che non passano o poca fame.",
          "Debolezza, capogiri o stanchezza insolita.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Attività fisica",
        description:
          "Modi semplici per muoverti di più.",
        intro:
          "Muoverti con regolarità fa bene al corpo e alla mente. Non ti serve la palestra. Anche camminare conta.",
        keyFacts: [
          "Il movimento attiva la circolazione, rafforza il cuore e i muscoli e aiuta le cellule a usare lo zucchero nel sangue.",
          "Muoverti con regolarità ti dà più energia, un sonno migliore e più equilibrio e mobilità ogni giorno.",
          "Non serve la palestra: alzati dalla sedia ogni ora e cammina per 15–30 minuti nella maggior parte dei giorni.",
        ],
        recommendations: [
          {
            title: "Inizia piano",
            description:
              "Comincia con brevi camminate e aumenta poco alla volta.",
          },
          {
            title: "Muoviti con costanza",
            description:
              "Un po' di movimento ogni giorno conta più di un grande sforzo ogni tanto.",
          },
          {
            title: "Rinforza i muscoli",
            description:
              "Porta la spesa, lavora in giardino o fai qualche piegamento sulle gambe.",
          },
        ],
        warningSigns: [
          "Dolore al petto, capogiri o fiato corto insolito durante l'attività.",
          "Dolore alle articolazioni che peggiora quando ti muovi.",
          "Senso di svenimento o battito irregolare durante l'esercizio.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Equilibrio emotivo",
        description:
          "Prenditi cura della mente e chiedi aiuto quando serve.",
        intro:
          "La salute mentale fa parte della tua salute. È normale avere anche periodi difficili.",
        keyFacts: [
          "Lo stress prolungato mantiene il corpo in tensione, accelera il battito, irrigidisce i muscoli e disturba il sonno.",
          "Quando ti prendi cura dell'equilibrio emotivo dormi più sereno, ti concentri meglio e affronti con più calma le preoccupazioni.",
          "La respirazione lenta e profonda, orari di sonno regolari e parlare apertamente con una persona fidata calmano il corpo.",
        ],
        recommendations: [
          {
            title: "Resta in contatto",
            description:
              "Tieniti in contatto con le persone di cui ti fidi.",
          },
          {
            title: "Cura le basi",
            description:
              "Sonno, movimento e tempo all'aperto ti aiutano.",
          },
          {
            title: "Chiedi aiuto",
            description:
              "Parla con una persona di fiducia o con il medico.",
          },
        ],
        warningSigns: [
          "Umore basso, ansia o mancanza di speranza per settimane.",
          "Fai fatica nella vita di tutti i giorni, al lavoro o con gli altri.",
          "Se pensi di farti del male, chiedi aiuto subito.",
        ],
      },
      {
        slug: "smoking",
        title: "Smettere di fumare",
        description:
          "Perché conviene smettere e cosa ti aiuta.",
        intro:
          "Smettere di fumare è una delle cose migliori che puoi fare per la tua salute. Il corpo comincia presto a riprendersi.",
        keyFacts: [
          "Già nelle prime ore dopo l'ultima sigaretta l'ossigeno nel sangue sale, i vasi si rilassano e i polmoni iniziano a pulirsi.",
          "Man mano che il corpo recupera respiri meglio sulle scale, tossisci meno e ritrovi gusto e olfatto.",
          "Scegliere un giorno per smettere, superare i 3 minuti di voglia e chiedere il supporto del medico raddoppiano le probabilità di riuscita.",
        ],
        recommendations: [
          {
            title: "Scegli una data",
            description:
              "Scegli il giorno in cui smetti. Pensa prima a cosa fare quando hai voglia di fumare.",
          },
          {
            title: "Fatti aiutare",
            description:
              "I centri antifumo e i prodotti approvati ti rendono tutto più facile.",
          },
          {
            title: "Non arrenderti",
            description:
              "Se ricominci a fumare, riprova.",
          },
        ],
        warningSigns: [
          "Tosse che non passa o tosse abituale che cambia.",
          "Sangue quando tossisci o dolore al petto che non passa.",
          "Fiato sempre più corto nelle attività di tutti i giorni.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Screening preventivo",
        description:
          "Controlli che trovano i problemi presto, prima dei sintomi.",
        intro:
          "Lo screening cerca i primi segni di una malattia, anche quando ti senti bene.",
        keyFacts: [
          "Molte condizioni, come la pressione alta, il diabete o alcuni tumori, iniziano in silenzio nel corpo molto prima di dare dolore.",
          "Anche quando ti senti in forze ogni giorno, un controllo di routine ti dà tranquillità e individua i cambiamenti quando si curano facilmente.",
          "Chiedi al medico di famiglia gli esami gratuiti e gli screening consigliati per la tua età.",
        ],
        recommendations: [
          {
            title: "Chiedi cosa ti serve",
            description:
              "Chiedi al medico quali controlli sono consigliati per te.",
          },
          {
            title: "Vai ai controlli",
            description:
              "Non saltare gli inviti allo screening e i controlli di routine.",
          },
          {
            title: "Parla della tua famiglia",
            description:
              "Di' al medico quali malattie hanno avuto i tuoi genitori, fratelli o nonni.",
          },
        ],
        warningSigns: [
          "Un nodulo nuovo, un sanguinamento strano o un neo che cambia forma.",
          "Qualsiasi sintomo nuovo che non passa e non ha una causa chiara.",
          "Un risultato di screening che richiede altri esami.",
        ],
      },
      {
        slug: "womens-health",
        title: "Salute della donna",
        description:
          "La tua salute a ogni età, dal ciclo alla menopausa.",
        intro:
          "I tuoi bisogni di salute cambiano nel corso della vita. Se sai cosa è normale per te, noti prima quando qualcosa cambia.",
        keyFacts: [
          "Il corpo femminile attraversa fasi naturali dal ciclo e dalla gravidanza fino alla menopausa, guidate da ormoni che agiscono su ossa e cuore.",
          "Quando conosci il tuo corpo noti subito qualsiasi cambiamento al seno, sanguinamento insolito o dolore che non passa.",
          "Il Pap test, l'autoesame mensile del seno e le visite regolari in gravidanza individuano i problemi precocemente.",
        ],
        recommendations: [
          {
            title: "Conosci il tuo corpo",
            description:
              "Fai caso al tuo ciclo e al tuo corpo, così noti i cambiamenti.",
          },
          {
            title: "Fai i controlli",
            description:
              "Vai alle visite e agli screening consigliati per la tua età.",
          },
          {
            title: "Chiedi aiuto presto",
            description:
              "Parla con il medico di qualsiasi sintomo che ti preoccupa.",
          },
        ],
        warningSigns: [
          "Sanguinamenti insoliti, tra un ciclo e l'altro o dopo la menopausa.",
          "Dolore forte o che non passa al basso ventre.",
          "Un cambiamento nuovo al seno, come un nodulo o la pelle diversa.",
        ],
      },
    ],
  },
  hr: {
    labels: {
      allTopics:
        "Svi zdravstveni vodiči",
      whyItMatters:
        "Zašto je važno",
      practicalSteps:
        "Što možeš učiniti",
      seekAdviceTitle:
        "Kada otići liječniku",
      seekAdviceBody:
        "Javi se liječniku ako primijetiš neki od ovih znakova. U hitnom slučaju odmah nazovi 112.",
      relatedTopics:
        "Drugi vodiči",
      readMore:
        "Pročitaj više",
      disclaimer:
        "Ove informacije nisu dijagnoza. Za svoje zdravlje razgovaraj s liječnikom.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Zdravlje srca",
        description:
          "Jednostavne navike za zdravo srce i dobar krvni tlak.",
        intro:
          "Tvoje srce svake minute pumpa krv kroz cijelo tijelo. Briga o srcu smanjuje rizik od srčanih bolesti i moždanog udara.",
        keyFacts: [
          "Visoki krvni tlak i povišeni kolesterol tiho opterećuju arterije i umaraju srce godinama bez ikakvih znakova.",
          "Snažno srce i normalan tlak daju ti bolju izdržljivost, lakše disanje i manji rizik od moždanog udara.",
          "Manje soli u hrani, svakodnevno brzo hodanje i redovito mjerenje tlaka štite tvoje srce.",
        ],
        recommendations: [
          {
            title: "Kreći se većinu dana",
            description:
              "Hodaj brzim korakom ili radi aktivnost koju voliš. I kratke šetnje vrijede.",
          },
          {
            title: "Jedi zdravo za srce",
            description:
              "Jedi više povrća, voća i cjelovitih žitarica. Smanji sol i gotovu industrijsku hranu.",
          },
          {
            title: "Provjeravaj svoje vrijednosti",
            description:
              "Redovito provjeravaj krvni tlak i kolesterol. Tegobe se lakše liječe kada se otkriju rano.",
          },
        ],
        warningSigns: [
          "Bol, pritisak ili stezanje u prsima, osobito ako se širi u ruku, vrat ili čeljust.",
          "Nagli nedostatak zraka ili brz i nepravilan rad srca.",
          "Umor koji ne prolazi ili otečene noge.",
        ],
      },
      {
        slug: "diabetes",
        title: "Dijabetes",
        description:
          "Što povećava rizik i kako držati šećer u krvi pod kontrolom.",
        intro:
          "Dijabetes utječe na to kako tvoje tijelo koristi šećer u krvi. Uz pravu podršku tip 2 možeš spriječiti, odgoditi ili dobro držati pod kontrolom.",
        keyFacts: [
          "Kod dijabetesa tipa 2 šećer ostaje u krvi umjesto da ulazi u stanice te može godinama tiho oštećivati krvne žile.",
          "Stabilan šećer u krvi daje ti ravnomjernu energiju kroz dan i čuva oči, bubrege, živce i srce.",
          "Male svakodnevne navike, poput polovice tanjura povrća i šetnje nakon obroka, smanjuju rizik.",
        ],
        recommendations: [
          {
            title: "Uravnoteži tanjur",
            description:
              "Napuni polovicu tanjura povrćem. Biraj cjeloviti kruh, rižu i tjesteninu.",
          },
          {
            title: "Budi aktivan",
            description:
              "Redovito kretanje pomaže tvom tijelu bolje iskoristiti šećer iz krvi.",
          },
          {
            title: "Obavi krvnu pretragu",
            description:
              "Ako u obitelji imaš dijabetes ili druge čimbenike rizika, zatraži od liječnika analizu krvi.",
          },
        ],
        warningSigns: [
          "Jaka žeđ ili mokrenje češće nego inače.",
          "Gubitak težine bez namjere ili stalni umor.",
          "Zamućen vid ili rane koje sporo cijele.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Zdrava prehrana",
        description:
          "Povoljna i jednostavna hrana za svaki dan.",
        intro:
          "Zdrava prehrana ne mora biti komplicirana ni skupa. Nekoliko jednostavnih pravila iz dana u dan daje tvom tijelu sve što mu treba.",
        keyFacts: [
          "Vlakna iz povrća i cjelovitih žitarica drže šećer u krvi i krvni tlak stabilnima.",
          "Jednostavna hrana kuhana kod kuće daje ti ravnomjernu energiju i sprječava umor nakon jela.",
          "Sezonsko povrće, grah i leća povoljni su, a pijenje vode umjesto slatkih sokova pomaže odmah.",
        ],
        recommendations: [
          {
            title: "Više povrća i voća",
            description:
              "Dodaj povrće ili voće u većinu obroka. Svježe i smrznuto jednako su dobri.",
          },
          {
            title: "Kuhaj kod kuće",
            description:
              "Biraj cjelovite žitarice i obroke kuhane kod kuće umjesto gotove hrane kad god možeš.",
          },
          {
            title: "Pij vodu",
            description:
              "Neka ti voda bude glavno piće. Smanji zaslađene napitke i voćne sokove.",
          },
        ],
        warningSigns: [
          "Naglo mršavljenje ili debljanje bez jasnog razloga.",
          "Probavne tegobe koje ne prolaze ili gubitak teka.",
          "Slabost, vrtoglavica ili jak umor iako redovito jedeš.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Tjelesna aktivnost",
        description:
          "Jednostavni načini za više kretanja, bez obzira na tvoju kondiciju.",
        intro:
          "Redovito kretanje jedna je od najboljih stvari za tvoje tijelo i um. Ne treba ti teretana. Svakodnevno hodanje se računa.",
        keyFacts: [
          "Kretanje potiče krvotok, jača srce i mišiće te pomaže stanicama iskoristiti šećer u krvi za energiju.",
          "Redovita aktivnost daje ti više energije, dublji san noću te bolju ravnotežu i pokretljivost.",
          "Ne treba ti teretana: ustani sa stolca svaki sat i hodaj 15–30 minuta većinu dana.",
        ],
        recommendations: [
          {
            title: "Kreni polako",
            description:
              "Započni kratkim šetnjama ili aktivnošću koja ti prija. Svaki tjedan dodaj malo više.",
          },
          {
            title: "Kreći se redovito",
            description:
              "Malo kretanja većinu dana pomaže više nego naporan trening tu i tamo.",
          },
          {
            title: "Jačaj mišiće",
            description:
              "Radi poslove koji uključuju mišiće, poput nošenja vrećica, rada u vrtu ili čučnjeva.",
          },
        ],
        warningSigns: [
          "Bol u prsima, vrtoglavica ili neobičan nedostatak zraka pri naporu.",
          "Bol ili oticanje zglobova koje se pogoršava pri kretanju.",
          "Osjećaj nesvjestice ili nepravilan rad srca tijekom aktivnosti.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Mentalno zdravlje",
        description:
          "Brini se o svom umu i znaj kada potražiti pomoć.",
        intro:
          "Mentalno zdravlje dio je tvog cjelokupnog zdravlja. Normalno je imati i teža razdoblja te potražiti pomoć kada ti zatreba.",
        keyFacts: [
          "Dugotrajan stres drži tijelo u napetosti, ubrzava puls, grči mišiće i remeti san.",
          "Briga o mentalnom zdravlju donosi mirniji san, bolju koncentraciju i lakše nošenje sa svakodnevnim brigama.",
          "Sporo i duboko disanje, redovito vrijeme spavanja i iskren razgovor s bliskom osobom brzo smiruju tijelo.",
        ],
        recommendations: [
          {
            title: "Ostani povezan",
            description:
              "Provodi vrijeme s ljudima kojima vjeruješ. Bliskost s drugima čuva tvoj um.",
          },
          {
            title: "Pazi na osnove",
            description:
              "San, kretanje i boravak na svježem zraku pomažu ti da se osjećaš bolje.",
          },
          {
            title: "Zatraži pomoć",
            description:
              "Ako ti postane preteško, razgovaraj s osobom od povjerenja ili s liječnikom.",
          },
        ],
        warningSigns: [
          "Tuga, tjeskoba ili osjećaj beznađa koji traju tjednima.",
          "Teško se nosiš sa svakodnevnim obvezama, poslom ili odnosima s bližnjima.",
          "Misli o samoozljeđivanju. Ako se to dogodi, odmah potraži pomoć.",
        ],
      },
      {
        slug: "smoking",
        title: "Prestanak pušenja",
        description:
          "Zašto se isplati prestati pušiti i što ti olakšava.",
        intro:
          "Prestanak pušenja jedna je od najboljih odluka za tvoje zdravlje. Tijelo se počinje brzo oporavljati. Većina ljudi pokuša više puta prije nego što potpuno prestane.",
        keyFacts: [
          "Već nekoliko sati nakon zadnje cigarete raste razina kisika u krvi, žile se opuštaju i pluća se počinju čistiti.",
          "Kako se pluća i krvotok oporavljaju, lakše dišeš na stepenicama, manje kašlješ i vraćaju ti se okus i miris.",
          "Odabir datuma prestanka, čekanje da prođu 3 minute želje za cigaretom i podrška liječnika udvostručuju šanse za uspjeh.",
        ],
        recommendations: [
          {
            title: "Odaberi dan prestanka",
            description:
              "Odredi datum i reci bliskim ljudima. Unaprijed isplaniraj što ćeš učiniti kada te uhvati želja.",
          },
          {
            title: "Potraži podršku",
            description:
              "Savjetovališta za nepušenje i odobrena pomagala povećavaju šansu da ostaneš nepušač.",
          },
          {
            title: "Nemoj odustati",
            description:
              "Ako ponovno zapališ, nemoj odustati. Nauči iz toga i pokušaj ponovno.",
          },
        ],
        warningSigns: [
          "Kašalj koji ne prolazi ili promjena dugotrajnog kašlja.",
          "Iskašljavanje krvi ili bol u prsima koja ne prolazi.",
          "Sve češći nedostatak zraka pri uobičajenim dnevnim poslovima.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Preventivni pregledi",
        description:
          "Pretrage koje otkrivaju probleme rano, prije prvih znakova.",
        intro:
          "Preventivni pregledi traže prve znakove bolesti dok se još osjećaš sasvim dobro. Rano otkrivene bolesti lakše se liječe.",
        keyFacts: [
          "Mnoge bolesti, poput visokog tlaka, dijabetesa ili ranih stadija raka, počinju tiho u tijelu mnogo prije boli.",
          "Čak i kada se svaki dan osjećaš dobro, redoviti pregled donosi mir i otkriva promjene dok je liječenje jednostavno.",
          "Pitaj svog obiteljskog liječnika koje besplatne HZZO preventivne preglede i nacionalne programe probira možeš obaviti ove godine.",
        ],
        recommendations: [
          {
            title: "Pitaj što ti treba",
            description:
              "Pitaj obiteljskog liječnika koji su pregledi preporučeni za tvoju dob i zdravlje.",
          },
          {
            title: "Odazovi se na preglede",
            description:
              "Odazovi se pozivima na nacionalne preventivne programe i redovite kontrole.",
          },
          {
            title: "Podijeli obiteljsku povijest",
            description:
              "Reci liječniku od kojih su bolesti bolovali tvoji roditelji, braća, sestre ili bake i djedovi.",
          },
        ],
        warningSigns: [
          "Nova kvržica, neobično krvarenje ili madež koji mijenja oblik ili boju.",
          "Svaki novi simptom koji ne prolazi i nema jasan uzrok.",
          "Nalaz probira koji traži dodatne pretrage. Nemoj čekati.",
        ],
      },
      {
        slug: "womens-health",
        title: "Zdravlje žena",
        description:
          "Tvoje zdravlje u svakoj dobi, od menstruacije do menopauze.",
        intro:
          "Zdravstvene potrebe žena mijenjaju se kroz život, od menstruacije i trudnoće do menopauze i kasnijih godina. Kada poznaješ svoje tijelo, lakše primijetiš promjene.",
        keyFacts: [
          "Žensko tijelo prolazi kroz prirodne hormonske promjene od menstruacije i trudnoće do menopauze, što utječe na kosti, srce i raspoloženje.",
          "Kada znaš što je za tebe uobičajeno, na vrijeme uočavaš promjene na dojkama, neobično krvarenje ili trajnu bol u zdjelici.",
          "Redoviti Papa-test, mjesečni samopregled dojki i redovite kontrole u trudnoći otkrivaju tegobe rano, kada se najlakše liječe.",
        ],
        recommendations: [
          {
            title: "Upoznaj svoje tijelo",
            description:
              "Prati svoj uobičajeni ciklus i tijelo kako bi lakše uočila promjene.",
          },
          {
            title: "Idi na redovite preglede",
            description:
              "Obavljaj ginekološke preglede i probire preporučene za tvoju dob.",
          },
          {
            title: "Potraži pomoć na vrijeme",
            description:
              "Razgovaraj s liječnikom o svakom simptomu koji te zabrinjava.",
          },
        ],
        warningSigns: [
          "Neobično krvarenje između menstruacija ili nakon menopauze.",
          "Jaka ili dugotrajna bol u donjem dijelu trbuha ili zdjelici.",
          "Nova promjena na dojci, poput kvržice, uvlačenja ili promjene na koži.",
        ],
      },
    ],
  },
  rom: {
    labels: {
      allTopics:
        "Savore sastipnaske sikavimata",
      whyItMatters:
        "Sostar si vazhno",
      practicalSteps:
        "So shaj te keres",
      seekAdviceTitle:
        "Kana te dzhas ko doktori",
      seekAdviceBody:
        "Dzha ko doktori te dikhes varesavo katar akala semnja. Kana si sigardiari, akhar sigo 112.",
      relatedTopics:
        "Aver sikavimata",
      readMore:
        "Drabar maj but",
      disclaimer:
        "Akala informacije naj dijagnoza. Vash tiro sastipen, de duma e doktoresa.",
    },
    topics: [
      {
        slug: "heart-health",
        title: "Sastipen e ilesko",
        description:
          "Sako-diveske tabijetura save arakhen tiro ilo thaj tiri tensija.",
        intro:
          "Tiro ilo bičhalel o rat ando sasto trupo sako minuta. Kana arakhes les, tiknjarel pes o riziko vash nasvalipena e ileske thaj dab ki godi.",
        keyFacts: [
          "Kana o rat phurdel zurales thaj o kolesterolo si ucho, von lokhes khinjaren e arterije thaj o ilo bershencar bi semnjengo.",
          "Zuralo ilo thaj normalno tensija den tut maj bari zor, maj lokho phurdinimos thaj maj cikno riziko vash dab ki godi.",
          "Maj xanci lon ando xaben, sigo phirimos sako dives thaj redovno merimos e tensijako arakhen tiro ilo.",
        ],
        recommendations: [
          {
            title: "Phir maj but dive",
            description:
              "Phir sigo vaj ker buchi savi plachal tut. Vi e cikne phirimata ginaven pes.",
          },
          {
            title: "Xa mishto vash tiro ilo",
            description:
              "Xa maj but zelenimata, frute thaj integralno manro. Čhiv maj xanci lon thaj xa maj xanci gata xaben.",
          },
          {
            title: "Dikh tire numere",
            description:
              "Merisar redovno i tensija thaj o kolesterolo. E problemura sastjaren pes maj lokhes kana arakhen pes rano.",
          },
        ],
        warningSigns: [
          "Dukh vaj tasavimos ko kolin, maj but te dzhal ko vast, ki kor vaj ki pashni.",
          "Sigo phari phurdinimos, vaj ilo so marel sigo thaj bi ritmosko.",
          "Khino savo na nakhel vaj shuvljarde punre.",
        ],
      },
      {
        slug: "diabetes",
        title: "Dijabeto",
        description:
          "So barjarel o riziko thaj sar te inkeres o gudlo rat ando balanso.",
        intro:
          "O dijabeto paruvel sar tiro trupo labyarel o zahari ando rat. Lačhe azhutimasa shaj te arakhes tut lestar vaj te trais mishto lesa.",
        keyFacts: [
          "Ko dijabeto tip 2, o zahari ačhel ando rat namesto te del ande celije, thaj shaj bershencar lokhes te dukhavel e rateske droma.",
          "Kana inkeres o gudlo rat ando balanso, si tut zor sasto dives thaj arakhes tire jakha, bobrege, nervura thaj o ilo.",
          "Cikne sako-diveske tabijetura, sar dopash charo zelenimasa thaj phirimos pala o xaben, tiknjaren o riziko.",
        ],
        recommendations: [
          {
            title: "Balansirisar o charo",
            description:
              "Pher dopash charo zelenimasa. Alosar integralno manro, rizo thaj makarone.",
          },
          {
            title: "Ačhov aktivno",
            description:
              "Redovno phirimos azhutil tiro trupo maj mishto te labyarel o zahari katar o rat.",
          },
          {
            title: "Ker rengro dikhiben",
            description:
              "Te si dijabeto andi familija vaj aver riziko, mang katar o doktori jekh rengro dikhiben.",
          },
        ],
        warningSigns: [
          "Bari trush vaj butivar phirimos ko toaleto.",
          "Xasares kile bi te manges vaj san sajekh khino.",
          "Kalo dikhiben vaj rane save sastjon lokhes.",
        ],
      },
      {
        slug: "healthy-eating",
        title: "Sasto xaben",
        description:
          "Ieftino thaj lokho xaben vash sako dives.",
        intro:
          "Te xas sasto na musaj te avel pharo vaj kuč. Xanci lokhe pravila sako dives den tire truposke so trubul leske.",
        keyFacts: [
          "E vlakne katar e zelenimata thaj integralno giv inkeren o gudlo rat thaj i tensija ando balanso.",
          "Lokho xaben kirado khere del tut zor sasto dives thaj arakhel tut katar khino pala o xaben.",
          "Zelenimata e sezonake, o fusuj thaj i leča si ieftine, thaj o pani namesto gudle pimatja azhutil sigo.",
        ],
        recommendations: [
          {
            title: "Maj but zelenimata thaj frute",
            description:
              "Čhiv zelenimata vaj frute ko maj but xabena. Neve vaj shudrarde si solduj lačhe.",
          },
          {
            title: "Kirav khere",
            description:
              "Alosar integralno manro thaj xaben kirado khere kana shaj.",
          },
          {
            title: "Pi pani",
            description:
              "Mukh o pani te avel tiro angluno pimos. Pi so maj xanci gudle sokura.",
          },
        ],
        warningSigns: [
          "Xasares vaj čhives but kile ande cikni vrjama.",
          "Problemura e poresa save na nakhen vaj xasarimos e bokhako.",
          "Slabipen, o shero phirel vaj baro khino vi kana xas.",
        ],
      },
      {
        slug: "physical-activity",
        title: "Fizikani aktivnost",
        description:
          "Lokhe droma te phires maj but, savi godi te avel tiri zor.",
        intro:
          "Te phires maj but si jekh katar e maj lačhe bukja vash tiro trupo thaj godi. Na trubul tut sala. Sako phirimos ginavel pes.",
        keyFacts: [
          "O phirimos mukhel o rat te phirel, zurarel o ilo thaj e muskulura, thaj azhutil e celijen te labyaren o zahari.",
          "Redovno phirimos del tut maj but zor, maj lačho sovibe ratjate thaj maj lačho balanso.",
          "Na trubul tut sala: ushti katar o skamin sako ora thaj phir 15–30 minute ko maj but dive.",
        ],
        recommendations: [
          {
            title: "Astar ciknes",
            description:
              "Astar cikne phirimasa. Ker zalog maj but sako kurko.",
          },
          {
            title: "Phir redovno",
            description:
              "Zalog phirimos sako dives azhutil maj but katar baro khinimos varekana.",
          },
          {
            title: "Zurar e muskulura",
            description:
              "Inger gono, ker buchi andi barcha vaj ker lokhe vjezhbe.",
          },
        ],
        warningSigns: [
          "Dukh ko kolin, o shero phirel vaj phari phurdinimos kana phires.",
          "Dukh vaj shuvljarimos ko globura savo barjol kana phires.",
          "Hatjares kaj peres vaj o ilo marel bi ritmosko kana keres vjezhbe.",
        ],
      },
      {
        slug: "mental-wellbeing",
        title: "Sastipen e godjako",
        description:
          "Arakh tiri godi thaj dzhan kana te manges azhutimos.",
        intro:
          "O sastipen e godjako si kotor katar tiro sastipen. Sako manush nakhavel vi lačhe vi phare dive. Normalno si te manges azhutimos.",
        keyFacts: [
          "Lungo streso inkerel o trupo phanglo, sigjarel o pulso, tasavel e muskulura thaj phagel o sovibe.",
          "Kana arakhes tiri godi, soves maj mirno, dikhes maj mishto tiri buchi thaj ačhes pasha tire manusha.",
          "Lokho thaj xor phurdinimos, redovno vrjama vash sovibe thaj putardi duma jekhe manushesa kaste pakjas lokhjaren o trupo.",
        ],
        recommendations: [
          {
            title: "Ačhov pasha e manusha",
            description:
              "Nakhar vrjama manushenca kaste pakjas. Te aves pasha avera arakhel tiri godi.",
          },
          {
            title: "Arakh e anglune bukja",
            description:
              "O sovibe, o phirimos thaj i vrjama avri azhutin tut te hatjares tut maj mishto.",
          },
          {
            title: "Mang azhutimos",
            description:
              "Te avel tuke but phares, de duma jekhe manushesa kaste pakjas vaj jekhe doktoresa.",
          },
        ],
        warningSigns: [
          "Brigipe, dar vaj bi-nadako hatjarimos savo ačhel kurkencar.",
          "Phares ikljos ko kraj sako-diveske bukjenca, khere vaj avere manushenca.",
          "Gindura te keres tuke nasul. Te avel akava, mang azhutimos sigo.",
        ],
      },
      {
        slug: "smoking",
        title: "Mukhimos e thuvjarimasko",
        description:
          "Sostar vazhil te mukhes e cigare thaj so azhutil tut.",
        intro:
          "Te mukhes o thuvjarimos si jekh katar e maj lačhe bukja vash tiro sastipen. Tiro trupo astarel sigo te sastjovel.",
        keyFacts: [
          "Ande anglune ore pala i palutni cigara, o oksigeno ando rat vazdel pes, e rateske droma lokhjon thaj e phuka astaren te uzhon.",
          "Sar sastjol o trupo, phurdines maj lokhes pe skale, xasaves maj xanci thaj irinel pes o vkus thaj o khandimos.",
          "Te alosares dives kana ačhaves, te azhukeres te nakhen e 3 minute mangimaske thaj te manges azhutimos katar o doktori, dujvar barjarel tire shanse.",
        ],
        recommendations: [
          {
            title: "Alosar jekh dives",
            description:
              "Alosar o dives kana mukhes e cigare thaj phen e manushenge kaste pakjas.",
          },
          {
            title: "Mang azhutimos",
            description:
              "Programura thaj draba vash mukhimos e thuvjarimasko azhutin te ačhes bi cigarengo.",
          },
          {
            title: "Ma mukh tut",
            description:
              "Te thuvjardjan pale, ma mukh tut. Sikljo katar kodo thaj probin pale.",
          },
        ],
        warningSigns: [
          "Xasavimos savo na nakhel vaj paruvimos ko purano xasavimos.",
          "Xasavimos ratesa vaj dukh ko kolin savi na nakhel.",
          "Sako dives maj but ačhes bi balvaljako ko lokhe bukja.",
        ],
      },
      {
        slug: "preventive-screening",
        title: "Preventivno dikhiben",
        description:
          "Dikhibena save arakhen problemura rano, anglal e semnja.",
        intro:
          "O preventivno dikhiben rodel e anglune semnja e nasvalipnaske anglal te dukhal tut vareso. Problemura arakhle rano sastjaren pes maj lokhes.",
        keyFacts: [
          "But nasvalipena, sar uchi tensija, dijabeto vaj varesave kancerura, astaren mirno ando trupo but anglal te dukhan.",
          "Vi kana hatjares tut zuralo sako dives, jekh redovno dikhiben del tut mir thaj arakhel e paruvimata kana sastjaren pes lokhes.",
          "Phuch tire familijake doktores save bi-loveske dikhibena thaj rengre dikhibena shaj te keres akava bersh.",
        ],
        recommendations: [
          {
            title: "Phuch so trubul tuke",
            description:
              "Phuch tire doktores save dikhibena si lačhe vash tiri vrjama thaj sastipen.",
          },
          {
            title: "Dzha ko dikhibena",
            description:
              "Dzha kana akharen tut ko preventivno dikhiben thaj ko redovne kontrole.",
          },
          {
            title: "Phen vash e nasvalipena andi familija",
            description:
              "Phen e doktoreske save nasvalipena sas tire daja, dades, phralen vaj papon.",
          },
        ],
        warningSigns: [
          "Nevi guka, neobicno ratjarimos vaj mladezho savo paruvel forma vaj boja.",
          "Sako nevo semno savo na nakhel thaj na dzhanes katar avel.",
          "Rezultato katar o dikhiben savo mangel te aves pale. Ma azhuker.",
        ],
      },
      {
        slug: "womens-health",
        title: "Sastipen e dzhuvljako",
        description:
          "Tiro sastipen ki sako vrjama, katar o ciklo dzhi ki menopauza.",
        intro:
          "E trubujimata vash sastipen e dzhuvljako paruven pes ando trajo, katar o ciklo thaj i khabni romni dzhi ki menopauza. Kana dzhanes so si normalno vash tute, dikhes sigo kana vareso paruvel pes.",
        keyFacts: [
          "O trupo e dzhuvljako nakhel katar prirodne paruvimata e hormonenge, katar o ciklo thaj khabnipen dzhi ki menopauza.",
          "Kana pinzhares tiro trupo, dikhes rano sako paruvimos ki chuchi, neobicno ratjarimos vaj dukh savi na nakhel.",
          "Redovno Pap-testi, sako-chonesko dikhiben e chuchjengo thaj kontrole kana i romni si khabni arakhen e problemura rano.",
        ],
        recommendations: [
          {
            title: "Pinzhar tiro trupo",
            description:
              "Dikh tiro obicno ciklo thaj trupo, kaj te dikhes sigo e paruvimata.",
          },
          {
            title: "Dzha ko kontrole",
            description:
              "Dzha ko dikhibena save si phende vash tiri vrjama.",
          },
          {
            title: "Mang azhutimos rano",
            description:
              "De duma e doktoresa vash sako semno savo daravel tut.",
          },
        ],
        warningSigns: [
          "Neobicno ratjarimos mashkar e ciklura vaj pala i menopauza.",
          "Zurali vaj lungi dukh telal ando por.",
          "Nevo paruvimos ki chuchi, sar guka vaj paruvimos pe morti.",
        ],
      },
    ],
  },
};

export function getHealthInformationDictionary(lang: Lang) {
  return dictionaries[lang] || dictionaries.en;
}

export function getHealthTopicBySlug(lang: Lang, slug: string) {
  return getHealthInformationDictionary(lang).topics.find((topic) => topic.slug === slug);
}

export const healthTopicSlugs = dictionaries.en.topics.map((topic) => topic.slug);

export interface TopicItem {
  slug: string;
  categorySlug: string;
  title: string;
  description: string;
  image: string;
  keyFact?: string;
  recommendationTitle?: string;
  recommendationBody?: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  readMinutes: number;
  audioMinutes: number;
}

export const HEALTH_TOPIC_CARD_SUMMARIES: Record<
  Lang,
  Record<string, { title: string; description: string }>
> = {
  ru: {
    "heart-health": {
      title: "Здоровье сердца",
      description:
        "Простые привычки для здорового давления и крепкого сердца.",
    },
    diabetes: {
      title: "Профилактика диабета",
      description:
        "Ранние признаки и как держать сахар в крови в норме.",
    },
    "healthy-eating": {
      title: "Здоровое питание",
      description:
        "Простая и сытная еда с меньшим количеством соли и сахара.",
    },
    "physical-activity": {
      title: "Физическая активность",
      description:
        "Как больше двигаться каждый день в любом возрасте без спортзала.",
    },
    "mental-wellbeing": {
      title: "Психическое здоровье",
      description:
        "Как заметить затяжной стресс и тревогу и где найти бесплатную помощь.",
    },
    smoking: {
      title: "Отказ от курения",
      description:
        "Как бросить курить и кто может вам помочь.",
    },
    "preventive-screening": {
      title: "Проверка здоровья",
      description:
        "Бесплатные осмотры, которые находят болезнь раньше, чем появятся боли.",
    },
    "womens-health": {
      title: "Женское здоровье",
      description:
        "Беременность, осмотры у гинеколога и что нормально в каждом возрасте.",
    },
  },

  ro: {
    "heart-health": {
      title: "Sănătatea inimii",
      description:
        "Obiceiuri simple pentru o tensiune bună și o inimă puternică.",
    },
    diabetes: {
      title: "Prevenția diabetului",
      description:
        "Primele semne și cum ții zahărul din sânge sub control.",
    },
    "healthy-eating": {
      title: "Alimentație sănătoasă",
      description:
        "Mese sățioase și ieftine, cu mai puțină sare și zahăr.",
    },
    "physical-activity": {
      title: "Activitate fizică",
      description:
        "Cum te miști mai mult zilnic, la orice vârstă, fără sală.",
    },
    "mental-wellbeing": {
      title: "Echilibru emoțional",
      description:
        "Recunoaște stresul și grijile care nu trec și găsește ajutor gratuit.",
    },
    smoking: {
      title: "Renunțarea la fumat",
      description:
        "Cum te lași de fumat și cine te poate ajuta.",
    },
    "preventive-screening": {
      title: "Screening preventiv",
      description:
        "Controale gratuite care găsesc bolile devreme, înainte să doară.",
    },
    "womens-health": {
      title: "Sănătatea femeii",
      description:
        "Sarcina, controlul ginecologic și ce e normal la fiecare vârstă.",
    },
  },
  en: {
    "heart-health": {
      title: "Heart health",
      description:
        "Simple habits for healthy blood pressure and a strong heart.",
    },
    diabetes: {
      title: "Diabetes prevention",
      description:
        "Early signs and how to keep your blood sugar steady.",
    },
    "healthy-eating": {
      title: "Healthy eating",
      description:
        "Low-cost, filling meals with less salt and sugar.",
    },
    "physical-activity": {
      title: "Physical activity",
      description:
        "Ways to move more every day, at any age, without a gym.",
    },
    "mental-wellbeing": {
      title: "Mental health",
      description:
        "Spot stress and worry that stay too long, and find free help.",
    },
    smoking: {
      title: "Quitting smoking",
      description:
        "How to stop smoking and who can help you.",
    },
    "preventive-screening": {
      title: "Health screening",
      description:
        "Free check-ups that catch illness early, before it hurts.",
    },
    "womens-health": {
      title: "Women's health",
      description:
        "Pregnancy, gynaecologist visits and what is normal at each age.",
    },
  },
  sq: {
    "heart-health": {
      title: "Shëndeti i zemrës",
      description:
        "Zakone të thjeshta për tension normal dhe zemër të fortë.",
    },
    diabetes: {
      title: "Parandalimi i diabetit",
      description:
        "Shenjat e para dhe si ta mbash sheqerin nën kontroll.",
    },
    "healthy-eating": {
      title: "Ushqyerja e shëndetshme",
      description:
        "Vakte të lira e të shëndetshme, me më pak kripë e sheqer.",
    },
    "physical-activity": {
      title: "Aktiviteti fizik",
      description:
        "Si të lëvizësh më shumë çdo ditë, në çdo moshë, pa palestër.",
    },
    "mental-wellbeing": {
      title: "Ekuilibri emocional",
      description:
        "Njih stresin dhe ankthin që zgjatin dhe gjej ndihmë falas.",
    },
    smoking: {
      title: "Lënia e duhanit",
      description:
        "Si ta lësh duhanin dhe kush mund të të ndihmojë.",
    },
    "preventive-screening": {
      title: "Kontrollet parandaluese",
      description:
        "Kontrolle falas që zbulojnë sëmundjet herët, para dhimbjes.",
    },
    "womens-health": {
      title: "Shëndeti i gruas",
      description:
        "Shtatzënia, vizitat te gjinekologu dhe çfarë është normale në çdo moshë.",
    },
  },
  it: {
    "heart-health": {
      title: "Salute del cuore",
      description:
        "Abitudini semplici per pressione regolare e cuore forte.",
    },
    diabetes: {
      title: "Prevenzione del diabete",
      description:
        "I primi segnali e come tenere stabile lo zucchero nel sangue.",
    },
    "healthy-eating": {
      title: "Alimentazione sana",
      description:
        "Pasti economici e sazianti, con meno sale e zucchero.",
    },
    "physical-activity": {
      title: "Attività fisica",
      description:
        "Come muoverti di più ogni giorno, a ogni età, senza palestra.",
    },
    "mental-wellbeing": {
      title: "Equilibrio emotivo",
      description:
        "Riconosci stress e ansia che non passano e trova aiuto gratuito.",
    },
    smoking: {
      title: "Smettere di fumare",
      description:
        "Come smettere di fumare e chi può aiutarti.",
    },
    "preventive-screening": {
      title: "Screening preventivo",
      description:
        "Controlli gratuiti per scoprire i problemi presto, prima del dolore.",
    },
    "womens-health": {
      title: "Salute della donna",
      description:
        "Gravidanza, visite ginecologiche e cosa è normale a ogni età.",
    },
  },
  hr: {
    "heart-health": {
      title: "Zdravlje srca",
      description:
        "Jednostavne navike za zdrav tlak i snažno srce.",
    },
    diabetes: {
      title: "Prevencija dijabetesa",
      description:
        "Rani znakovi i kako držati šećer u krvi stabilnim.",
    },
    "healthy-eating": {
      title: "Zdrava prehrana",
      description:
        "Povoljni i zasitni obroci s manje soli i šećera.",
    },
    "physical-activity": {
      title: "Tjelesna aktivnost",
      description:
        "Kako se kretati više svaki dan, u svakoj dobi, bez teretane.",
    },
    "mental-wellbeing": {
      title: "Mentalno zdravlje",
      description:
        "Prepoznaj stres i brige koje ne prolaze i pronađi besplatnu pomoć.",
    },
    smoking: {
      title: "Prestanak pušenja",
      description:
        "Kako prestati pušiti i tko ti može pomoći.",
    },
    "preventive-screening": {
      title: "Preventivni pregledi",
      description:
        "Besplatni pregledi koji otkrivaju bolesti rano, prije boli.",
    },
    "womens-health": {
      title: "Zdravlje žena",
      description:
        "Trudnoća, ginekološki pregledi i što je normalno u svakoj dobi.",
    },
  },
  rom: {
    "heart-health": {
      title: "Sastipen e ilesko",
      description:
        "Lokhe tabijetura vash normalno tensija thaj zuralo ilo.",
    },
    diabetes: {
      title: "Arakhimos katar o dijabeto",
      description:
        "Anglune semnja thaj sar te inkeres o gudlo rat ando balanso.",
    },
    "healthy-eating": {
      title: "Sasto xaben",
      description:
        "Ieftino thaj čaljardo xaben maj xanci lonesa thaj zaharosa.",
    },
    "physical-activity": {
      title: "Fizikani aktivnost",
      description:
        "Sar te phires maj but sako dives, ki sako vrjama, bi salako.",
    },
    "mental-wellbeing": {
      title: "Sastipen e godjako",
      description:
        "Pinzhar o streso thaj e brige save na nakhen thaj arakh bi-lovesko azhutimos.",
    },
    smoking: {
      title: "Mukhimos e thuvjarimasko",
      description:
        "Sar te mukhes e cigare thaj kon shaj te azhutil tut.",
    },
    "preventive-screening": {
      title: "Preventivno dikhiben",
      description:
        "Bi-loveske dikhibena save arakhen nasvalipena rano, anglal te dukhal.",
    },
    "womens-health": {
      title: "Sastipen e dzhuvljako",
      description:
        "Khabnipen, dikhiben ko ginekologo thaj so si normalno ki sako vrjama.",
    },
  },
};

export const HEALTH_TOPICS_BASE = [
  { slug: "heart-health", categorySlug: "inima", readMinutes: 3, audioMinutes: 2 },
  { slug: "diabetes", categorySlug: "diabet", readMinutes: 4, audioMinutes: 3 },
  { slug: "healthy-eating", categorySlug: "nutritie", readMinutes: 3, audioMinutes: 2 },
  { slug: "physical-activity", categorySlug: "miscare", readMinutes: 2, audioMinutes: 2 },
  { slug: "mental-wellbeing", categorySlug: "minte", readMinutes: 4, audioMinutes: 3 },
  { slug: "smoking", categorySlug: "fumat", readMinutes: 3, audioMinutes: 2 },
  { slug: "preventive-screening", categorySlug: "screening", readMinutes: 3, audioMinutes: 2 },
  { slug: "womens-health", categorySlug: "femei", readMinutes: 4, audioMinutes: 3 },
];

const TOPIC_ICONS: Record<string, ComponentType<SVGProps<SVGSVGElement>>> = {
  "heart-health": HeartIcon,
  diabetes: DropletIcon,
  "healthy-eating": AppleIcon,
  "physical-activity": ActivityIcon,
  "mental-wellbeing": BrainIcon,
  smoking: NoSmokingIcon,
  "preventive-screening": SearchIcon,
  "womens-health": ShieldIcon,
};

const TOPIC_KEY_FACT_INDEX: Record<string, number> = {
  "heart-health": 0,
  diabetes: 0,
  "healthy-eating": 1,
  "physical-activity": 1,
  "mental-wellbeing": 1,
  smoking: 0,
  "preventive-screening": 0,
  "womens-health": 0,
};

export function getHealthTopicsList(lang: Lang = "ro"): TopicItem[] {
  const summaries = HEALTH_TOPIC_CARD_SUMMARIES[lang] || HEALTH_TOPIC_CARD_SUMMARIES.ro;
  const fullDict = getHealthInformationDictionary(lang);
  return HEALTH_TOPICS_BASE.map((base) => {
    const fullTopic = fullDict.topics.find((t) => t.slug === base.slug);
    const factIdx = TOPIC_KEY_FACT_INDEX[base.slug] ?? 0;
    const firstRec = fullTopic?.recommendations?.[0];
    return {
      ...base,
      title: summaries[base.slug]?.title ?? base.slug,
      description: summaries[base.slug]?.description ?? "",
      image:
        base.slug === "heart-health"
          ? "/images/health-topics/heart-health-care.jpg"
          : `/images/health-topics/${base.slug}.jpg`,
      keyFact: fullTopic?.keyFacts?.[factIdx] ?? fullTopic?.keyFacts?.[0] ?? "",
      recommendationTitle: firstRec?.title ?? "",
      recommendationBody: firstRec?.description ?? "",
      icon: TOPIC_ICONS[base.slug] ?? HeartIcon,
    };
  });
}

export const HEALTH_TOPICS_LIST: TopicItem[] = getHealthTopicsList("ro");

export function getHealthTopicGridDictionary(lang: Lang) {
  return (
    translations[lang]?.healthInfoPage?.topicGrid ??
    translations.ro.healthInfoPage.topicGrid!
  );
}
