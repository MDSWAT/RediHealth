import { NextResponse } from "next/server";
import { logActivity } from "@/lib/activity-log";
import { getControlDatabase } from "@/lib/database";
import { SUPPORTED_COUNTRIES, isSupportedCountry } from "@/lib/medical-institutes";
import { importCountryFromOsm } from "@/lib/osm-import";
import { getClientIp } from "@/lib/rate-limit";
import { requireSuperAdmin } from "@/lib/super-admin";

// Importing a whole country from OpenStreetMap can take a few minutes (Italy is the largest).
export const maxDuration = 300;

export async function POST(request: Request) {
  const access = await requireSuperAdmin();
  if ("error" in access) return access.error;

  const body = (await request.json().catch(() => null)) as { country?: unknown } | null;
  const country = typeof body?.country === "string" ? body.country.toUpperCase() : "";
  if (!isSupportedCountry(country)) {
    return NextResponse.json({ error: `Country must be one of ${SUPPORTED_COUNTRIES.join(", ")}.` }, { status: 400 });
  }
  if (country !== access.worker.country) {
    return NextResponse.json({ error: "You can only import institutes for your own country." }, { status: 403 });
  }

  try {
    const result = await importCountryFromOsm(getControlDatabase(), country);
    await logActivity({
      country: access.worker.country,
      actorWorkerId: access.worker.workerId,
      actorName: access.worker.workerName,
      actorEmail: access.email,
      actorRole: access.worker.role,
      action: "medical_institute.osm_import",
      entityType: "medical_institute",
      entityId: country,
      details: result,
      ipAddress: getClientIp(request),
    });
    return NextResponse.json(result);
  } catch (error) {
    console.error("OpenStreetMap import failed", error);
    return NextResponse.json(
      { error: "Import from OpenStreetMap failed. The server may be busy. Try again in a few minutes." },
      { status: 502 },
    );
  }
}
