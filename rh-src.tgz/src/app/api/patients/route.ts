import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { logActivity } from "@/lib/activity-log";
import { getCountryDatabase, isOfflineSyncTransaction, type ResultSetHeader, type RowDataPacket } from "@/lib/database";
import { parseJsonColumn, stringifyJsonColumn } from "@/lib/json";
import {
  PATIENT_LIST_COLUMNS,
  PATIENT_ASSIGNMENT_COLUMNS,
  PATIENT_FROM,
  mapPatientRow,
  type DBPatientRow,
} from "@/lib/data/patients";
import {
  isPatientPriority,
  isPatientStatus,
  validateFollowupList,
  validatePhotoList,
  validateTreatmentPlanInput,
} from "@/lib/validation";
import type {
  CreatePatientPayload,
  PatientPriority,
  PatientStatus,
  TreatmentPlan,
} from "@/lib/types/patient";
import { getUserWorkerContext } from "@/lib/worker-auth";
import { sendPatientPortalLinkEmail } from "@/lib/email";
import { getRequestLang } from "@/lib/i18n/server-routing";
import { PORTAL_LINK_TTL_DAYS, generatePortalToken, hashPortalToken } from "@/lib/security/portal-token";
import { getClientIp } from "@/lib/rate-limit";
import { isValidEmail, text } from "@/lib/text";
import { encryptField, isEncryptionConfigured } from "@/lib/security/field-encryption";
import { isRomanianCounty } from "@/lib/romanian-counties";
import { validatePatientIntake } from "@/lib/patient-intake";

function isDuplicateEntryError(error: unknown): boolean {
  const dbError = error as { code?: string; errno?: number; sqlState?: string; message?: string };
  return (
    dbError.code === "ER_DUP_ENTRY"
    || dbError.errno === 1062
    || dbError.sqlState === "23000"
    || /duplicate entry/i.test(dbError.message || "")
  );
}

const MAX_CONDITION_NOTES_LENGTH = 20_000;
const MAX_MEDICAL_HISTORY_LENGTH = 15_000;
const MAX_SHORT_FIELD_LENGTH = 50;

function normalizeWorkerIds(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value
    .map((item) => (item == null ? "" : String(item).trim()))
    .filter((item) => item.length > 0))];
}

export async function GET(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  const assignmentView = searchParams.get("view") === "assignment";
  if (assignmentView && !workerContext.isAdmin) {
    return NextResponse.json({ error: "Administrator access is required." }, { status: 403 });
  }
  const statusParam = searchParams.get("status");
  const priorityParam = searchParams.get("priority");
  const workerIdParam = searchParams.get("assigned_worker_id");
  const searchParam = searchParams.get("search")?.trim().toLowerCase();
  const pageParam = searchParams.get("page");
  const limitParam = searchParams.get("limit");

  const page = Math.max(1, Number(pageParam) || 1);
  const limit = Math.min(100, Math.max(10, Number(limitParam) || 50));
  const offset = (page - 1) * limit;

  try {
    const db = getCountryDatabase(workerContext.country);
    let query = `SELECT ${assignmentView ? PATIENT_ASSIGNMENT_COLUMNS : PATIENT_LIST_COLUMNS} ${PATIENT_FROM}`;
    const params: unknown[] = [];
    const conditions: string[] = [];

    // Non-admins may only ever see patients assigned to them.
    if (!workerContext.isAdmin && workerContext.workerId) {
      conditions.push("(p.assigned_worker_id = ? OR FIND_IN_SET(?, REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(p.assigned_worker_ids, '[]'), '[', ''), ']', ''), '\"', ''), ' ', '')) > 0)");
      params.push(workerContext.workerId, workerContext.workerId);
    } else if (workerIdParam && workerIdParam !== "all") {
      if (workerIdParam === "unassigned") {
        conditions.push("(p.assigned_worker_id IS NULL AND (p.assigned_worker_ids IS NULL OR JSON_LENGTH(p.assigned_worker_ids) = 0))");
      } else {
        conditions.push("(p.assigned_worker_id = ? OR FIND_IN_SET(?, REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(p.assigned_worker_ids, '[]'), '[', ''), ']', ''), '\"', ''), ' ', '')) > 0)");
        params.push(workerIdParam, workerIdParam);
      }
    }

    if (statusParam && statusParam !== "all") {
      conditions.push("p.status = ?");
      params.push(statusParam);
    }

    if (priorityParam && priorityParam !== "all") {
      conditions.push("p.priority = ?");
      params.push(priorityParam);
    }

    if (searchParam) {
      conditions.push(
        "(LOWER(p.full_name) LIKE ? OR LOWER(p.email) LIKE ? OR p.phone LIKE ? OR LOWER(p.condition_notes) LIKE ? OR LOWER(w.full_name) LIKE ?)",
      );
      const term = `%${searchParam}%`;
      params.push(term, term, term, term, term);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`;
    }

    // Get total count for pagination
    let totalQuery = `SELECT COUNT(*) as total ${PATIENT_FROM}`;
    const totalParams: unknown[] = [];
    if (conditions.length > 0) {
      totalQuery += ` WHERE ${conditions.join(" AND ")}`;
      totalParams.push(...params);
    }
    const [totalRows] = await db.query<RowDataPacket[]>(totalQuery, totalParams);
    const total = Number(totalRows[0]?.total || 0);

    query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const [rows] = await db.query<DBPatientRow[]>(query, params);
    return NextResponse.json({
      patients: rows.map((row) => mapPatientRow(row, workerContext.country)),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasMore: page * limit < total,
      },
    });
  } catch (error) {
    console.error("Failed to fetch patients", error);
    return NextResponse.json(
      { error: "Could not fetch patients. Ensure migrations 003–007, 012 and 013 are applied." },
      { status: 503 },
    );
  }
}

export async function POST(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  let body: CreatePatientPayload;

  try {
    body = (await request.json()) as CreatePatientPayload;
  } catch {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }
  const intake = validatePatientIntake(body.intake);
  if (!intake.ok) return NextResponse.json({ error: intake.error }, { status: 400 });
  if ((intake.value?.documents.length || intake.value?.location) && !isEncryptionConfigured(workerContext.country)) {
    return NextResponse.json({ error: "Documents and GPS cannot be saved until the country encryption key is set." }, { status: 503 });
  }

  const fullName = text(body.full_name);
  const phone = text(body.phone);
  const email = text(body.email).toLowerCase();
  const dateOfBirth = text(body.date_of_birth);
  const gender = text(body.gender);
  const address = text(body.address);
  const county = workerContext.country === "RO" ? text(body.county) : "";
  const conditionNotes = text(body.condition_notes);
  const medicalHistory = text(body.medical_history);
  const requestId = body.request_id ? String(body.request_id) : null;
  const requestedAssignedWorkerIds = normalizeWorkerIds(body.assigned_worker_ids);
  const requestedAssignedWorkerId = body.assigned_worker_id
    ? String(body.assigned_worker_id)
    : requestedAssignedWorkerIds[0] || null;
  const accessToken = generatePortalToken();
  const accessTokenHash = hashPortalToken(accessToken);

  if (!fullName || !phone || !isValidEmail(email)) {
    return NextResponse.json(
      { error: "Enter the patient's name, phone and a valid email." },
      { status: 400 },
    );
  }

  if (workerContext.country === "RO" && !isRomanianCounty(county)) {
    return NextResponse.json({ error: "Choose a valid county for the patient." }, { status: 400 });
  }

  if (
    fullName.length > 200 ||
    phone.length > 50 ||
    email.length > 320 ||
    address.length > 500 ||
    dateOfBirth.length > MAX_SHORT_FIELD_LENGTH ||
    gender.length > MAX_SHORT_FIELD_LENGTH ||
    conditionNotes.length > MAX_CONDITION_NOTES_LENGTH ||
    medicalHistory.length > MAX_MEDICAL_HISTORY_LENGTH
  ) {
    return NextResponse.json(
      { error: "One or more fields are too long." },
      { status: 400 },
    );
  }

  if (body.status !== undefined && !isPatientStatus(body.status)) {
    return NextResponse.json({ error: "Invalid patient status." }, { status: 400 });
  }
  if (body.priority !== undefined && !isPatientPriority(body.priority)) {
    return NextResponse.json({ error: "Invalid patient priority." }, { status: 400 });
  }
  const validatedFollowups = body.followups == null ? null : validateFollowupList(body.followups);
  if (validatedFollowups && !validatedFollowups.ok) {
    return NextResponse.json({ error: validatedFollowups.error }, { status: 400 });
  }
  const validatedPhotos = body.photos == null ? null : validatePhotoList(body.photos);
  if (validatedPhotos && !validatedPhotos.ok) {
    return NextResponse.json({ error: validatedPhotos.error }, { status: 400 });
  }

  if (!workerContext.isAdmin) {
    const assignsOtherWorker =
      (requestedAssignedWorkerId && requestedAssignedWorkerId !== workerContext.workerId) ||
      requestedAssignedWorkerIds.some((workerId) => workerId !== workerContext.workerId);

    if (assignsOtherWorker) {
      return NextResponse.json(
        { error: "Only administrators can assign patients to other staff." },
        { status: 403 },
      );
    }
  }

  const status: PatientStatus = body.status ?? "active";
  const priority: PatientPriority = body.priority ?? "moderate";
  const validatedTreatment = validateTreatmentPlanInput(body.treatment_plan ?? null);
  if (!validatedTreatment.ok) {
    return NextResponse.json({ error: validatedTreatment.error }, { status: 400 });
  }
  const treatmentPlan = stringifyJsonColumn(validatedTreatment.value);
  const followups = stringifyJsonColumn(validatedFollowups?.value);
  const photos = encryptField(workerContext.country, stringifyJsonColumn(validatedPhotos?.value));
  const assignedWorkerIds = workerContext.isAdmin
    ? requestedAssignedWorkerIds
    : [workerContext.workerId];
  const assignedWorkerId = workerContext.isAdmin
    ? requestedAssignedWorkerId
    : workerContext.workerId;
  let createdPatientId: number | undefined;

  try {
    const db = getCountryDatabase(workerContext.country);
    const [result] = await db.query<ResultSetHeader>(
      `INSERT INTO patients (request_id, assigned_worker_id, assigned_worker_ids, access_token_hash, access_token_expires_at, full_name, phone, email, date_of_birth, gender, address, condition_notes, medical_history, treatment_plan, followups, photos, status, priority, county, intake)
       VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        requestId,
        assignedWorkerId ?? workerContext.workerId,
        stringifyJsonColumn(assignedWorkerIds.length > 0 ? assignedWorkerIds : null),
        accessTokenHash,
        PORTAL_LINK_TTL_DAYS,
        fullName,
        phone,
        email,
        dateOfBirth || null,
        gender || null,
        address || null,
        conditionNotes || null,
        encryptField(workerContext.country, medicalHistory || null),
        treatmentPlan,
        followups,
        photos,
        status,
        priority,
        county || null,
        encryptField(workerContext.country, stringifyJsonColumn(intake.value)),
      ],
    );
    createdPatientId = result.insertId;
  } catch (error) {
    if (isDuplicateEntryError(error)) {
      return NextResponse.json(
        { error: "A patient with this email or portal token already exists." },
        { status: 409 },
      );
    }
    console.error("Failed to create patient profile", error);
    return NextResponse.json(
      { error: "Could not create patient profile. Ensure migrations 001–004, 012 and 013 are applied." },
      { status: 503 },
    );
  }

  await logActivity({
    country: workerContext.country,
    actorWorkerId: workerContext.workerId,
    actorName: workerContext.workerName,
    actorEmail: text(session.user.email),
    actorRole: workerContext.role,
    action: "patient.created",
    entityType: "patient",
    entityId: createdPatientId,
    details: {
      full_name: fullName,
      email,
      status,
      priority,
      assigned_worker_id: assignedWorkerId,
      assigned_worker_ids: assignedWorkerIds,
    },
    ipAddress: getClientIp(request),
  });

  let emailSent = false;
  if (isOfflineSyncTransaction()) {
    return NextResponse.json({ success: true, id: createdPatientId, email_sent: false, warning: "Saved from offline queue. Send the portal invitation separately while online." }, { status: 201 });
  }
  try {
    emailSent = await sendPatientPortalLinkEmail({
      name: fullName,
      email,
      accessToken,
      country: workerContext.country,
      lang: await getRequestLang(request),
      treatmentPlan: parseJsonColumn<TreatmentPlan>(treatmentPlan),
      conditionNotes,
      baseUrl: new URL(request.url).origin,
    });
  } catch (error) {
    console.error("Failed to send patient portal link email", error);
  }

  if (!emailSent) {
    return NextResponse.json(
      {
        success: true,
        id: createdPatientId,
        email_sent: false,
        warning: "Patient was created, but portal email could not be sent.",
      },
      { status: 201 },
    );
  }

  return NextResponse.json(
    { success: true, id: createdPatientId, email_sent: true },
    { status: 201 },
  );
}

export async function PATCH(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  let body: Partial<CreatePatientPayload> & { id?: string | number };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }
  const id = body.id ? String(body.id) : null;
  if (!id) {
    return NextResponse.json({ error: "Patient ID is required." }, { status: 400 });
  }

  if (body.status !== undefined && !isPatientStatus(body.status)) {
    return NextResponse.json({ error: "Invalid patient status." }, { status: 400 });
  }
  if (body.priority !== undefined && !isPatientPriority(body.priority)) {
    return NextResponse.json({ error: "Invalid patient priority." }, { status: 400 });
  }

  const updates: string[] = [];
  const params: unknown[] = [];

  if (body.intake !== undefined) {
    const intake = validatePatientIntake(body.intake);
    if (!intake.ok) return NextResponse.json({ error: intake.error }, { status: 400 });
    if ((intake.value?.documents.length || intake.value?.location) && !isEncryptionConfigured(workerContext.country)) {
      return NextResponse.json({ error: "Documents and GPS cannot be saved until the country encryption key is set." }, { status: 503 });
    }
    updates.push("intake = ?");
    params.push(encryptField(workerContext.country, stringifyJsonColumn(intake.value)));
  }
  if (body.full_name !== undefined) {
    const nextFullName = text(body.full_name);
    if (!nextFullName) {
      return NextResponse.json({ error: "Patient name cannot be empty." }, { status: 400 });
    }
    if (nextFullName.length > 200) {
      return NextResponse.json({ error: "Patient name is too long." }, { status: 400 });
    }
    updates.push("full_name = ?");
    params.push(nextFullName);
  }
  if (body.phone !== undefined) {
    const nextPhone = text(body.phone);
    if (!nextPhone) {
      return NextResponse.json({ error: "Patient phone cannot be empty." }, { status: 400 });
    }
    if (nextPhone.length > 50) {
      return NextResponse.json({ error: "Patient phone is too long." }, { status: 400 });
    }
    updates.push("phone = ?");
    params.push(nextPhone);
  }
  if (body.email !== undefined) {
    const nextEmail = text(body.email).toLowerCase();
    if (!isValidEmail(nextEmail)) {
      return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
    }
    updates.push("email = ?");
    params.push(nextEmail);
  }
  if (body.date_of_birth !== undefined) {
    const nextDateOfBirth = text(body.date_of_birth);
    if (nextDateOfBirth.length > MAX_SHORT_FIELD_LENGTH) {
      return NextResponse.json({ error: "Date of birth is too long." }, { status: 400 });
    }
    updates.push("date_of_birth = ?");
    params.push(nextDateOfBirth || null);
  }
  if (body.gender !== undefined) {
    const nextGender = text(body.gender);
    if (nextGender.length > MAX_SHORT_FIELD_LENGTH) {
      return NextResponse.json({ error: "Gender is too long." }, { status: 400 });
    }
    updates.push("gender = ?");
    params.push(nextGender || null);
  }
  if (body.address !== undefined) {
    const nextAddress = text(body.address);
    if (nextAddress.length > 500) {
      return NextResponse.json({ error: "Patient address is too long." }, { status: 400 });
    }
    updates.push("address = ?");
    params.push(nextAddress || null);
  }
  if (body.county !== undefined) {
    const nextCounty = workerContext.country === "RO" ? text(body.county) : "";
    if (workerContext.country === "RO" && !isRomanianCounty(nextCounty)) {
      return NextResponse.json({ error: "Choose a valid county for the patient." }, { status: 400 });
    }
    updates.push("county = ?");
    params.push(nextCounty || null);
  }
  if (body.condition_notes !== undefined) {
    const nextNotes = text(body.condition_notes);
    if (nextNotes.length > MAX_CONDITION_NOTES_LENGTH) {
      return NextResponse.json({ error: "Condition notes are too long." }, { status: 400 });
    }
    updates.push("condition_notes = ?");
    params.push(nextNotes || null);
  }
  if (body.medical_history !== undefined) {
    const nextHistory = text(body.medical_history);
    if (nextHistory.length > MAX_MEDICAL_HISTORY_LENGTH) {
      return NextResponse.json({ error: "Medical history is too long." }, { status: 400 });
    }
    updates.push("medical_history = ?");
    params.push(encryptField(workerContext.country, nextHistory || null));
  }
  if (body.profile_photo !== undefined) {
    if (body.profile_photo === null || body.profile_photo === "") {
      updates.push("profile_photo = ?");
      params.push(null);
    } else if (typeof body.profile_photo !== "string") {
      return NextResponse.json({ error: "Invalid profile photo." }, { status: 400 });
    } else {
      const imageMatch = /^data:image\/(?:jpeg|png|webp|gif);base64,([A-Za-z0-9+/]+={0,2})$/.exec(body.profile_photo);
      const imageData = imageMatch?.[1];
      const padding = imageData?.endsWith("==") ? 2 : imageData?.endsWith("=") ? 1 : 0;
      const imageBytes = imageData ? Math.floor((imageData.length * 3) / 4) - padding : 0;
      if (!imageData || imageData.length % 4 !== 0 || imageBytes > 5 * 1024 * 1024) {
        return NextResponse.json(
          { error: "Use a PNG, JPEG, GIF or WebP photo up to 5 MB." },
          { status: 400 },
        );
      }
      updates.push("profile_photo = ?");
      params.push(encryptField(workerContext.country, body.profile_photo));
    }
  }
  if (body.treatment_plan !== undefined) {
    const validatedTreatment = validateTreatmentPlanInput(body.treatment_plan);
    if (!validatedTreatment.ok) {
      return NextResponse.json({ error: validatedTreatment.error }, { status: 400 });
    }
    updates.push("treatment_plan = ?");
    params.push(stringifyJsonColumn(validatedTreatment.value));
  }
  if (body.followups !== undefined) {
    const validatedFollowups = validateFollowupList(body.followups);
    if (!validatedFollowups.ok) {
      return NextResponse.json({ error: validatedFollowups.error }, { status: 400 });
    }
    updates.push("followups = ?");
    params.push(stringifyJsonColumn(validatedFollowups.value));
  }
  if (body.photos !== undefined) {
    const validatedPhotos = validatePhotoList(body.photos);
    if (!validatedPhotos.ok) {
      return NextResponse.json({ error: validatedPhotos.error }, { status: 400 });
    }
    updates.push("photos = ?");
    params.push(encryptField(workerContext.country, stringifyJsonColumn(validatedPhotos.value)));
  }
  if (body.status !== undefined) {
    updates.push("status = ?");
    params.push(body.status);
  }
  if (body.priority !== undefined) {
    updates.push("priority = ?");
    params.push(body.priority);
  }
  if (body.assigned_worker_id !== undefined) {
    if (!workerContext.isAdmin) {
      return NextResponse.json(
        { error: "Only administrators can change patient assignments." },
        { status: 403 },
      );
    }

    const nextAssignedWorkerId = body.assigned_worker_id ? String(body.assigned_worker_id) : null;
    updates.push("assigned_worker_id = ?");
    params.push(nextAssignedWorkerId);
    updates.push("assigned_worker_ids = ?");
    params.push(stringifyJsonColumn(nextAssignedWorkerId ? [nextAssignedWorkerId] : null));
  }
  if (body.assigned_worker_ids !== undefined) {
    if (!workerContext.isAdmin) {
      return NextResponse.json(
        { error: "Only administrators can change patient assignments." },
        { status: 403 },
      );
    }

    const nextAssignedWorkerIds = normalizeWorkerIds(body.assigned_worker_ids);
    updates.push("assigned_worker_ids = ?");
    params.push(stringifyJsonColumn(nextAssignedWorkerIds.length > 0 ? nextAssignedWorkerIds : null));
    updates.push("assigned_worker_id = ?");
    params.push(nextAssignedWorkerIds[0] || null);
  }

  if (updates.length === 0) {
    return NextResponse.json({ error: "No fields to update." }, { status: 400 });
  }

  params.push(id);

  // Non-admins may only update patients assigned to them.
  let whereClause = "id = ?";
  if (!workerContext.isAdmin) {
    whereClause += " AND (assigned_worker_id = ? OR FIND_IN_SET(?, REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(assigned_worker_ids, '[]'), '[', ''), ']', ''), '\"', ''), ' ', '')) > 0)";
    params.push(workerContext.workerId, workerContext.workerId);
  }

  try {
    const updateFieldNames = updates
      .map((entry) => entry.split("=")[0]?.trim())
      .filter(Boolean);

    const [result] = await getCountryDatabase(workerContext.country).query<ResultSetHeader>(
      `UPDATE patients SET ${updates.join(", ")} WHERE ${whereClause}`,
      params,
    );

    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Patient not found or not assigned to you." }, { status: 404 });
    }

    await logActivity({
      country: workerContext.country,
      actorWorkerId: workerContext.workerId,
      actorName: workerContext.workerName,
      actorEmail: text(session.user.email),
      actorRole: workerContext.role,
      action: body.followups !== undefined ? "patient.followups_updated" : "patient.updated",
      entityType: "patient",
      entityId: id,
      details: {
        updated_fields: updateFieldNames,
        status: body.status,
        priority: body.priority,
        followups_count: Array.isArray(body.followups) ? body.followups.length : undefined,
      },
      ipAddress: getClientIp(request),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    if (isDuplicateEntryError(error)) {
      return NextResponse.json(
        { error: "A patient with this email already exists." },
        { status: 409 },
      );
    }
    console.error("Failed to update patient profile", error);
    return NextResponse.json(
      { error: "Could not update the patient." },
      { status: 503 },
    );
  }
}

export async function DELETE(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  let id = searchParams.get("id");

  if (!id) {
    // The id may arrive as a query parameter or in a JSON body.
    try {
      const body = (await request.json()) as { id?: string | number };
      if (body.id) {
        id = String(body.id);
      }
    } catch {
      // No JSON body provided; the missing-id check below handles it.
    }
  }

  if (!id) {
    return NextResponse.json({ error: "Patient ID is required." }, { status: 400 });
  }

  // Non-admins may only delete patients assigned to them.
  let whereClause = "id = ?";
  const deleteParams: unknown[] = [id];
  if (!workerContext.isAdmin) {
    whereClause += " AND (assigned_worker_id = ? OR FIND_IN_SET(?, REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(assigned_worker_ids, '[]'), '[', ''), ']', ''), '\"', ''), ' ', '')) > 0)";
    deleteParams.push(workerContext.workerId, workerContext.workerId);
  }

  try {
    const db = getCountryDatabase(workerContext.country);
    const [existingRows] = await db.query<RowDataPacket[]>(
      `SELECT id, full_name, email
       FROM patients
       WHERE ${whereClause}
       LIMIT 1`,
      deleteParams,
    );

    if (!existingRows[0]) {
      return NextResponse.json({ error: "Patient not found or not assigned to you." }, { status: 404 });
    }

    const [result] = await db.query<ResultSetHeader>(
      `DELETE FROM patients WHERE ${whereClause}`,
      deleteParams,
    );

    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Patient not found or not assigned to you." }, { status: 404 });
    }

    await logActivity({
      country: workerContext.country,
      actorWorkerId: workerContext.workerId,
      actorName: workerContext.workerName,
      actorEmail: text(session.user.email),
      actorRole: workerContext.role,
      action: "patient.deleted",
      entityType: "patient",
      entityId: id,
      details: {
        full_name: existingRows[0].full_name ?? null,
        email: existingRows[0].email ?? null,
      },
      ipAddress: getClientIp(request),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete patient profile", error);
    return NextResponse.json(
      { error: "Could not delete the patient." },
      { status: 503 },
    );
  }
}
