import { loadRequestInbox } from "@/lib/data/request-inbox";
import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { configuredCountries, getCountryDatabase, type ResultSetHeader, type RowDataPacket } from "@/lib/database";
import { parseCountry } from "@/lib/countries";
import { isRomanianCounty } from "@/lib/romanian-counties";
import { logActivity } from "@/lib/activity-log";
import { sendHelpRequestConfirmationEmail } from "@/lib/email";
import type { RequestStatus, RequestPriority } from "@/lib/types/medical-request";
import { checkRateLimit, getClientIp } from "@/lib/rate-limit";
import { isValidEmail, text } from "@/lib/text";
import { getUserWorkerContext } from "@/lib/worker-auth";
import { verifyRecaptcha } from "@/lib/security/recaptcha";
import { getRequestLang } from "@/lib/i18n/server-routing";

type RequestPayload = {
  name?: unknown;
  phone?: unknown;
  email?: unknown;
  description?: unknown;
  country?: unknown;
  county?: unknown;
  privacyConsent?: unknown;
  captchaToken?: unknown;
};

export async function POST(request: Request) {
  const rateLimit = await checkRateLimit(`medical-help-requests:${getClientIp(request)}`, { limit: 5, windowMs: 60_000 });
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: "Too many requests. Wait a moment and try again." },
      { status: 429, headers: { "Retry-After": String(rateLimit.retryAfterSeconds) } },
    );
  }

  let body: RequestPayload;

  try {
    body = (await request.json()) as RequestPayload;
  } catch {
    return NextResponse.json({ error: "Invalid request data." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "Invalid request data." }, { status: 400 });
  }
  const captchaError = await verifyRecaptcha(body.captchaToken, "help_request");
  if (captchaError) return captchaError;

  // The request is stored in the database of the country the person chose, never anywhere else.
  const available = configuredCountries();
  const country = parseCountry(body.country) ?? (available.length === 1 ? available[0] : null);
  if (!country || !available.includes(country)) {
    return NextResponse.json({ error: "Choose your country." }, { status: 400 });
  }

  const county = country === "RO" ? text(body.county) : "";
  if (body.privacyConsent !== true) {
    return NextResponse.json({ error: "Agree to the privacy policy to continue." }, { status: 400 });
  }
  if (country === "RO" && !isRomanianCounty(county)) {
    return NextResponse.json({ error: "Choose a county." }, { status: 400 });
  }

  const name = text(body.name);
  const phone = text(body.phone);
  const email = text(body.email).toLowerCase();
  const description = text(body.description);

  if (!phone || description.length < 10) {
    return NextResponse.json(
      { error: "Enter a phone number and describe the problem." },
      { status: 400 },
    );
  }

  if (email && !isValidEmail(email)) {
    return NextResponse.json(
      { error: "Enter a valid email or leave it empty." },
      { status: 400 },
    );
  }

  if (
    name.length > 200 ||
    phone.length > 50 ||
    email.length > 320 ||
    description.length > 4000
  ) {
    return NextResponse.json(
      { error: "One or more fields are too long." },
      { status: 400 },
    );
  }

  try {
    const [result] = await getCountryDatabase(country).query<ResultSetHeader>(
      `INSERT INTO medical_help_requests
        (full_name, phone, email, description, county, privacy_consent_at)
       VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      // Older country databases define email as NOT NULL; an omitted email remains optional.
      [name || null, phone, email, description, county || null],
    );

    await logActivity({
      country,
      actorName: name || null,
      actorEmail: email || null,
      actorRole: "public_user",
      action: "request.submitted",
      entityType: "medical_help_request",
      entityId: result.insertId || null,
      details: {
        has_name: Boolean(name),
        has_email: Boolean(email),
        description_length: description.length,
      },
      ipAddress: getClientIp(request),
    });
  } catch (error) {
    console.error("Failed to store medical help request", error);
    return NextResponse.json(
      { error: "Your request was not saved. Try again." },
      { status: 503 },
    );
  }

  let emailSent = false;
  if (email) {
    emailSent = await sendHelpRequestConfirmationEmail({
      name,
      phone,
      email,
      description,
      lang: await getRequestLang(request),
    });
  }

  return NextResponse.json({ success: true, email_sent: emailSent }, { status: 201 });
}

export async function GET(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  try {
    const data = await loadRequestInbox(workerContext.country, new URL(request.url).searchParams, String(workerContext.workerId), workerContext.isAdmin);
    return NextResponse.json(data);
  } catch (error) {
    console.error("Failed to fetch medical help requests", error);
    return NextResponse.json({ error: "Could not fetch requests." }, { status: 503 });
  }
}

export async function PATCH(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  let body: {
    id?: string | number;
    status?: RequestStatus;
    priority?: RequestPriority;
    internal_notes?: string | null;
  };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request payload." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "Invalid request payload." }, { status: 400 });
  }
  const id = body.id ? String(body.id) : null;
  if (!id) {
    return NextResponse.json({ error: "Request ID is required." }, { status: 400 });
  }

  const validStatuses: RequestStatus[] = ["pending", "in_progress", "resolved", "archived"];
  const validPriorities: RequestPriority[] = ["normal", "urgent"];

  const updates: string[] = [];
  const params: unknown[] = [];

  if (body.status !== undefined) {
    if (!validStatuses.includes(body.status)) {
      return NextResponse.json({ error: "Invalid status value." }, { status: 400 });
    }
    updates.push("status = ?");
    params.push(body.status);
    updates.push("status_updated_by_name = ?");
    params.push(text(session.user.name) || null);
    updates.push("status_updated_by_email = ?");
    params.push(text(session.user.email) || null);
    updates.push("status_updated_at = CURRENT_TIMESTAMP");
  }

  if (body.priority !== undefined) {
    if (!validPriorities.includes(body.priority)) {
      return NextResponse.json({ error: "Invalid priority value." }, { status: 400 });
    }
    updates.push("priority = ?");
    params.push(body.priority);
  }

  if (body.internal_notes !== undefined) {
    if (body.internal_notes !== null && (typeof body.internal_notes !== "string" || body.internal_notes.length > 10_000)) {
      return NextResponse.json({ error: "Internal notes are invalid or too long." }, { status: 400 });
    }
    updates.push("internal_notes = ?");
    params.push(body.internal_notes);
  }

  if (updates.length === 0) {
    return NextResponse.json({ error: "No update fields provided." }, { status: 400 });
  }

  params.push(id);

  try {
    const db = getCountryDatabase(workerContext.country);
    const [existingRows] = await db.query<RowDataPacket[]>(
      "SELECT id, status, priority, internal_notes FROM medical_help_requests WHERE id = ? LIMIT 1",
      [id],
    );

    const existing = existingRows[0];
    if (!existing) {
      return NextResponse.json({ error: "Request not found." }, { status: 404 });
    }

    const [result] = await db.query<ResultSetHeader>(
      `UPDATE medical_help_requests SET ${updates.join(", ")} WHERE id = ?`,
      params,
    );

    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Request not found." }, { status: 404 });
    }

    const [rows] = await db.query<RowDataPacket[]>(
      `SELECT id, full_name, phone, email, description,
              COALESCE(status, 'pending') AS status,
              status_updated_by_name, status_updated_by_email, status_updated_at,
              COALESCE(priority, 'normal') AS priority,
              internal_notes, created_at, updated_at, county, privacy_consent_at
       FROM medical_help_requests
       WHERE id = ?
       LIMIT 1`,
      [id],
    );

    await logActivity({
      country: workerContext.country,
      actorWorkerId: workerContext.workerId,
      actorName: text(session.user.name) || workerContext.workerName,
      actorEmail: text(session.user.email),
      actorRole: workerContext.role,
      action: body.status !== undefined ? "request.status_changed" : "request.updated",
      entityType: "medical_help_request",
      entityId: id,
      details: {
        previous_status: existing.status ?? null,
        next_status: body.status ?? existing.status ?? null,
        previous_priority: existing.priority ?? null,
        next_priority: body.priority ?? existing.priority ?? null,
        internal_notes_changed: body.internal_notes !== undefined,
      },
      ipAddress: getClientIp(request),
    });

    return NextResponse.json({ success: true, request: rows[0] || null });
  } catch (error) {
    console.error("Failed to update medical help request", error);
    return NextResponse.json(
      { error: "Could not update request. Ensure database migration 002 is applied." },
      { status: 503 },
    );
  }
}

export async function DELETE(request: Request) {
  const session = await auth();

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }

  const workerContext = await getUserWorkerContext(session.user.email);
  if (!workerContext.workerId) {
    return NextResponse.json({ error: "Staff access is required." }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  let id = searchParams.get("id");

  if (!id) {
    // The id may arrive as a query parameter or in a JSON body.
    try {
      const body = (await request.json()) as { id?: string | number };
      if (body.id) {
        id = String(body.id);
      }
    } catch {
      // No JSON body provided; the missing-id check below handles it.
    }
  }

  if (!id) {
    return NextResponse.json({ error: "Request ID is required." }, { status: 400 });
  }

  try {
    const db = getCountryDatabase(workerContext.country);
    const [rows] = await db.query<RowDataPacket[]>(
      "SELECT id, status, priority FROM medical_help_requests WHERE id = ? LIMIT 1",
      [id],
    );
    const existing = rows[0];
    if (!existing) {
      return NextResponse.json({ error: "Request not found." }, { status: 404 });
    }

    const [result] = await db.query<ResultSetHeader>(
      `DELETE FROM medical_help_requests WHERE id = ?`,
      [id],
    );

    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Request not found." }, { status: 404 });
    }

    await logActivity({
      country: workerContext.country,
      actorWorkerId: workerContext.workerId,
      actorName: text(session.user.name) || workerContext.workerName,
      actorEmail: text(session.user.email),
      actorRole: workerContext.role,
      action: "request.deleted",
      entityType: "medical_help_request",
      entityId: id,
      details: {
        status: existing.status ?? null,
        priority: existing.priority ?? null,
      },
      ipAddress: getClientIp(request),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete medical help request", error);
    return NextResponse.json(
      { error: "Could not delete the request. Try again." },
      { status: 503 },
    );
  }
}
