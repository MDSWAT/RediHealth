import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { PageListenAction } from "@/components/ui/PageListenAction";
import { getRequestLang } from "@/lib/i18n/server-routing";
import { getLegalCopy } from "@/lib/i18n/legal-translations";
import { localizedPageTitle } from "@/lib/i18n/page-metadata";

export async function generateMetadata(): Promise<Metadata> {
  const lang = await getRequestLang();
  const copy = getLegalCopy(lang).accessibility;
  return {
    title: localizedPageTitle(lang, "accessibility", "Accessibility - RediHealth"),
    description: copy.description,
  };
}

export default async function AccessibilityPage() {
  const lang = await getRequestLang();
  const copy = getLegalCopy(lang).accessibility;
  return (
    <main id="main-content" className="flex-1 pb-12 sm:pb-16">
      <Container>
        <PageHeader
          title={copy.title}
          lead={copy.description}
          actions={<PageListenAction lang={lang} segments={[copy.title, copy.description, ...copy.paragraphs]} />}
        />

        {/* The opening paragraph leads at a larger size in the body colour; the rest follow at a
            comfortable measure. */}
        <div className="mt-8 max-w-(--measure-reading) space-y-4 text-body text-muted-foreground">
          {copy.paragraphs.map((paragraph, index) => (
            <p
              key={paragraph}
              className={index === 0 ? "mb-6 text-title text-foreground sm:leading-relaxed" : undefined}
            >
              {paragraph}
            </p>
          ))}
          <p>
            {copy.contactLead}{" "}
            <a href="mailto:support@redihealth.app" className="rounded-sm text-sapphire underline decoration-sapphire/40 underline-offset-4 transition-colors duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] hover:text-sapphire-light hover:decoration-sapphire focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              support@redihealth.app
            </a>{" "}
            {copy.contact}
          </p>
        </div>
      </Container>
    </main>
  );
}
