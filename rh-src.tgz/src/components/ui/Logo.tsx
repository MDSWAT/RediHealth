import Link from "next/link";
import Image from "next/image";
import { cn } from "@/lib/cn";

/** Brand mark and name. Change them here: the header, footer and printed summaries all read these. */
export const LOGO_SRC = "/Icons/Logo.svg";
export const BRAND_NAME = "RediHealth";

type LogoProps = {
  className?: string;
  muted?: boolean;
  tone?: "default" | "light";
  href?: string;
  /** Localized accessible name, starting with the brand (e.g. "RediHealth, home page"). Defaults to the brand name. */
  label?: string;
  onClick?: () => void;
};

export function Logo({ className, muted = false, tone = "default", href = "/", label, onClick }: LogoProps) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md font-semibold sm:gap-2.5",
        className,
      )}
      aria-label={label || undefined}
    >
      <Image src={LOGO_SRC} alt="" width={40} height={40} className="h-7 w-7 shrink-0 sm:h-10 sm:w-10" />
      <span
        className={cn(
          "text-body sm:text-lead transition-colors duration-(--dur-base) ease-(--ease-out-calm)",
          tone === "light" ? "text-paper" : muted ? "text-muted-foreground" : "text-foreground dark:text-paper",
        )}
      >
        {BRAND_NAME}
      </span>
    </Link>
  );
}
