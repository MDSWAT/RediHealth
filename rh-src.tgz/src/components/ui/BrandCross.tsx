import { useId } from "react";
import { cn } from "@/lib/cn";

const UPPER = "M21.02,42.78c-0.37,0-0.73,0-1.08,0c-3.19-0.02-6.38-0.04-9.57-0.07c-2.78-0.03-5.23-2.3-5.45-5.07c-0.05-0.69-0.05-1.38-0.05-2.07c0-3,0-6,0.01-8.99c0.01-3.16,2.54-5.68,5.71-5.68c3.29,0,6.59,0,9.88,0c0.58,0,0.64-0.06,0.64-0.64c0-3.45-0.01-6.89,0-10.34c0.01-3.29,2.52-5.76,5.82-5.76c3.4,0,6.79,0,10.19,0c3.02,0,5.3,1.91,5.8,4.87c0.05,0.28,0.05,0.56,0.05,0.84c0,2.9-0.09,5.79,0.03,8.68c0.06,1.52-0.29,2.89-0.8,4.26c-0.52,1.38-1.33,2.59-2.37,3.65c-1.37,1.39-3.03,2.29-4.85,2.94c-1.78,0.64-3.59,1.22-5.33,1.95c-2.2,0.92-4.13,2.26-5.63,4.16c-1.49,1.89-2.37,4.06-2.83,6.4C21.14,42.19,21.08,42.47,21.02,42.78z M33.58,27.54c2.78,0.02,5-2.18,5.02-4.98c0.02-2.64-2.22-4.94-4.8-4.98c-2.85-0.05-5.02,2.15-5.14,4.75C28.52,25.23,30.87,27.56,33.58,27.54z";
const LOWER = "M46.73,20.87c0.98,0,1.99,0,3,0c1.38,0.01,2.77-0.02,4.15,0.03c2.73,0.1,5.3,2.49,5.3,5.73c0,3.45,0.01,6.89-0.01,10.34c-0.02,2.87-1.94,5.18-4.7,5.7c-0.36,0.07-0.74,0.09-1.11,0.09c-3.29,0.01-6.59,0-9.88,0.01c-0.59,0-0.61,0.02-0.61,0.6c0,3.59,0,7.18,0,10.76c0.01,3.24-2.47,5.72-5.71,5.72c-3.19,0-6.38,0-9.57,0c-0.33,0-0.67-0.03-0.99-0.08c-1.56-0.25-2.3-1.02-2.54-2.58c-0.42-2.64-0.21-5.26,0.3-7.86c0.56-2.82,1.52-5.47,3.13-7.87c1.64-2.44,3.79-4.28,6.41-5.59c2.07-1.03,4.18-2.01,6.06-3.39c3.09-2.27,5.13-5.25,6.15-8.94C46.35,22.68,46.52,21.78,46.73,20.87z";

/**
 * The RediHealth cross (the mark from /Icons/Logo.svg) as inline SVG in the current colour, for
 * dark grounds where the red logo would sink. Two tones like the logo: the upper-left half in full
 * colour, the lower-right half a step quieter. Decorative: the brand name is said elsewhere.
 * `sheen` adds a band of warm light, clipped to the mark, that a stylesheet can sweep across it
 * (`.brand-cross-sheen`); at rest it sits outside the mark, so without motion nothing shows.
 */
export function BrandCross({ className, sheen = false }: { className?: string; sheen?: boolean }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg viewBox="5 5 54.5 54.5" aria-hidden="true" focusable="false" className={cn("shrink-0", className)}>
      <path fill="currentColor" d={UPPER} />
      <path fill="currentColor" fillOpacity={0.72} d={LOWER} />
      {sheen ? (
        <>
          <defs>
            <clipPath id={`${id}-mark`}>
              <path d={UPPER} />
              <path d={LOWER} />
            </clipPath>
            <linearGradient id={`${id}-light`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#fde68a" stopOpacity="0" />
              <stop offset="0.5" stopColor="#fde68a" stopOpacity="0.95" />
              <stop offset="1" stopColor="#fde68a" stopOpacity="0" />
            </linearGradient>
          </defs>
          <g clipPath={`url(#${id}-mark)`}>
            <rect className="brand-cross-sheen" x="-24" y="-10" width="16" height="84" fill={`url(#${id}-light)`} />
          </g>
        </>
      ) : null}
    </svg>
  );
}
