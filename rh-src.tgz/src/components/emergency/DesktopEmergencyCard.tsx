"use client";

import React from "react";
import { PhoneIcon, CloseIcon } from "@/components/ui/icons";
import { cn } from "@/lib/cn";
import { useLanguage } from "@/lib/i18n/language-context";
import { translations } from "@/lib/i18n/translations";

export type DesktopEmergencyCardProps = {
  onDismiss?: () => void;
  className?: string;
  /** id for the heading, so a dialog that hosts the card can name itself with it. */
  titleId?: string;
};

function useSafeLanguage() {
  try {
    const ctx = useLanguage();
    const lang = ctx?.lang || "ro";
    const baseT = translations[lang] ?? translations.ro;
    const t = {
      ...baseT,
      ...(ctx?.t || {}),
      emergency: ctx?.t?.emergency ?? baseT.emergency,
    };
    return { lang, t };
  } catch {
    return { lang: "ro" as const, t: translations.ro };
  }
}

/**
 * On a computer, tel: links open FaceTime or Skype or nothing at all, so the dialer gate
 * shows the number to dial from a phone instead.
 */
export function DesktopEmergencyCard({
  onDismiss,
  className,
  titleId,
}: DesktopEmergencyCardProps) {
  const { t } = useSafeLanguage();
  const e = t.emergency;

  return (
    <div
      className={cn(
        "relative rounded-xl border border-border bg-card p-6 shadow-xl sm:p-7",
        className
      )}
    >
      {onDismiss ? (
        <button
          type="button"
          onClick={onDismiss}
          aria-label={e.closeWindowAria}
          className="press-row absolute right-3 top-3 flex h-11 w-11 min-h-11 min-w-11 items-center justify-center rounded-lg border border-transparent text-muted-foreground transition-colors duration-[var(--dur-fast)] hover:border-border-control hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring motion-reduce:transition-none"
        >
          <CloseIcon className="h-5 w-5" aria-hidden="true" />
        </button>
      ) : null}

      <div className="flex items-start gap-4">
        <PhoneIcon className="mt-1 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />

        <div className="min-w-0 space-y-3 pr-8">
          <div>
            <h3 id={titleId} className="text-title font-semibold text-foreground">
              {e.desktopDialTitle}
            </h3>
            <p className="mt-0.5 text-body text-muted-foreground">{e.desktopDialSubtitle}</p>
          </div>

          <p className="text-display font-semibold tabular-nums text-primary">112</p>

          <p className="text-body text-muted-foreground">{e.desktopFreeNote}</p>

          <p className="border-t border-border pt-3 text-body text-muted-foreground">
            {e.desktopRuralNote}
          </p>
        </div>
      </div>
    </div>
  );
}
