"use client";

import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/Button";
import { PhoneIcon, CloseIcon } from "@/components/ui/icons";
import { DesktopEmergencyCard } from "@/components/emergency/DesktopEmergencyCard";
import styles from "@/components/emergency/EmergencyOverlay.module.css";
import { cn } from "@/lib/cn";
import { useLanguage } from "@/lib/i18n/language-context";
import { translations } from "@/lib/i18n/translations";

export type EmergencyDialerGateProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

function useSafeLanguage() {
  try {
    const ctx = useLanguage();
    const lang = ctx?.lang || "ro";
    const baseT = translations[lang] ?? translations.ro;
    const t = {
      ...baseT,
      ...(ctx?.t || {}),
      emergency: ctx?.t?.emergency ?? baseT.emergency,
    };
    return { lang, t };
  } catch {
    return { lang: "ro" as const, t: translations.ro };
  }
}

/**
 * The site never dials by itself. On a phone this opens the keypad with 112 filled in, after
 * saying that the reader still presses call; on a computer it shows the number to dial.
 */
export function EmergencyDialerGate({
  open,
  onOpenChange,
}: EmergencyDialerGateProps) {
  const { t } = useSafeLanguage();
  const e = t.emergency;

  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === "undefined") return false;
    const userAgent = navigator.userAgent || "";
    return (
      /Mobi|Android|iPhone|iPad|iPod/i.test(userAgent) ||
      window.matchMedia("(max-width: 768px)").matches
    );
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(max-width: 768px)");
    const handler = (e: MediaQueryListEvent) => {
      setIsMobile(e.matches || /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent || ""));
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const panelRef = useRef<HTMLDivElement>(null);

  // Focus moves into the dialog and back to the opener; Escape closes only this layer
  // (it can sit on top of the warning-signs dialog).
  useEffect(() => {
    if (!open) return;
    const opener = document.activeElement as HTMLElement | null;
    panelRef.current?.focus({ preventScroll: true });
    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        event.stopImmediatePropagation();
        onOpenChange(false);
      }
    }
    window.addEventListener("keydown", handleKeyDown, true);
    return () => {
      window.removeEventListener("keydown", handleKeyDown, true);
      document.body.style.overflow = overflow;
      opener?.focus({ preventScroll: true });
    };
  }, [open, onOpenChange]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="dialer-gate-title"
      className="scrim-in fixed inset-0 z-[110] flex items-end justify-center bg-ink-950/70 p-0 sm:items-center sm:p-4"
    >
      <div
        className="fixed inset-0 -z-10"
        onClick={() => onOpenChange(false)}
        aria-hidden="true"
      />

      {isMobile ? (
        <div
          ref={panelRef}
          tabIndex={-1}
          className={cn(styles.panel, "relative w-full max-w-lg rounded-t-xl bg-card p-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] shadow-xl focus:outline-none sm:rounded-xl sm:p-6")}
        >
          <div className="flex items-start justify-between gap-3">
            <h2 id="dialer-gate-title" className="pt-1 text-title font-semibold text-foreground">
              {e.dialerGateTitle}
            </h2>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              aria-label={e.closeWindowAria}
              className="press-row -mr-2 -mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors duration-[var(--dur-fast)] hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring motion-reduce:transition-none"
            >
              <CloseIcon className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>

          <div className="mt-3 space-y-3">
            <p className="text-body text-foreground">{e.dialerNotice}</p>
            <p className="text-body text-muted-foreground">{e.dialerFreeNote}</p>
          </div>

          <div className="mt-6 flex flex-col gap-3">
            <Button
              href="tel:112"
              variant="primary"
              size="lg"
              fullWidth
              onClick={() => onOpenChange(false)}
              className="min-h-14 px-6"
            >
              <PhoneIcon className="h-5 w-5 shrink-0" aria-hidden="true" />
              <span>{e.openDialerButton}</span>
            </Button>

            <Button
              type="button"
              variant="outline"
              size="lg"
              fullWidth
              onClick={() => onOpenChange(false)}
            >
              {e.cancelButton}
            </Button>
          </div>
        </div>
      ) : (
        <div ref={panelRef} tabIndex={-1} className={cn(styles.card, "relative w-full max-w-lg focus:outline-none")}>
          <DesktopEmergencyCard titleId="dialer-gate-title" onDismiss={() => onOpenChange(false)} />
        </div>
      )}
    </div>
  );
}
