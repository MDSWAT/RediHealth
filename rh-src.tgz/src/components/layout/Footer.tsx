"use client";

import { WheelBackdrop } from "@/components/landing/WheelBackdrop";
import dynamic from "next/dynamic";
import { useState } from "react";
import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { Logo } from "@/components/ui/Logo";
import { Reveal } from "@/components/ui/Reveal";
import { PhoneIcon } from "@/components/ui/icons";
import { getChromeCopy } from "@/components/layout/chrome-copy";
import {
  feedbackTriggerCopy,
  openReportIssue,
  openSiteFeedback,
} from "@/components/layout/chrome-widget-events";
import { useLanguage } from "@/lib/i18n/language-context";
import { getPwaCopy } from "@/lib/i18n/pwa-copy";
import { withLangPrefix } from "@/lib/i18n/routing";
import { applyPwaUpdate, openPwaInstall, usePwaSnapshot } from "@/lib/pwa/pwa-state";

const EmergencySignsModal = dynamic(
  () => import("@/components/emergency/EmergencySignsModal").then((mod) => mod.EmergencySignsModal),
  { ssr: false },
);
const EmergencyDialerGate = dynamic(
  () => import("@/components/emergency/EmergencyDialerGate").then((mod) => mod.EmergencyDialerGate),
  { ssr: false },
);

/**
 * Footer: the ink ground that closes every page, mirroring the ink hero. A short statement of
 * what RediHealth is, four link columns with 44px rows, a calm 112 reminder (with the
 * alarm-signs guide) and the legal line. Sentence case, no ampersands in prose.
 * The two dialogs render beside the footer, not inside it, so they keep their own text colour.
 */
export function Footer() {
  const { lang, t } = useLanguage();
  const tFooter = t.footer;
  const chrome = getChromeCopy(lang);
  const pwa = usePwaSnapshot();
  const pwaCopy = getPwaCopy(lang);
  const showInstallTrigger = !pwa.isStandalone && !pwa.hasUpdate;
  const pwaTriggerLabel = showInstallTrigger
    ? pwaCopy.installButton
    : pwa.isRefreshing
      ? pwaCopy.refreshingApp
      : pwa.hasUpdate
        ? pwaCopy.updateNow
        : pwaCopy.refreshApp;
  const [emergencySignsOpen, setEmergencySignsOpen] = useState(false);
  const [dialerOpen, setDialerOpen] = useState(false);

  const columns: { heading: string; links: { label: string; href: string }[] }[] = [
    {
      heading: tFooter.col1Heading,
      links: [
        { label: tFooter.col1Link1, href: "/health-information" },
        { label: tFooter.col1Link2, href: "/health-assistant" },
        { label: tFooter.col1Link3, href: "/health-check" },
        { label: tFooter.col1Link4, href: "/stiri" },
      ],
    },
    {
      heading: tFooter.col2Heading,
      links: [
        { label: tFooter.col2Link1, href: "/medic-online" },
        { label: tFooter.col2Link2, href: "/medic-online/programare" },
        { label: tFooter.col2Link3, href: "/find-help" },
        { label: tFooter.col2Link4, href: "/contul-meu" },
      ],
    },
    {
      heading: tFooter.col3Heading,
      links: [
        { label: tFooter.col3Link1, href: "/mediatori" },
        { label: tFooter.col3Link2, href: "/panel/mediator" },
        { label: tFooter.col3Link3, href: "/panel" },
        { label: tFooter.col3Link4, href: "/mediatori#protocol" },
      ],
    },
    {
      heading: tFooter.col4Heading,
      links: [
        { label: tFooter.col4Link1, href: "/about" },
        { label: tFooter.col4Link2, href: "/contact" },
        { label: tFooter.col4Link3, href: "/accessibility" },
        { label: tFooter.col4Link4, href: "/privacy" },
        { label: tFooter.col4Link5, href: "/terms" },
      ],
    },
  ];

  return (
    <>
      <footer className="relative z-10 bg-ink-950 text-paper">
        {/* The topic wheel with its eight icons, soft, behind the footer's content at every width. */}
        <div aria-hidden="true">
          <WheelBackdrop placement="footer" />
        </div>
        <Container className="py-12 sm:py-16">
          <div className="grid gap-10 xl:grid-cols-[1.1fr_2.9fr] xl:gap-12">
            <div className="max-w-sm space-y-4">
              <Logo className="hero-focus" tone="light" href={withLangPrefix("/", lang)} label={chrome.homeLink} />
              <p className="text-body text-mist">{tFooter.brandDescription}</p>
            </div>

            <nav aria-label={chrome.footerNav}>
              {/* The four columns arrive one after another as the footer comes into view. */}
              <Reveal stagger className="grid grid-cols-2 gap-x-6 gap-y-8 md:grid-cols-4">
                {columns.map((column) => (
                  <div key={column.heading} className="min-w-0">
                    <h2 className="text-body font-semibold leading-snug text-paper">{column.heading}</h2>
                    <ul className="mt-2">
                      {column.links.map((link) => (
                        <li key={link.href}>
                          <Link
                            href={withLangPrefix(link.href, lang)}
                            className="group hero-focus -mx-2 flex min-h-11 items-center rounded-(--radius-control) px-2 py-2.5 text-body leading-snug break-words text-mist press-on-dark hover:text-paper transition-colors duration-(--dur-fast) ease-(--ease-out-calm) motion-reduce:transition-none"
                          >
                            <span className="min-w-0 [overflow-wrap:anywhere]">{link.label}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </Reveal>
            </nav>
          </div>

          {/* 112 reminder: hanging-indented on phones so wrapped lines and actions share one left axis; inline from lg. */}
          <div className="mt-12 flex flex-col gap-1 text-body text-mist lg:flex-row lg:flex-wrap lg:items-center lg:gap-x-4">
            <div className="flex items-start gap-2.5 lg:items-center">
              <PhoneIcon aria-hidden="true" className="mt-1 h-4 w-4 shrink-0 text-ruby-300 lg:mt-0" />
              <p className="font-semibold leading-snug text-paper">{tFooter.emergency112Title}</p>
            </div>
            {/* Same gate as the header's 112 line: keypad on a phone, the number and guidance on a computer. */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-0 pl-[26px] lg:pl-0">
              <button
                type="button"
                onClick={() => setDialerOpen(true)}
                className="hero-focus press-on-dark -mx-1.5 -my-1.5 inline-flex min-h-11 items-center whitespace-nowrap rounded-md px-1.5 font-semibold text-paper underline decoration-paper/40 underline-offset-4 transition-colors duration-(--dur-fast) ease-(--ease-out-calm) hover:decoration-paper motion-reduce:transition-none"
              >
                {tFooter.call112Button}
              </button>
              <button
                type="button"
                onClick={() => setEmergencySignsOpen(true)}
                className="hero-focus press-on-dark -mx-1.5 -my-1.5 inline-flex min-h-11 items-center whitespace-nowrap rounded-md px-1.5 text-mist underline decoration-mist/40 underline-offset-4 transition-colors duration-(--dur-fast) ease-(--ease-out-calm) hover:text-paper hover:decoration-paper motion-reduce:transition-none"
              >
                {tFooter.seeAlarmSigns}
              </button>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 border-t border-white/10 pt-6 text-meta text-mist lg:flex-row lg:items-center lg:justify-between lg:gap-8">
            <p className="text-pretty leading-relaxed">
              <span className="font-medium text-paper/85">{tFooter.copyrightLine}</span>
              <span aria-hidden="true" className="mx-2.5 inline-block h-3 w-px align-middle bg-white/20" />
              <span>{tFooter.nonEmergencyWarning}</span>
            </p>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-1 lg:shrink-0">
              <button
                type="button"
                disabled={!showInstallTrigger && pwa.isRefreshing}
                onClick={() => {
                  if (showInstallTrigger) {
                    void openPwaInstall();
                  } else {
                    void applyPwaUpdate();
                  }
                }}
                className="hero-focus -mx-2 -my-1.5 inline-flex min-h-11 items-center whitespace-nowrap rounded-(--radius-control) px-2 text-meta underline decoration-mist/40 underline-offset-4 press-on-dark hover:text-paper hover:decoration-paper transition-colors duration-(--dur-fast) ease-(--ease-out-calm) motion-reduce:transition-none disabled:cursor-wait disabled:opacity-70"
              >
                {pwaTriggerLabel}
              </button>
              <button
                type="button"
                onClick={() => {
                  openSiteFeedback();
                }}
                className="hero-focus -mx-2 -my-1.5 inline-flex min-h-11 items-center rounded-(--radius-control) px-2 text-meta underline decoration-mist/40 underline-offset-4 press-on-dark hover:text-paper hover:decoration-paper transition-colors duration-(--dur-fast) ease-(--ease-out-calm) motion-reduce:transition-none whitespace-nowrap"
              >
                {(feedbackTriggerCopy[lang] ?? feedbackTriggerCopy.ro).footerLink}
              </button>
              {/* Opens the report form in place (it records this page); the floating button is desktop-only. */}
              <Link
                href={withLangPrefix("/report-issue", lang)}
                onClick={(event) => {
                  if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
                  if (openReportIssue()) event.preventDefault();
                }}
                className="hero-focus -mx-2 -my-1.5 inline-flex min-h-11 items-center rounded-(--radius-control) px-2 text-meta underline decoration-mist/40 underline-offset-4 press-on-dark hover:text-paper hover:decoration-paper transition-colors duration-(--dur-fast) ease-(--ease-out-calm) motion-reduce:transition-none whitespace-nowrap"
              >
                {tFooter.reportIssueFallback}
              </Link>
            </div>
          </div>
        </Container>
      </footer>

      {emergencySignsOpen ? <EmergencySignsModal open={emergencySignsOpen} onOpenChange={setEmergencySignsOpen} /> : null}
      {dialerOpen ? <EmergencyDialerGate open={dialerOpen} onOpenChange={setDialerOpen} /> : null}
    </>
  );
}
