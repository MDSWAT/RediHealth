"use client";

import { useEffect, useRef, useState } from "react";
import {
  buildJitsiEmbedUrl,
  MEDIATOR_VIDEO_TOOLBAR,
  subscribeJitsiCallEnd,
} from "@/lib/jitsi-embed";
import { Button } from "@/components/ui/Button";
import { VideoIcon, AlertCircleIcon } from "@/components/ui/icons";
import { useLanguage } from "@/lib/i18n/language-context";
import { translations, type Lang } from "@/lib/i18n/translations";

function useSafeLanguage() {
  try {
    return useLanguage();
  } catch {
    return { lang: "ro" as Lang, t: translations.ro, setLang: () => {} };
  }
}

const handoverCopy = {
  ru: {
    liveStatus: "Дежурный врач на связи",
    endCall: "Завершить вызов",
    iframeTitle: "Видеозвонок с врачом",
    sidePanelLabel: "Поддержка во время звонка",
    patientLine: (name: string, age: string) => `Пациент: ${name} (${age})`,
    translation: "Перевод:",
    translationLanguage: "Романи (Романес)",
    bp: "BP",
    pulse: "Пульс",
    glucose: "Уровень сахара в крови",
    temp: "Температура",
    liveNotesLabel: "Заметки о вызовах",
    tabletTip: "Держите таблетку лицом к пациенту, чтобы врач мог его хорошо видеть.",
    title: "Передача дежурному врачу",
    subtitle: "Врач видит это еще до начала видеозвонка.",
    nameLabel: "Имя пациента",
    ageLabel: "Возраст",
    vitalsLabel: "Значения, измеренные во время визита",
    reasonLabel: "Причина звонка",
    languageBarrier: "Требуется перевод",
    languageHelp: "Посредник переводится на цыганский (Romanes).",
    notesLabel: "Другие примечания",
    submitting: "Отправка данных…",
    submit: "Начать видеозвонок",
    sendError: "Данные не были отправлены. Попробуйте еще раз.",
    connectError: "Не удалось подключить врача. Попробуйте еще раз.",
    demoAge: "68 лет",
    demoReason: "Головокружение по утрам, боль в задней части шеи при усилии.",
    demoNotes: "Кооператив. Вчера утром приняла последнюю таблетку эналаприла.",
  },

  ro: {
    liveStatus: "Medicul de gardă e conectat",
    endCall: "Închide apelul",
    iframeTitle: "Apel video cu medicul",
    sidePanelLabel: "Sprijin în timpul apelului",
    patientLine: (name: string, age: string) => `Pacient: ${name} (${age})`,
    translation: "Traducere:",
    translationLanguage: "romani (romanes)",
    bp: "TA",
    pulse: "Puls",
    glucose: "Glicemie",
    temp: "Temp",
    liveNotesLabel: "Notițe din apel",
    tabletTip: "Ține tableta spre pacient, ca medicul să-l vadă bine.",
    title: "Predare către medicul de gardă",
    subtitle: "Medicul vede aceste date înainte să înceapă apelul video.",
    nameLabel: "Nume pacient",
    ageLabel: "Vârstă",
    vitalsLabel: "Valori măsurate la pacient",
    reasonLabel: "Motivul apelului",
    languageBarrier: "Are nevoie de traducere",
    languageHelp: "Mediatorul traduce în limba romani (romanes).",
    notesLabel: "Alte observații",
    submitting: "Se trimit datele…",
    submit: "Pornește apelul video",
    sendError: "Datele nu s-au trimis. Încearcă din nou.",
    connectError: "Medicul nu s-a putut conecta. Încearcă din nou.",
    demoAge: "68 ani",
    demoReason: "Amețeli dimineața și durere de ceafă la efort",
    demoNotes: "Colaborează. A luat ultima pastilă de enalapril ieri dimineață.",
  },
  en: {
    liveStatus: "Doctor on call connected",
    endCall: "End call",
    iframeTitle: "Video call with the doctor",
    sidePanelLabel: "Support during the call",
    patientLine: (name: string, age: string) => `Patient: ${name} (${age})`,
    translation: "Translation:",
    translationLanguage: "Romani (Romanes)",
    bp: "BP",
    pulse: "Pulse",
    glucose: "Blood sugar",
    temp: "Temp",
    liveNotesLabel: "Call notes",
    tabletTip: "Keep the tablet facing the patient so the doctor can see them well.",
    title: "Handover to the doctor on call",
    subtitle: "The doctor sees this before the video call starts.",
    nameLabel: "Patient name",
    ageLabel: "Age",
    vitalsLabel: "Values measured at the visit",
    reasonLabel: "Reason for the call",
    languageBarrier: "Needs translation",
    languageHelp: "The mediator translates into Romani (Romanes).",
    notesLabel: "Other notes",
    submitting: "Sending data…",
    submit: "Start video call",
    sendError: "The data was not sent. Try again.",
    connectError: "Could not connect the doctor. Try again.",
    demoAge: "68 years",
    demoReason: "Dizzy in the mornings, pain at the back of the neck on effort",
    demoNotes: "Cooperative. Took her last enalapril tablet yesterday morning.",
  },
  sq: {
    liveStatus: "Mjeku i turnit është lidhur",
    endCall: "Mbyll thirrjen",
    iframeTitle: "Thirrje video me mjekun",
    sidePanelLabel: "Ndihmë gjatë thirrjes",
    patientLine: (name: string, age: string) => `Pacienti: ${name} (${age})`,
    translation: "Përkthim:",
    translationLanguage: "gjuha rome (romanes)",
    bp: "TA",
    pulse: "Pulsi",
    glucose: "Sheqeri në gjak",
    temp: "Temp",
    liveNotesLabel: "Shënime nga thirrja",
    tabletTip: "Mbaje tabletin drejt pacientit që mjeku ta shohë mirë.",
    title: "Dorëzimi te mjeku i turnit",
    subtitle: "Mjeku i sheh këto të dhëna para se të nisë thirrja video.",
    nameLabel: "Emri i pacientit",
    ageLabel: "Mosha",
    vitalsLabel: "Vlerat e matura te pacienti",
    reasonLabel: "Arsyeja e thirrjes",
    languageBarrier: "Ka nevojë për përkthim",
    languageHelp: "Mediatori shëndetësor përkthen në gjuhën rome (romanes).",
    notesLabel: "Shënime të tjera",
    submitting: "Po dërgohen të dhënat…",
    submit: "Nis thirrjen video",
    sendError: "Të dhënat nuk u dërguan. Provo përsëri.",
    connectError: "Mjeku nuk u lidh dot. Provo përsëri.",
    demoAge: "68 vjeç",
    demoReason: "Marramendje në mëngjes dhe dhimbje në zverk kur lodhet",
    demoNotes: "Bashkëpunon. Pilulën e fundit të enalaprilit e mori dje në mëngjes.",
  },
  it: {
    liveStatus: "Medico di turno collegato",
    endCall: "Chiudi la chiamata",
    iframeTitle: "Videochiamata con il medico",
    sidePanelLabel: "Supporto durante la chiamata",
    patientLine: (name: string, age: string) => `Paziente: ${name} (${age})`,
    translation: "Traduzione:",
    translationLanguage: "romanì (romanes)",
    bp: "PA",
    pulse: "Polso",
    glucose: "Glicemia",
    temp: "Temp",
    liveNotesLabel: "Note della chiamata",
    tabletTip: "Tieni il tablet rivolto al paziente, così il medico lo vede bene.",
    title: "Passaggio al medico di turno",
    subtitle: "Il medico vede questi dati prima della videochiamata.",
    nameLabel: "Nome del paziente",
    ageLabel: "Età",
    vitalsLabel: "Valori misurati alla visita",
    reasonLabel: "Motivo della chiamata",
    languageBarrier: "Serve la traduzione",
    languageHelp: "Il mediatore traduce in romanì (romanes).",
    notesLabel: "Altre note",
    submitting: "Invio dei dati…",
    submit: "Avvia la videochiamata",
    sendError: "I dati non sono stati inviati. Riprova.",
    connectError: "Impossibile collegare il medico. Riprova.",
    demoAge: "68 anni",
    demoReason: "Capogiri al mattino e dolore alla nuca sotto sforzo",
    demoNotes: "Collabora. Ha preso l'ultima compressa di enalapril ieri mattina.",
  },
  hr: {
    liveStatus: "Dežurni liječnik je spojen",
    endCall: "Završi poziv",
    iframeTitle: "Videokonzultacija s liječnikom",
    sidePanelLabel: "Podrška tijekom poziva",
    patientLine: (name: string, age: string) => `Pacijent: ${name} (${age})`,
    translation: "Prijevod:",
    translationLanguage: "romski (romani)",
    bp: "Krvni tlak",
    pulse: "Puls",
    glucose: "Glukoza u krvi",
    temp: "Temp.",
    liveNotesLabel: "Bilješke iz poziva",
    tabletTip: "Držite tablet okrenut prema pacijentu kako bi ga liječnik dobro vidio.",
    title: "Predaja slučaja dežurnom liječniku",
    subtitle: "Liječnik vidi ove podatke prije početka videokonzultacije.",
    nameLabel: "Ime pacijenta",
    ageLabel: "Dob",
    vitalsLabel: "Izmjerene vrijednosti kod pacijenta",
    reasonLabel: "Razlog poziva",
    languageBarrier: "Potreban je prijevod",
    languageHelp: "Zdravstveni medijator prevodi na romski jezik.",
    notesLabel: "Ostale napomene",
    submitting: "Slanje podataka…",
    submit: "Pokreni videokonzultaciju",
    sendError: "Podatci nisu poslani. Pokušajte ponovno.",
    connectError: "Nije moguće spojiti liječnika. Pokušajte ponovno.",
    demoAge: "68 god.",
    demoReason: "Jutarnja vrtoglavica i bol u zatiljku pri naporu",
    demoNotes: "Surađuje. Zadnju tabletu enalaprila uzela je jučer ujutro.",
  },
  rom: {
    liveStatus: "O doktori si phandino",
    endCall: "Phand o svato",
    iframeTitle: "Video-svato e doktoresa",
    sidePanelLabel: "Zhutipen and-o svato",
    patientLine: (name: string, age: string) => `Paciento: ${name} (${age})`,
    translation: "Nakhavipe:",
    translationLanguage: "romani chhib (romanes)",
    bp: "Tensiyona",
    pulse: "Pulso",
    glucose: "Zaharo",
    temp: "Tatipen",
    liveNotesLabel: "Noturya katar o svato",
    tabletTip: "Inker o tableto karing o paciento te dikhel les o doktori mishto.",
    title: "Dinipe ko doktori pe buchi",
    subtitle: "O doktori dikhel kadale date angla te nachel o video-svato.",
    nameLabel: "Anav e pacientesko",
    ageLabel: "Borsha",
    vitalsLabel: "Merimata ko paciento",
    reasonLabel: "Soske kerel pes o svato",
    languageBarrier: "Trebul nakhavipe pe chhib",
    languageHelp: "O sastipnasko mediatori nakhavel pe romani chhib (romanes).",
    notesLabel: "Aver noturya",
    submitting: "Bichhalen pes e date…",
    submit: "Nachav o video-svato",
    sendError: "E date na bichhaldile. Zumav palem.",
    connectError: "O doktori nashti te phandel pes. Zumav palem.",
    demoAge: "68 borsha",
    demoReason: "Phiravel pes lako shero tosara thaj dukhal e men ko zor",
    demoNotes: "Zhutil. Lya e palutni draba enalapril izdral tosara.",
  },
};

interface MediatorDoctorHandoverProtocolProps {
  initialPatientName?: string;
  initialAge?: string;
  initialVitals?: {
    bloodPressure?: string;
    pulse?: string | number;
    spo2?: string | number;
    glucose?: string | number;
    temp?: string | number;
  };
  meetingId?: string | number;
  onConnected?: (roomId: string) => void;
}

export function MediatorDoctorHandoverProtocol({
  initialPatientName = "Maria Căldăraru",
  initialAge,
  initialVitals = {
    bloodPressure: "155/95 mmHg",
    pulse: "82 bpm",
    spo2: "95%",
    glucose: "142 mg/dL",
    temp: "37.1 °C",
  },
  meetingId = "handover-live-01",
  onConnected,
}: MediatorDoctorHandoverProtocolProps) {
  const { lang } = useSafeLanguage();
  const copy = handoverCopy[lang] ?? handoverCopy.ro;

  const [patientName, setPatientName] = useState(initialPatientName);
  const [age, setAge] = useState(initialAge ?? copy.demoAge);
  // Demo seed text, shown in the active language.
  const [reason, setReason] = useState(copy.demoReason);
  const [languageBarrier, setLanguageBarrier] = useState(true);
  const translationLanguage = copy.translationLanguage;
  const [mediatorNotes, setMediatorNotes] = useState(copy.demoNotes);

  const [isTransmitting, setIsTransmitting] = useState(false);
  const [isCallActive, setIsCallActive] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const handoverIframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    if (!isCallActive) return;
    return subscribeJitsiCallEnd(handoverIframeRef.current, 2, () => {
      setIsCallActive(false);
    });
  }, [isCallActive]);

  const sanitizedMeetingId = String(meetingId).replace(/[^a-zA-Z0-9-_]/g, "");
  const handoverJitsiUrl = buildJitsiEmbedUrl({
    baseRoomUrl: `https://meet.jit.si/redihealth-handover-${sanitizedMeetingId}`,
    apiId: 2,
    toolbarButtons: MEDIATOR_VIDEO_TOOLBAR,
  });

  const handleStartHandover = async () => {
    setIsTransmitting(true);
    setErrorMessage("");

    try {
      const response = await fetch("/api/meetings/mediator-handover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          meetingId,
          patientName,
          patientAge: age,
          vitals: initialVitals,
          reasonForVisit: reason,
          languageBarrier,
          notes: mediatorNotes,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || copy.sendError);
      }

      setIsCallActive(true);
      if (onConnected) {
        onConnected(String(meetingId));
      }
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : copy.connectError);
    } finally {
      setIsTransmitting(false);
    }
  };

  if (isCallActive) {
    // Split tablet view: Top/Left video call with online physician, Bottom/Right mediator translation aid & live notes
    return (
      <div className="rounded-xl border border-border bg-ink-950 text-paper overflow-hidden shadow-lg">
        <div className="flex items-center justify-between border-b border-paper/10 px-4 py-3 bg-ink-900">
          <span className="text-meta font-bold text-white">
            {copy.liveStatus}
          </span>

          <button
            type="button"
            onClick={() => setIsCallActive(false)}
            className="whitespace-nowrap rounded-md border border-white/30 bg-white/10 px-3 py-1 text-body font-semibold text-white transition-colors duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {copy.endCall}
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-0">
          {/* Main video area */}
          <div className="lg:col-span-2 h-[50dvh] lg:h-[60dvh] overflow-hidden bg-ink-950 relative">
            <iframe
              ref={handoverIframeRef}
              src={handoverJitsiUrl}
              title={copy.iframeTitle}
              allow="camera; microphone; fullscreen; display-capture; autoplay"
              scrolling="no"
              style={{ colorScheme: "dark" }}
              className="block h-full w-full overflow-hidden border-0 bg-ink-950"
            />
          </div>

          {/* Mediator side-dock for translation & notes */}
          <div className="border-t lg:border-t-0 lg:border-l border-paper/10 bg-ink-900 p-4 flex flex-col justify-between">
            <div>
              <p className="text-meta font-bold text-sapphire-border">
                {copy.sidePanelLabel}
              </p>
              <h3 className="mt-1 text-body font-bold text-paper">
                {copy.patientLine(patientName, age)}
              </h3>

              {languageBarrier && (
                <div className="mt-3 rounded-md border border-amber-care/40 bg-amber-care/15 p-2 text-meta text-amber-care-border">
                  {copy.translation} <strong>{translationLanguage}</strong>
                </div>
              )}

              <div className="mt-3 space-y-1 text-meta text-mist font-mono bg-paper/5 p-2.5 rounded-md border border-paper/10">
                <p>{copy.bp}: {initialVitals.bloodPressure || "--"}</p>
                <p>{copy.pulse}: {initialVitals.pulse || "--"} | SpO2: {initialVitals.spo2 || "--"}</p>
                <p>{copy.glucose}: {initialVitals.glucose || "--"}</p>
              </div>

              <div className="mt-3">
                <label className="block text-meta font-semibold text-mist mb-1">
                  {copy.liveNotesLabel}
                </label>
                <textarea
                  aria-label={copy.liveNotesLabel}
                  rows={4}
                  value={mediatorNotes}
                  onChange={(e) => setMediatorNotes(e.target.value)}
                  className="w-full rounded-md border border-paper/20 bg-ink-950/60 p-2 text-body text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                />
              </div>
            </div>

            <p className="mt-4 text-meta text-mist border-t border-paper/10 pt-2">
              {copy.tabletTip}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border bg-card p-5 sm:p-6 shadow-xs">
      <div className="flex items-center gap-2 pb-3 mb-4 border-b border-border">
        <VideoIcon className="h-5 w-5 text-sapphire" />
        <div>
          <h2 className="text-body font-bold text-foreground">
            {copy.title}
          </h2>
          <p className="text-meta text-muted-foreground">
            {copy.subtitle}
          </p>
        </div>
      </div>

      {errorMessage && (
        <div
          role="alert"
          className="mb-4 rounded-lg border border-primary/30 bg-primary-soft/75 p-3 text-body font-medium text-foreground dark:border-ruby-300/35 dark:bg-primary/15 dark:text-paper flex items-center gap-2"
        >
          <AlertCircleIcon className="h-4 w-4 shrink-0 text-primary dark:text-ruby-300" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Clinical Vignette Form */}
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-meta font-semibold text-foreground mb-1">
              {copy.nameLabel}
            </label>
            <input
              type="text"
              aria-label={copy.nameLabel}
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              className="w-full min-h-[44px] rounded-lg border border-border-control bg-background px-3 py-2 text-body text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <div>
            <label className="block text-meta font-semibold text-foreground mb-1">
              {copy.ageLabel}
            </label>
            <input
              type="text"
              aria-label={copy.ageLabel}
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className="w-full min-h-[44px] rounded-lg border border-border-control bg-background px-3 py-2 text-body text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>
        </div>

        {/* Vitals Summary Pill Row */}
        <div className="rounded-lg border border-border bg-muted/30 p-3.5">
          <span className="text-meta font-semibold text-muted-foreground">
            {copy.vitalsLabel}
          </span>
          <div className="mt-2 flex flex-wrap gap-2 text-meta font-mono font-bold text-foreground">
            <span className="rounded-md border border-border bg-background px-2.5 py-1">
              {copy.bp}: {initialVitals.bloodPressure || "--"}
            </span>
            <span className="rounded-md border border-border bg-background px-2.5 py-1">
              {copy.pulse}: {initialVitals.pulse || "--"}
            </span>
            <span className="rounded-md border border-border bg-background px-2.5 py-1">
              SpO2: {initialVitals.spo2 || "--"}
            </span>
            <span className="rounded-md border border-border bg-background px-2.5 py-1">
              {copy.glucose}: {initialVitals.glucose || "--"}
            </span>
            <span className="rounded-md border border-border bg-background px-2.5 py-1">
              {copy.temp}: {initialVitals.temp || "--"}
            </span>
          </div>
        </div>

        <div>
          <label className="block text-meta font-semibold text-foreground mb-1">
            {copy.reasonLabel}
          </label>
          <input
            type="text"
            aria-label={copy.reasonLabel}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full min-h-[44px] rounded-lg border border-border-control bg-background px-3 py-2 text-body text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </div>

        {/* Language barrier toggle */}
        <div className="rounded-lg border border-border bg-background p-3 flex items-center justify-between">
          <div>
            <p className="text-meta font-semibold text-foreground">
              {copy.languageBarrier}
            </p>
            <p className="text-meta text-muted-foreground">
              {copy.languageHelp}
            </p>
          </div>
          <input
            type="checkbox"
            aria-label={copy.languageBarrier}
            checked={languageBarrier}
            onChange={(e) => setLanguageBarrier(e.target.checked)}
            className="h-5 w-5 rounded border-border-control accent-sapphire focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          />
        </div>

        <div>
          <label className="block text-meta font-medium text-foreground mb-1">
            {copy.notesLabel}
          </label>
          <textarea
            aria-label={copy.notesLabel}
            rows={2}
            value={mediatorNotes}
            onChange={(e) => setMediatorNotes(e.target.value)}
            className="w-full rounded-lg border border-border-control bg-background px-3 py-2 text-body text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </div>

        <div className="pt-2">
          <Button
            type="button"
            variant="action"
            size="md"
            fullWidth
            disabled={isTransmitting}
            onClick={handleStartHandover}
          >
            <VideoIcon className="h-4 w-4 shrink-0" />
            {isTransmitting ? copy.submitting : copy.submit}
          </Button>
        </div>
      </div>
    </div>
  );
}
