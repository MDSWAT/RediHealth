"use client";

import { Button } from "@/components/ui/Button";
import { StethoscopeIcon } from "@/components/ui/icons";
import { useLanguage } from "@/lib/i18n/language-context";
import { DEFAULT_LANG, withLangPrefix } from "@/lib/i18n/routing";
import type { Lang } from "@/lib/i18n/translations";

interface PrescriptionDoctorBridgeProps {
  className?: string;
}

const PRESCRIPTION_DOCTOR_BRIDGE_COPY: Record<
  Lang,
  { heading: string; body: string; buttonText: string }
> = {
  ru: {
    heading: "Не уверены в своем рецепте?",
    body: "Не уверены, что эти лекарства безопасны с другими таблетками, которые вы принимаете? Прежде чем начать, поговорите с врачом онлайн бесплатно.",
    buttonText: "Спросить врача онлайн",
  },
  en: {
    heading: "Not sure about your prescription?",
    body: "Not sure these medicines are safe with other pills you take? Talk to a doctor online for free before you start them.",
    buttonText: "Ask a doctor online",
  },
  ro: {
    heading: "Nu înțelegi ceva din rețetă?",
    body: "Nu știi dacă aceste medicamente merg cu alte pastile pe care le iei? Vorbește gratuit cu un medic online înainte să le iei.",
    buttonText: "Întreabă un medic online",
  },
  sq: {
    heading: "Nuk e kupton diçka në recetë?",
    body: "Nuk je i sigurt nëse këto ilaçe shkojnë me ilaçet e tjera që merr? Fol falas me një mjek online para se t'i fillosh.",
    buttonText: "Pyet një mjek online",
  },
  it: {
    heading: "Hai dubbi sulla ricetta?",
    body: "Non sai se questi farmaci vanno bene insieme ad altri che prendi? Parla gratuitamente con un medico online prima di iniziarli.",
    buttonText: "Chiedi a un medico online",
  },
  hr: {
    heading: "Nešto ti nije jasno na receptu?",
    body: "Nisi siguran ili sigurna idu li ovi lijekovi uz druge tablete koje uzimaš? Razgovaraj besplatno s liječnikom online prije nego što ih počneš uzimati.",
    buttonText: "Pitaj liječnika online",
  },
  rom: {
    heading: "Na haljares vareso and-i receta?",
    body: "Na dzanes te djan kadala drabura avre xapensa so les? Vorbin bi lovengo jekhe doktorestar online angla te nachaves len.",
    buttonText: "Phuch doktores online",
  },
};

export function getPrescriptionDoctorBridgeCopy(lang: Lang) {
  return PRESCRIPTION_DOCTOR_BRIDGE_COPY[lang] || PRESCRIPTION_DOCTOR_BRIDGE_COPY[DEFAULT_LANG];
}

export function PrescriptionDoctorBridge({ className = "" }: PrescriptionDoctorBridgeProps) {
  const { lang } = useLanguage();
  const t = getPrescriptionDoctorBridgeCopy(lang);

  const targetUrl = withLangPrefix("/medic-online?source=prescription", lang);

  return (
    <section className={`mt-8 border-t border-border pt-6 ${className}`}>
      <div className="flex flex-col items-start gap-4">
        <div>
          <h3 className="text-balance text-body font-semibold text-foreground">{t.heading}</h3>
          <p className="mt-1 max-w-xl text-body text-muted-foreground">{t.body}</p>
        </div>
        <Button
          href={targetUrl}
          variant="action"
          size="lg"
          className="w-full shrink-0 sm:w-auto print:hidden"
        >
          <StethoscopeIcon className="h-4 w-4 shrink-0" />
          <span>{t.buttonText}</span>
        </Button>
      </div>
    </section>
  );
}
