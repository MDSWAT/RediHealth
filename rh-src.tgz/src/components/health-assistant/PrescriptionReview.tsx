"use client";

import { useRecaptcha } from "@/components/security/RecaptchaProvider";
/* eslint-disable @next/next/no-img-element -- preview is an object URL from user file */

import { useEffect, useRef, useState, type CSSProperties } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { ListenButton } from "@/components/ui/ListenButton";
import { PageHeader } from "@/components/ui/PageHeader";
import {
  AlertCircleIcon,
  ArrowRightIcon,
  CameraIcon,
  CheckCircleIcon,
  ImageIcon,
  PinIcon,
  TrashIcon,
} from "@/components/ui/icons";
import { useAssistantCopy } from "@/components/health-assistant/assistant-copy";
import { AssistantNavigation, AssistantOtherTools } from "@/components/health-assistant/AssistantNavigation";
import { getPrescriptionDoctorBridgeCopy } from "@/components/health-assistant/PrescriptionDoctorBridge";
import { PrescriptionStructuredResult } from "@/components/health-assistant/PrescriptionStructuredResult";
import { useReadAloud } from "@/components/health-check/readingTools";
import { prefersCalmOrReducedMotion, useReadingLevel } from "@/lib/comfort-preferences";
import { Container } from "@/components/ui/Container";
import type { DocumentSourceKind, PrescribedMedicineItem } from "@/lib/health-assistant";
import { prepareMedicalImageForUpload } from "@/lib/image";
import { findHelpLinks } from "@/lib/i18n/find-help-links";
import { useLanguage } from "@/lib/i18n/language-context";
import { DEFAULT_LANG, withLangPrefix } from "@/lib/i18n/routing";
import { translations, type Lang } from "@/lib/i18n/translations";

type ReviewResponse = {
  message: string;
  prescriptionText?: string;
  medicines?: PrescribedMedicineItem[];
  sourceKind?: DocumentSourceKind;
  confidenceScore?: number;
  confidenceReason?: string;
  urgency?: "emergency" | "routine";
  careLevel?: "emergency" | "urgent" | "soon" | "routine";
};

type ReasonChipKey = "feverPain" | "coughCold" | "heartBp" | "stomach" | "child" | "notSure";

const REASON_ORDER: ReasonChipKey[] = ["feverPain", "coughCold", "heartBp", "stomach", "child", "notSure"];

interface PrescriptionReviewCopy {
  title: string;
  subtitle: string;
  listenPage: string;
  stopListening: string;
  largeTextLabel: string;
  stepOneBadge: string;
  dropTitle: string;
  cameraCapture: string;
  galleryUpload: string;
  removePhoto: string;
  photoReady: string;
  retakeLight: string;
  tipLine: string;
  dragOrBrowse: string;
  skeletonHeading: string;
  qualityWarning: string;
  stepTwoBadge: string;
  whyLabel: string;
  whyHint: string;
  reasons: Record<ReasonChipKey, string>;
  noteLabel: string;
  whyPh: string;
  reviewButton: string;
  reviewing: string;
  reviewingHint: string;
  uploadReqErr: string;
  fileErr: string;
  readErr: string;
  serviceErr: string;
  reviewErr: string;
  reviewErrLink: string;
  rateLimitErr: string;
  previewAlt: string;
}

class ReadError extends Error {}


function ReasonChipIcon({ reason }: { reason: ReasonChipKey }) {
  switch (reason) {
    case "feverPain":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <path
            d="M11.5 11.2V4.75a1.5 1.5 0 0 0-3 0v6.45a3.25 3.25 0 1 0 3 0Z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="10" cy="13.75" r="1.2" fill="currentColor" />
        </svg>
      );
    case "coughCold":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <path
            d="M10 3.5v6.2M10 7.5c-2.6 0-5 2-5 5.3 0 1.8 1.2 3.2 2.8 3.2 1.2 0 2.2-.8 2.2-2.1M10 7.5c2.6 0 5 2 5 5.3 0 1.8-1.2 3.2-2.8 3.2-1.2 0-2.2-.8-2.2-2.1"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "heartBp":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <path
            d="M10 16.4s-6-3.7-6-8.1a3.4 3.4 0 0 1 6-2.1 3.4 3.4 0 0 1 6 2.1c0 4.4-6 8.1-6 8.1Z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "stomach":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <path
            d="M8.5 3.5v2.7c0 1.3-2.5 2.1-2.5 4.9 0 2.9 2.1 5.1 5 5.1 2.7 0 4.5-1.8 4.5-4.3 0-2.2-1.6-3.7-3.8-3.7-.9 0-1.7.3-2.2.8"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "child":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <circle cx="10" cy="6.25" r="2.75" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M5.25 16.25a4.75 4.75 0 0 1 9.5 0"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      );
    case "notSure":
      return (
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="h-4 w-4 shrink-0">
          <circle cx="10" cy="10" r="6.75" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M8.4 8a1.75 1.75 0 0 1 3.35.65c0 1.2-1.75 1.55-1.75 2.75"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <circle cx="10" cy="13.9" r="0.85" fill="currentColor" />
        </svg>
      );
  }
}

function ArrowRightSvg() {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" className="arrow-travel h-4 w-4 shrink-0">
      <path
        d="M4.25 10h11.5m0 0-4.25-4.25M15.75 10l-4.25 4.25"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function PrescriptionReview() {
  const executeCaptcha = useRecaptcha();
  const { lang } = useLanguage();
  const voice = useReadAloud(lang);
  const [readingLevel] = useReadingLevel();
  const assistantCopy = useAssistantCopy();
  const doctorBridge = getPrescriptionDoctorBridgeCopy(lang);
  const helpLinks = findHelpLinks(lang);
  const headerCopy = translations[lang]?.header ?? translations[DEFAULT_LANG].header;
  const safetyRules = readingLevel === "simple" ? assistantCopy.rx.plainRules : assistantCopy.rx.rules;

  const dict: Record<Lang, PrescriptionReviewCopy> = {
  ru: {
"listenPage": "Слушать",
"stopListening": "Стоп",
"largeTextLabel": "Крупнее",
"stepOneBadge": "Шаг 1 из 2",
"photoReady": "Фото готово",
"retakeLight": "Переснять при хорошем освещении",
"tipLine": "Положите лист или коробку ровно при дневном свете, чтобы название и текст были чёткими.",
"dragOrBrowse": "или перетащите фото сюда",
"stepTwoBadge": "Шаг 2 из 2",
"reasons": {"feverPain":"Температура или боль","coughCold":"Кашель или простуда","heartBp":"Сердце или давление","stomach":"Желудок или пищеварение","child":"Для ребёнка","notSure":"Не знаю"},
"noteLabel": "Или кратко опишите своими словами (необязательно)",













"removePhoto": "Удалить фото",
"skeletonHeading": "Подготовка понятного объяснения…",

      title: "Объяснить рецепт",
      subtitle: "Сфотографируйте рецепт или коробку с лекарством — объясним всё простыми словами. Всегда уточняйте детали у фармацевта или врача.",
      dropTitle: "Добавьте фото рецепта или упаковки",
      cameraCapture: "Сфотографироваться",
      galleryUpload: "Выбрать из галереи",

      qualityWarning:
        "Фотография выглядит немного темной или размытой. Попробуйте еще раз при дневном свете, чтобы текст легко читался.",
      whyLabel: "Почему это было предписано? (необязательно)",
      whyHint: "Это помогает ассистенту понять рецепт. Вам не обязательно знать диагноз.",
      whyPh: "Например: у меня это появилось после визита к врачу по поводу боли в горле и температуры…",
      reviewButton: "Прочтите рецепт",
      reviewing: "Читая ваш рецепт…",
      reviewingHint: "Это может занять до минуты. Держите эту страницу открытой.",
      uploadReqErr: "Чтобы продолжить, сделайте или загрузите фотографию вашего рецепта.",
      fileErr: "Этот файл не удаётся открыть как фото. Сделайте новое фото.",
      readErr: "Нам не удалось прочитать этот файл изображения. Попробуйте другое фото.",
      serviceErr:
        "Автоматическое чтение фото временно недоступно. Попробуйте позже или покажите рецепт или упаковку фармацевту.",
      reviewErr: "Не удалось прочитать рецепт. Покажите его фармацевту или",
      reviewErrLink: "попросите помощи у человека",
      rateLimitErr: "Подождите одну минуту и попробуйте снова.",
      previewAlt: "Фотография выбранного вами рецепта",
    },

    en: {
      title: "Explain my prescription",
      subtitle:
        "Photograph your prescription or medicine box and we explain it clearly. Always check with your pharmacist or doctor.",
      listenPage: "Listen",
      stopListening: "Stop",
      largeTextLabel: "Larger text",
      stepOneBadge: "Step 1 of 2",
      dropTitle: "Add your prescription or medicine box",
      cameraCapture: "Take a photo",
      galleryUpload: "Choose a photo",
      removePhoto: "Remove photo",
      photoReady: "Photo is ready",
      retakeLight: "Take another photo in good light",
      tipLine: "Lay the sheet or box flat in daylight so the text and name are easy to read.",
      dragOrBrowse: "or drag a photo here",
      skeletonHeading: "Preparing clear explanation…",
      qualityWarning:
        "The photo looks a little dark or blurry. Try again in daylight so the text is easy to read.",
      stepTwoBadge: "Step 2 of 2",
      whyLabel: "Why was this prescribed? (optional)",
      whyHint: "Tap what fits, or go straight to reading the prescription. No typing needed.",
      reasons: {
        feverPain: "Fever or pain",
        coughCold: "Cough or cold",
        heartBp: "Heart or blood pressure",
        stomach: "Stomach or digestion",
        child: "For a child",
        notSure: "Not sure",
      },
      noteLabel: "Or write briefly in your own words (optional)",
      whyPh: "For example: I got it after a doctor's visit for a sore throat and fever…",
      reviewButton: "Explain prescription",
      reviewing: "Reading prescription…",
      reviewingHint: "This can take up to a minute. Keep this page open.",
      uploadReqErr: "Take or upload a photo of your prescription to continue.",
      fileErr: "This file is not a photo we can open. Take a new photo instead.",
      readErr: "We could not read that image file. Try another photo.",
      serviceErr:
        "Automatic photo reading is temporarily unavailable. Please try again later or show the prescription or medicine box to your pharmacist.",
      reviewErr: "We could not read this prescription. Show it to your pharmacist, or",
      reviewErrLink: "ask a person for help",
      rateLimitErr: "Please wait one minute, then try again.",
      previewAlt: "Photo of the prescription you selected",
    },
    ro: {
      title: "Explică-mi rețeta",
      subtitle:
        "Fă o poză rețetei sau cutiei de medicamente și ți-o explicăm pe înțeles. Verifică mereu cu farmacistul sau medicul.",
      listenPage: "Ascultă",
      stopListening: "Oprește",
      largeTextLabel: "Scris mai mare",
      stepOneBadge: "Pasul 1 din 2",
      dropTitle: "Adaugă rețeta sau cutia medicamentului",
      cameraCapture: "Fă o poză",
      galleryUpload: "Alege o poză",
      removePhoto: "Șterge poza",
      photoReady: "Poza este pregătită",
      retakeLight: "Fă altă poză la lumină",
      tipLine: "Pune foaia sau cutia pe masă, la lumină naturală, cu numele și textul bine încadrate.",
      dragOrBrowse: "sau trage o poză aici",
      skeletonHeading: "Pregătim explicația pe înțeles…",
      qualityWarning:
        "Poza pare întunecată sau neclară. Încearcă din nou la lumina zilei, ca textul să se vadă bine.",
      stepTwoBadge: "Pasul 2 din 2",
      whyLabel: "De ce ai primit rețeta? (opțional)",
      whyHint: "Atinge un motiv dacă îl știi sau apasă direct pe butonul de mai jos. Nu trebuie să scrii.",
      reasons: {
        feverPain: "Durere sau febră",
        coughCold: "Tuse sau răceală",
        heartBp: "Inimă sau tensiune",
        stomach: "Stomac sau digestie",
        child: "Pentru un copil",
        notSure: "Nu știu exact",
      },
      noteLabel: "Sau scrie pe scurt cu cuvintele tale (opțional)",
      whyPh: "De exemplu: am primit rețeta după o vizită la medic pentru durere în gât și febră…",
      reviewButton: "Citește și explică rețeta",
      reviewing: "Se citește rețeta…",
      reviewingHint: "Poate dura până la un minut. Lasă pagina deschisă.",
      uploadReqErr: "Fă sau încarcă o poză a rețetei ca să continui.",
      fileErr: "Acest fișier nu este o poză pe care o putem deschide. Fă o poză nouă.",
      readErr: "Nu am putut deschide poza. Încearcă altă poză.",
      serviceErr:
        "Citirea automată a pozelor este temporar indisponibilă. Încearcă mai târziu sau arată rețeta ori cutia farmacistului.",
      reviewErr: "Nu am putut citi această rețetă. Arat-o farmacistului sau",
      reviewErrLink: "cere ajutor unei persoane",
      rateLimitErr: "Așteaptă un minut, apoi încearcă din nou.",
      previewAlt: "Poza rețetei alese",
    },
    sq: {
      title: "Shpjego recetën time",
      subtitle:
        "Fotografo recetën ose kutinë e ilaçit dhe ta shpjegojmë qartë. Kontrolloje gjithmonë me farmacistin ose mjekun.",
      listenPage: "Dëgjo",
      stopListening: "Ndalo",
      largeTextLabel: "Shkrim më i madh",
      stepOneBadge: "Hapi 1 nga 2",
      dropTitle: "Shto recetën ose kutinë e ilaçit",
      cameraCapture: "Bëj një foto",
      galleryUpload: "Zgjidh një foto",
      removePhoto: "Hiq foton",
      photoReady: "Fotoja është gati",
      retakeLight: "Bëj një foto tjetër në dritë",
      tipLine: "Vendose fletën ose kutinë drejt, në dritë natyrale, që emri dhe teksti të lexohen qartë.",
      dragOrBrowse: "ose tërhiq një foto këtu",
      skeletonHeading: "Po përgatitet shpjegimi i qartë…",
      qualityWarning:
        "Fotoja duket pak e errët ose e paqartë. Provo përsëri në dritë natyrale, që teksti të lexohet mirë.",
      stepTwoBadge: "Hapi 2 nga 2",
      whyLabel: "Pse të është dhënë kjo recetë? (sipas dëshirës)",
      whyHint: "Prek arsyen nëse e di, ose vazhdo direkt te leximi i recetës. Nuk ka nevojë të shkruash.",
      reasons: {
        feverPain: "Dhimbje ose temperaturë",
        coughCold: "Kollë ose ftohje",
        heartBp: "Zemër ose presion",
        stomach: "Stomak ose tretje",
        child: "Për një fëmijë",
        notSure: "Nuk jam i sigurt",
      },
      noteLabel: "Ose shkruaj shkurt me fjalët e tua (sipas dëshirës)",
      whyPh: "Për shembull: e mora pas një vizite te mjeku për dhimbje fyti dhe temperaturë…",
      reviewButton: "Lexo dhe shpjego recetën",
      reviewing: "Po lexohet receta…",
      reviewingHint: "Mund të zgjasë deri në një minutë. Mbaje faqen të hapur.",
      uploadReqErr: "Bëj ose ngarko një foto të recetës për të vazhduar.",
      fileErr: "Ky skedar nuk është një foto që mund ta hapim. Bëj një foto të re.",
      readErr: "Nuk mundëm ta hapim këtë foto. Provo një foto tjetër.",
      serviceErr:
        "Leximi automatik i fotove është përkohësisht i padisponueshëm. Provo më vonë ose tregoja recetën apo kutinë farmacistit.",
      reviewErr: "Nuk mundëm ta lexojmë këtë recetë. Tregoja farmacistit ose",
      reviewErrLink: "kërko ndihmë nga një person",
      rateLimitErr: "Të lutem prit një minutë, pastaj provo përsëri.",
      previewAlt: "Foto e recetës që zgjodhe",
    },
    it: {
      title: "Spiegami la ricetta",
      subtitle:
        "Fotografa la ricetta o la scatola del farmaco e te la spieghiamo con chiarezza. Verifica sempre con il farmacista o il medico.",
      listenPage: "Ascolta",
      stopListening: "Ferma",
      largeTextLabel: "Testo più grande",
      stepOneBadge: "Passo 1 di 2",
      dropTitle: "Aggiungi la ricetta o la scatola",
      cameraCapture: "Scatta una foto",
      galleryUpload: "Scegli una foto",
      removePhoto: "Rimuovi foto",
      photoReady: "La foto è pronta",
      retakeLight: "Scatta un'altra foto alla luce",
      tipLine: "Appoggia il foglio o la scatola in piano alla luce del giorno, con nome e testo ben visibili.",
      dragOrBrowse: "oppure trascina una foto qui",
      skeletonHeading: "Preparazione della spiegazione chiara…",
      qualityWarning:
        "La foto sembra un po' scura o sfocata. Riprova con la luce naturale, così il testo si legge correttamente.",
      stepTwoBadge: "Passo 2 di 2",
      whyLabel: "Perché ti è stata prescritta? (facoltativo)",
      whyHint: "Tocca un motivo se lo conosci, oppure vai direttamente alla lettura. Non serve scrivere.",
      reasons: {
        feverPain: "Febbre o dolore",
        coughCold: "Tosse o raffreddore",
        heartBp: "Cuore o pressione",
        stomach: "Stomaco o digestione",
        child: "Per un bambino",
        notSure: "Non lo so di preciso",
      },
      noteLabel: "Oppure scrivi in breve con parole tue (facoltativo)",
      whyPh: "Ad esempio: l'ho ricevuta dopo una visita per mal di gola e febbre…",
      reviewButton: "Leggi e spiega la ricetta",
      reviewing: "Lettura ricetta…",
      reviewingHint: "Può richiedere fino a un minuto. Tieni aperta questa pagina.",
      uploadReqErr: "Scatta o carica una foto della ricetta per continuare.",
      fileErr: "Questo file non è una foto che possiamo aprire. Scatta una nuova foto.",
      readErr: "Non siamo riusciti a leggere il file dell'immagine. Prova con un'altra foto.",
      serviceErr:
        "La lettura automatica delle foto non è temporaneamente disponibile. Riprova più tardi o mostra la ricetta o la scatola al farmacista.",
      reviewErr: "Non siamo riusciti a leggere questa ricetta. Mostrala al tuo farmacista, oppure",
      reviewErrLink: "chiedi aiuto a una persona",
      rateLimitErr: "Attendi un minuto, poi riprova.",
      previewAlt: "Foto della ricetta selezionata",
    },
    hr: {
      title: "Objasni mi recept",
      subtitle:
        "Fotografiraj recept ili kutiju lijeka i objasnit ćemo ti sve jasno. Uvijek provjeri s ljekarnikom ili liječnikom.",
      listenPage: "Poslušaj",
      stopListening: "Zaustavi",
      largeTextLabel: "Veća slova",
      stepOneBadge: "Korak 1 od 2",
      dropTitle: "Dodaj recept ili kutiju lijeka",
      cameraCapture: "Snimi fotografiju",
      galleryUpload: "Odaberi fotografiju",
      removePhoto: "Ukloni fotografiju",
      photoReady: "Fotografija je spremna",
      retakeLight: "Snimi drugu fotografiju na svjetlu",
      tipLine: "Položi list ili kutiju ravno na dnevnom svjetlu tako da se naziv i tekst jasno vide.",
      dragOrBrowse: "ili povuci fotografiju ovdje",
      skeletonHeading: "Pripremamo jasno objašnjenje…",
      qualityWarning:
        "Fotografija izgleda pomalo tamno ili mutno. Pokušaj ponovno na dnevnom svjetlu kako bi tekst bio čitljiv.",
      stepTwoBadge: "Korak 2 od 2",
      whyLabel: "Zašto si dobio ili dobila ovaj recept? (nije obavezno)",
      whyHint: "Dodirni razlog ako ga znaš ili odmah kreni na čitanje recepta. Ne moraš pisati.",
      reasons: {
        feverPain: "Bol ili vrućica",
        coughCold: "Kašalj ili prehlada",
        heartBp: "Srce ili tlak",
        stomach: "Želudac ili probava",
        child: "Za dijete",
        notSure: "Nisam siguran",
      },
      noteLabel: "Ili kratko napiši svojim riječima (nije obavezno)",
      whyPh: "Na primjer: dobio sam ga nakon pregleda kod liječnika zbog grlobolje i vrućice…",
      reviewButton: "Pročitaj i objasni recept",
      reviewing: "Čitanje recepta u tijeku…",
      reviewingHint: "Ovo može potrajati do jedne minute. Ostavi ovu stranicu otvorenom.",
      uploadReqErr: "Snimi ili učitaj fotografiju recepta za nastavak.",
      fileErr: "Ova datoteka nije fotografija koju možemo otvoriti. Snimi novu fotografiju.",
      readErr: "Nismo uspjeli otvoriti tu slikovnu datoteku. Pokušaj s drugom fotografijom.",
      serviceErr:
        "Automatsko čitanje fotografija trenutačno nije dostupno. Pokušaj kasnije ili pokaži recept ili kutiju ljekarniku.",
      reviewErr: "Nismo uspjeli pročitati ovaj recept. Pokaži ga ljekarniku ili",
      reviewErrLink: "zatraži pomoć osobe",
      rateLimitErr: "Pričekaj jednu minutu, pa pokušaj ponovno.",
      previewAlt: "Fotografija odabranog recepta",
    },
    rom: {
      title: "Xatyar mange i receta",
      subtitle:
        "Ker poza chire recetake vaj e drabaki kutijake thaj shpjeginas la tuke chaches. Dikh svako data le farmacistosa vaj le doktoresa.",
      listenPage: "Ashun",
      stopListening: "Achav",
      largeTextLabel: "Maj baro ramovimos",
      stepOneBadge: "Pasho 1 katar 2",
      dropTitle: "Thov i receta vaj i drabaki kutija",
      cameraCapture: "Ker poza",
      galleryUpload: "Alosar jekh poza",
      removePhoto: "Khos i poza",
      photoReady: "I poza si gata",
      retakeLight: "Ker aver poza ko vudud",
      tipLine: "Thov o lil vaj i kutija pre masi, and-o divesko vudud, te dikhljol o anav thaj o teksto mishto.",
      dragOrBrowse: "vaj thov jekh poza kathe",
      skeletonHeading: "Pregatisaras o chacho shpjegimos…",
      qualityWarning:
        "I poza dikljol xantsi kali vaj na uzi. Zumav pale ko divesko vudud kaste ginavel pe o teksto mishto.",
      stepTwoBadge: "Pasho 2 katar 2",
      whyLabel: "Soske ljan kadaja receta? (te manges)",
      whyHint: "Azba jekh motivo te dzanes les, vaj dja sigo ko ginavimos e recetako. Na trebul te ramos.",
      reasons: {
        feverPain: "Dukh vaj tatipen",
        coughCold: "Khas vaj shil",
        heartBp: "Ilo vaj tensia",
        stomach: "Ogi vaj xabem",
        child: "Vash jekh chavoro",
        notSure: "Na dzanav chaches",
      },
      noteLabel: "Vaj ramov skurto chire vorbenca (te manges)",
      whyPh: "Misal: ljem la pala jekh drom ko doktori vash dukh and-o korr thaj tatipen…",
      reviewButton: "Shpjegin i receta",
      reviewing: "Ginavel pe i receta…",
      reviewingHint: "Shaj djal dji ko jekh minuto. Mekh kadaja rig puterdi.",
      uploadReqErr: "Ker vaj thov jekh poza e recetaki te djas maj dur.",
      fileErr: "Kadava fajlo naj poza kaj shaj phuteras la. Ker jekh nevi poza.",
      readErr: "Nashti phuterdas kadaja poza. Zumav aver poza.",
      serviceErr:
        "O automatikano ginavimos e pozengo na kamel akana. Zumav maj palal vaj sikav i receta ori i kutija ke farmacisto.",
      reviewErr: "Nashti ginadas kadaja receta. Sikav la ke farmacisto vaj",
      reviewErrLink: "mang zhutimos katar ekh manush",
      rateLimitErr: "Azhuker jekh minuta, porme zumav pale.",
      previewAlt: "Poza katar i alosardi receta",
    },
  };
  const t = dict[lang] || dict[DEFAULT_LANG];

  const cameraInput = useRef<HTMLInputElement>(null);
  const galleryInput = useRef<HTMLInputElement>(null);
  const stepTwoRef = useRef<HTMLDivElement>(null);
  const resultSectionRef = useRef<HTMLElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedReasons, setSelectedReasons] = useState<ReasonChipKey[]>([]);
  const [context, setContext] = useState("");
  const [result, setResult] = useState<ReviewResponse | null>(null);
  const [qualityState, setQualityState] = useState<"idle" | "checking" | "good" | "warn">("idle");
  const [errorKind, setErrorKind] = useState<
    "file" | "uploadReq" | "read" | "rateLimit" | "service" | "review" | null
  >(null);
  const errorMessages = {
    file: t.fileErr,
    uploadReq: t.uploadReqErr,
    read: t.readErr,
    rateLimit: t.rateLimitErr,
    service: t.serviceErr,
    review: t.reviewErr,
  };
  const errorAlert = errorKind ? (
    <div
      role="alert"
      className="swap-in flex items-start gap-2.5 rounded-lg border border-border bg-card p-3.5 text-body font-medium text-foreground dark:border-ink-800 dark:bg-ink-900"
    >
      <AlertCircleIcon className="mt-0.5 h-4 w-4 shrink-0 text-amber-care dark:text-amber-care-border" />
      <span>
        {errorMessages[errorKind]}
        {errorKind === "review" ? (
          <>
            {" "}
            <Link
              href={withLangPrefix("/get-help?mode=mediator", lang)}
              className="rounded-xs font-semibold text-foreground underline decoration-amber-care decoration-2 underline-offset-4 transition-colors duration-[var(--dur-fast)] hover:text-sapphire focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1"
            >
              {t.reviewErrLink}
            </Link>
            .
          </>
        ) : null}
      </span>
    </div>
  ) : null;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  function getScrollBehavior(): ScrollBehavior {
    if (prefersCalmOrReducedMotion()) {
      return "auto";
    }
    return "smooth";
  }

  // Client-side lighting and blur pre-check (Change 44)
  function checkImageQuality(imageUrl: string) {
    setQualityState("checking");
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        setQualityState("good");
        return;
      }

      canvas.width = 160;
      canvas.height = 160;
      ctx.drawImage(img, 0, 0, 160, 160);

      try {
        const imageData = ctx.getImageData(0, 0, 160, 160);
        const data = imageData.data;
        const pixels = data.length / 4;
        let sum = 0;
        let sumSquares = 0;
        for (let i = 0; i < data.length; i += 4) {
          const brightness = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
          sum += brightness;
          sumSquares += brightness * brightness;
        }
        const mean = sum / pixels;
        const stdDev = Math.sqrt(Math.max(0, sumSquares / pixels - mean * mean));

        // Warn when the photo is too dark, or so uniform that no writing stands out.
        setQualityState(mean < 60 || stdDev < 10 ? "warn" : "good");
      } catch {
        setQualityState("good");
      }
    };
    img.onerror = () => {
      setQualityState("good");
    };
    img.src = imageUrl;
  }

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  useEffect(() => {
    if (!preview) return;
    const timer = window.setTimeout(() => {
      stepTwoRef.current?.scrollIntoView({ behavior: getScrollBehavior(), block: "nearest" });
    }, 80);
    return () => window.clearTimeout(timer);
  }, [preview]);

  useEffect(() => {
    if (!result) return;
    const timer = window.setTimeout(() => {
      resultSectionRef.current?.scrollIntoView({ behavior: getScrollBehavior(), block: "start" });
    }, 80);
    return () => window.clearTimeout(timer);
  }, [result]);

  function handleHeaderListen() {
    if (voice.speaking) {
      voice.stop();
      return;
    }
    voice.speak([t.title, t.subtitle, t.tipLine]);
  }

  function toggleReasonChip(reason: ReasonChipKey) {
    setSelectedReasons((prev) => {
      if (reason === "notSure") {
        return prev.includes("notSure") ? [] : ["notSure"];
      }
      const withoutNotSure = prev.filter((item) => item !== "notSure");
      if (withoutNotSure.includes(reason)) {
        return withoutNotSure.filter((item) => item !== reason);
      }
      return [...withoutNotSure, reason];
    });
  }

  function handleRemovePhoto() {
    if (preview) URL.revokeObjectURL(preview);
    setFile(null);
    setPreview(null);
    setQualityState("idle");
    setErrorKind(null);
    setResult(null);
    if (cameraInput.current) cameraInput.current.value = "";
    if (galleryInput.current) galleryInput.current.value = "";
  }

  function handleFileSelected(selected: File | null) {
    setErrorKind(null);
    setResult(null);
    if (!selected) return;

    const looksLikeImage =
      selected.type.startsWith("image/") ||
      /\.(heic|heif|jpg|jpeg|png|webp|avif)$/i.test(selected.name);

    if (!looksLikeImage || selected.size > 15 * 1024 * 1024) {
      if (preview) URL.revokeObjectURL(preview);
      setFile(null);
      setPreview(null);
      setQualityState("idle");
      setErrorKind("file");
      return;
    }

    if (preview) URL.revokeObjectURL(preview);
    const objectUrl = URL.createObjectURL(selected);
    setFile(selected);
    setPreview(objectUrl);
    checkImageQuality(objectUrl);
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file) {
      setErrorKind("uploadReq");
      return;
    }

    setErrorKind(null);
    setResult(null);
    setIsSubmitting(true);

    const selectedChipLabels = REASON_ORDER.filter((key) => selectedReasons.includes(key)).map(
      (key) => t.reasons[key]
    );
    const combinedPrescriptionContext = [selectedChipLabels.join(", "), context.trim()]
      .filter(Boolean)
      .join(". ");

    try {
      let prescription: { mimeType: string; data: string };
      try {
        prescription = await prepareMedicalImageForUpload(file);
      } catch {
        throw new ReadError();
      }

      const captchaToken = await executeCaptcha("health_assistant");
      const response = await fetch("/api/health-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prescriptionContext: combinedPrescriptionContext,
          prescription,
          lang,
          captchaToken,
        }),
      });

      // Server errors are written in English; the person always sees a message in their language.
      if (!response.ok) {
        if (response.status === 429) setErrorKind("rateLimit");
        else if (response.status === 503) setErrorKind("service");
        else setErrorKind("review");
        return;
      }
      setResult((await response.json()) as ReviewResponse);
    } catch (caughtError) {
      setErrorKind(caughtError instanceof ReadError ? "read" : "review");
    } finally {
      setIsSubmitting(false);
    }
  }

  const currentStep = preview ? 2 : 1;
  const currentStepLabel = preview ? t.stepTwoBadge : t.stepOneBadge;

  return (
    <main
      id="main-content"
      className="flex-1 pt-2 pb-10 sm:pt-3 sm:pb-14"
    >
      <Container>
        <AssistantNavigation />

        <PageHeader
          className="print:hidden"
          title={t.title}
          lead={t.subtitle}
          actions={
            voice.available ? (
              <ListenButton
                uiLang={lang}
                autoRead
                isPlaying={voice.speaking}
                onToggle={handleHeaderListen}
              />
            ) : undefined
          }
        />

        <div className="mt-5 grid gap-6 sm:mt-6 lg:grid-cols-[minmax(0,1fr)_21rem] lg:items-start xl:grid-cols-[minmax(0,1fr)_24rem] xl:gap-8 print:block">
          <div className="min-w-0 space-y-6">
            <section className="rounded-2xl border border-border bg-card shadow-xs print:hidden">
              <form onSubmit={handleSubmit} className="space-y-6 p-5 sm:p-8" aria-busy={isSubmitting}>
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2.5">
                    <p className="whitespace-nowrap text-meta font-medium text-muted-foreground tabular-nums">
                      {currentStepLabel}
                    </p>
                  </div>

                  <div
                    className="mt-3 flex h-1 w-full gap-1.5"
                    role="progressbar"
                    aria-label={t.title}
                    aria-valuenow={currentStep}
                    aria-valuemin={1}
                    aria-valuemax={2}
                    aria-valuetext={currentStepLabel}
                  >
                    {[1, 2].map((segment) => (
                      <div
                        key={segment}
                        className={`h-1 flex-1 rounded-sm transition-colors duration-[var(--dur-base)] ease-[var(--ease-out-calm)] ${
                          currentStep >= segment ? "bg-sapphire dark:bg-sapphire-border" : "bg-border"
                        }`}
                      />
                    ))}
                  </div>
                </div>

            {/* Separate inputs: one opens the camera directly on phones, the other the gallery. */}
            <input
              ref={cameraInput}
              type="file"
              accept="image/*"
              capture="environment"
              tabIndex={-1}
              aria-hidden="true"
              onChange={(e) => handleFileSelected(e.target.files?.[0] ?? null)}
              className="sr-only"
            />
            <input
              ref={galleryInput}
              type="file"
              accept="image/*"
              tabIndex={-1}
              aria-hidden="true"
              onChange={(e) => handleFileSelected(e.target.files?.[0] ?? null)}
              className="sr-only"
            />

            {/* Step 1: Visual capture dropzone */}
            {preview ? (
              <div className="swap-in rounded-2xl border border-border bg-surface-subtle/30 p-5 text-center sm:p-7">
                <p className="text-body font-semibold text-foreground">{t.photoReady}</p>

                <figure className="mt-4 flex flex-col items-center">
                  <img
                    src={preview}
                    alt={t.previewAlt}
                    className="max-h-80 w-auto rounded-xl border border-border bg-card object-contain shadow-xs"
                  />
                  {file?.name ? (
                    <figcaption className="mt-2 max-w-full truncate text-meta text-muted-foreground">
                      {file.name}
                    </figcaption>
                  ) : null}
                </figure>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
                  <Button
                    type="button"
                    variant="outline"
                    size="md"
                    onClick={() => cameraInput.current?.click()}
                    className="dark:bg-ink-900"
                  >
                    <CameraIcon className="h-4 w-4 shrink-0" />
                    <span className="min-w-0 truncate">{t.retakeLight}</span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="md"
                    onClick={() => galleryInput.current?.click()}
                    className="dark:bg-ink-900"
                  >
                    <ImageIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <span>{t.galleryUpload}</span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="md"
                    onClick={handleRemovePhoto}
                    disabled={isSubmitting}
                  >
                    <TrashIcon className="h-4 w-4 shrink-0" />
                    <span>{t.removePhoto}</span>
                  </Button>
                </div>
              </div>
            ) : (
              <div
                onDragOver={(event) => {
                  event.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={(event) => {
                  // Moving over the zone's own children fires dragleave too; only leave for real.
                  if (event.currentTarget.contains(event.relatedTarget as Node | null)) return;
                  setIsDragging(false);
                }}
                onDrop={(event) => {
                  event.preventDefault();
                  setIsDragging(false);
                  handleFileSelected(event.dataTransfer.files?.[0] ?? null);
                }}
                className={`swap-in rounded-2xl border-2 p-6 text-center transition-[border-color,background-color,box-shadow] duration-[var(--dur-base)] ease-[var(--ease-out-calm)] motion-reduce:transition-none sm:p-8 ${
                  isDragging
                    ? "border-solid border-sapphire bg-sapphire-soft/50 shadow-[0_0_0_4px_color-mix(in_oklab,var(--color-sapphire)_14%,transparent)] dark:border-sapphire-light dark:bg-sapphire/15"
                    : "border-dashed border-border-control bg-surface-subtle/30 dark:bg-muted/10"
                }`}
              >
                <div
                  className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl shadow-xs transition-colors duration-[var(--dur-base)] ease-[var(--ease-out-calm)] motion-reduce:transition-none ${
                    isDragging
                      ? "bg-sapphire text-white dark:bg-sapphire-border dark:text-ink-950"
                      : "bg-sapphire-soft text-sapphire dark:bg-sapphire/20 dark:text-sapphire-light"
                  }`}
                >
                  <CameraIcon className="h-7 w-7" />
                </div>

                <h2 className="mt-3.5 text-title font-semibold text-foreground text-balance">
                  {t.dropTitle}
                </h2>

                <p className="mt-1.5 text-body leading-relaxed text-muted-foreground">
                  {t.tipLine}
                </p>

                {/* Primary interactive action buttons: clearly identifiable as buttons */}
                <div className="mt-5 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <Button
                    type="button"
                    variant="action"
                    size="lg"
                    onClick={() => cameraInput.current?.click()}
                    className="min-h-13 w-full sm:w-auto sm:px-6"
                  >
                    <CameraIcon className="h-5 w-5 shrink-0" />
                    <span>{t.cameraCapture}</span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => galleryInput.current?.click()}
                    className="min-h-13 w-full dark:bg-ink-900 sm:w-auto sm:px-6"
                  >
                    <ImageIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
                    <span>{t.galleryUpload}</span>
                  </Button>
                </div>

                <p className="mt-3 hidden text-meta text-muted-foreground lg:block">
                  {t.dragOrBrowse}
                </p>
              </div>
            )}

            {!preview ? errorAlert : null}

            {/* Step 2: Revealed smoothly ONLY after a photo is selected */}
            {preview ? (
              <div
                ref={stepTwoRef}
                className="assistant-step-in space-y-6 border-t border-border pt-6"
              >
                {/* Photo quality status banner */}
                {qualityState === "warn" ? (
                  <div
                    role="status"
                    className="flex flex-col gap-3 rounded-xl border border-amber-care-border bg-amber-care-soft/60 p-4 text-left dark:border-amber-care/40 dark:bg-amber-care/15 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <p className="flex items-start gap-2.5 text-body text-foreground">
                      <AlertCircleIcon className="mt-0.5 h-4 w-4 shrink-0 text-amber-care dark:text-amber-care-border" />
                      <span>{t.qualityWarning}</span>
                    </p>
                    <button
                      type="button"
                      onClick={() => cameraInput.current?.click()}
                      className="inline-flex min-h-11 max-w-full shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-amber-care-border bg-card px-4 py-2 text-body font-semibold text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring dark:border-amber-care/50"
                    >
                      <CameraIcon className="h-4 w-4 shrink-0 text-amber-care dark:text-amber-care-border" />
                      <span className="min-w-0 truncate">{t.retakeLight}</span>
                    </button>
                  </div>
                ) : qualityState === "good" ? (
                  <p role="status" className="text-body font-semibold text-live-sage">
                    {t.photoReady}
                  </p>
                ) : null}

                {/* 1-tap visual reason chips + optional note */}
                <div>
                  <h3 className="text-title font-semibold text-foreground">
                    {t.whyLabel}
                  </h3>
                  <p
                    id="prescription-context-hint"
                    className="mt-1 text-body text-muted-foreground"
                  >
                    {t.whyHint}
                  </p>

                  <div className="mt-3.5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    {REASON_ORDER.map((reasonKey, index) => {
                      const active = selectedReasons.includes(reasonKey);
                      return (
                        <button
                          key={reasonKey}
                          type="button"
                          onClick={() => toggleReasonChip(reasonKey)}
                          aria-pressed={active}
                          style={{ "--i": index } as CSSProperties}
                          className={`list-in press-row flex min-h-11 max-w-full items-center gap-2.5 whitespace-nowrap rounded-xl border px-3.5 py-2.5 text-left text-body font-medium transition-colors duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                            active
                              ? "border-sapphire bg-sapphire-soft font-semibold text-foreground dark:border-sapphire/65 dark:bg-sapphire/20 dark:text-foreground"
                              : "border-border bg-background text-foreground hover:bg-muted"
                          }`}
                        >
                          <span
                            className={`inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-colors duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] motion-reduce:transition-none ${
                              active
                                ? "bg-sapphire text-white"
                                : "bg-surface-subtle text-sapphire dark:bg-muted dark:text-sapphire-border"
                            }`}
                          >
                            <ReasonChipIcon reason={reasonKey} />
                          </span>
                          <span className="min-w-0 flex-1 truncate leading-snug">{t.reasons[reasonKey]}</span>
                          {active ? (
                            <CheckCircleIcon className="h-4 w-4 shrink-0 text-sapphire dark:text-sapphire-border" />
                          ) : null}
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-4">
                    <label
                      className="block text-body font-medium text-muted-foreground"
                      htmlFor="prescription-context"
                    >
                      {t.noteLabel}
                    </label>
                    <textarea
                      id="prescription-context"
                      aria-describedby="prescription-context-hint"
                      rows={2}
                      maxLength={4000}
                      value={context}
                      onChange={(event) => setContext(event.target.value)}
                      placeholder={t.whyPh}
                      className="field-focus mt-1.5 w-full resize-none rounded-lg border border-border-control bg-background p-3 text-body text-foreground placeholder:text-muted-foreground"
                    />
                  </div>
                </div>

                {errorAlert}

                <div className="sticky bottom-0 z-10 -mx-5 border-t border-border bg-card/95 px-5 py-3.5 backdrop-blur-xs sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0 sm:backdrop-blur-none">
                  <Button
                    type="submit"
                    variant="action"
                    size="lg"
                    disabled={isSubmitting || !file}
                    className="min-h-13 w-full sm:w-auto sm:px-7"
                  >
                    <span className="min-w-0 truncate">{isSubmitting ? t.reviewing : t.reviewButton}</span>
                    {!isSubmitting ? <ArrowRightSvg /> : null}
                  </Button>

                  {/* Honest progress: a calm indeterminate line, no fake percentages or scanning effects. */}
                  <div role="status" aria-live="polite" className={isSubmitting ? "mt-3" : ""}>
                    {isSubmitting ? (
                      <>
                        <div className="h-1.5 w-full overflow-hidden rounded-md bg-muted sm:max-w-xs" aria-hidden="true">
                          <div className="assistant-reading-bar h-full w-2/5 rounded-md bg-sapphire dark:bg-sapphire-border" />
                        </div>
                        <p className="mt-2 text-body text-muted-foreground">{t.reviewingHint}</p>
                      </>
                    ) : null}
                  </div>
                </div>
              </div>
            ) : null}
          </form>
        </section>

        {isSubmitting && !result ? (
          <section
            aria-label={t.skeletonHeading}
            className="rounded-2xl border border-border bg-card p-5 shadow-xs print:hidden sm:p-8"
          >
            <p className="text-body font-semibold text-foreground">{t.skeletonHeading}</p>
            <div className="mt-4 space-y-3" aria-hidden="true">
              {[0, 1].map((row) => (
                <div
                  key={row}
                  style={{ "--i": row } as CSSProperties}
                  className="list-in rounded-xl border border-border bg-background p-4 sm:p-5"
                >
                  {/* Name and strength, purpose line, then the four times of day: the card that is coming. */}
                  <div className="flex items-baseline gap-2.5">
                    <div className="skeleton-sheen h-5 w-2/5" />
                    <div className="skeleton-sheen h-4 w-14" />
                  </div>
                  <div className="skeleton-sheen mt-2.5 h-3.5 w-4/5" />
                  <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                    {[0, 1, 2, 3].map((slot) => (
                      <div key={slot} className="skeleton-sheen h-16" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        {result && (
          <section
            ref={resultSectionRef}
            className="assistant-step-in rounded-2xl border border-border bg-card p-5 shadow-xs sm:p-8"
          >
            <PrescriptionStructuredResult
              aiMessage={result.message}
              prescriptionText={result.prescriptionText}
              medicines={result.medicines}
              sourceKind={result.sourceKind}
              confidenceScore={result.confidenceScore}
              confidenceReason={result.confidenceReason}
              emergency={result.urgency === "emergency" || result.careLevel === "emergency"}
            />
          </section>
        )}
          </div>

          <aside className="min-w-0 space-y-4 lg:sticky lg:top-[calc(var(--site-header-h,4rem)+1.5rem)] print:hidden">
            <div className="rounded-2xl border border-border bg-card p-5 shadow-xs sm:p-6">
              <h2 className="text-balance text-body font-semibold text-foreground">
                {assistantCopy.rx.rulesHeading}
              </h2>
              <ol className="mt-4 space-y-3">
                {safetyRules.map((rule, index) => (
                  <li key={rule} className="flex items-start gap-3">
                    <span
                      aria-hidden="true"
                      className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-sapphire-soft text-meta font-semibold text-sapphire tabular-nums dark:bg-sapphire/20 dark:text-sapphire-light"
                    >
                      {index + 1}
                    </span>
                    <span className="text-body text-muted-foreground">{rule}</span>
                  </li>
                ))}
              </ol>
              <Button
                href={withLangPrefix("/find-help?category=pharmacy", lang)}
                variant="outline"
                size="md"
                fullWidth
                className="mt-5 hover:border-sapphire hover:bg-sapphire-soft/45 dark:bg-ink-900"
              >
                <PinIcon className="h-4 w-4 shrink-0 text-sapphire" aria-hidden="true" />
                <span className="min-w-0 truncate">{helpLinks.nav}</span>
                <ArrowRightIcon className="h-4 w-4 shrink-0 text-muted-foreground transition-colors duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] group-hover:text-sapphire motion-reduce:transition-none" aria-hidden="true" />
              </Button>
            </div>

            <div className="rounded-2xl border border-border bg-surface-subtle/60 p-5 shadow-xs dark:bg-card sm:p-6">
              <div className="min-w-0">
                <h2 className="text-balance text-body font-semibold text-foreground">
                  {doctorBridge.heading}
                </h2>
                <p className="mt-1.5 text-body text-muted-foreground">
                  {doctorBridge.body}
                </p>
              </div>
              <Button
                href={withLangPrefix("/medic-online?source=prescription", lang)}
                variant="action"
                size="md"
                fullWidth
                className="mt-5"
              >
                <span className="min-w-0 truncate">{headerCopy.navMedic}</span>
                <ArrowRightIcon className="h-4 w-4 shrink-0" aria-hidden="true" />
              </Button>
            </div>
          </aside>
        </div>

        <AssistantOtherTools />
      </Container>
    </main>
  );
}
