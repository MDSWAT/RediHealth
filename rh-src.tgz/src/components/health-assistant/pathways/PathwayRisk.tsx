"use client";

import { Button } from "@/components/ui/Button";
import { CheckCircleIcon } from "@/components/ui/icons";
import { UniversalDoctorExit } from "@/components/health-assistant/UniversalDoctorExit";
import { type RiskLevel, useAssistantCopy } from "@/components/health-assistant/assistant-copy";
import {
  stepHeading,
  stepLead,
  subHeading,
} from "@/components/health-assistant/step-ui";

interface PathwayRiskProps {
  step: 2 | 3;
  answers: {
    q1?: boolean;
    q2?: boolean;
    q3?: boolean;
  };
  onAnswer: (question: "q1" | "q2" | "q3", value: boolean) => void;
  plainLanguage: boolean;
  onQuickResolve?: () => void;
}

const QUESTION_IDS = ["q1", "q2", "q3"] as const;

const LEVEL_TONE: Record<RiskLevel, { bar: string; text: string }> = {
  low: { bar: "bg-sapphire", text: "text-sapphire dark:text-sapphire-border" },
  moderate: { bar: "bg-amber-care", text: "text-amber-care" },
  // Raised risk is a warning, not an emergency: red stays reserved for 112 (the fill count shows the step).
  high: { bar: "bg-amber-care", text: "text-amber-care" },
};

export function PathwayRisk({ step, answers, onAnswer, plainLanguage, onQuickResolve }: PathwayRiskProps) {
  const { risk } = useAssistantCopy();

  const yesCount = QUESTION_IDS.filter((id) => answers[id]).length;
  const level: RiskLevel = yesCount >= 2 ? "high" : yesCount === 1 ? "moderate" : "low";
  const allAnswered = QUESTION_IDS.every((id) => answers[id] !== undefined);

  if (step === 2) {
    return (
      <div>
        <h2 className={stepHeading}>{risk.heading}</h2>
        <p className={stepLead}>{risk.lead}</p>

        <ol className="mt-6 divide-y divide-border border-t border-border">
          {QUESTION_IDS.map((id, idx) => {
            const q = risk.questions[id];
            const current = answers[id];
            const labelId = `risk-${id}-label`;
            return (
              <li key={id} className="py-5">
                <p id={labelId} className="text-body text-foreground">
                  <span className="mr-1.5 font-semibold tabular-nums text-muted-foreground">{idx + 1}.</span>
                  <span className="font-semibold">{q.title}.</span> {plainLanguage ? q.plainText : q.text}
                </p>
                <div role="group" aria-labelledby={labelId} className="mt-3 grid grid-cols-2 gap-3 sm:max-w-sm">
                  {([true, false] as const).map((value) => {
                    const selected = current === value;
                    return (
                      <button
                        key={String(value)}
                        type="button"
                        data-risk-yes={value ? "" : undefined}
                        aria-pressed={selected}
                        onClick={() => onAnswer(id, value)}
                        className={`min-h-12 whitespace-nowrap rounded-xl border px-4 text-body font-semibold transition-[background-color,border-color,color,filter] duration-[var(--dur-fast)] ease-[var(--ease-out-calm)] motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                          selected
                            ? "border-sapphire bg-sapphire text-white press-solid"
                            : "border-border-control bg-card text-foreground press-row hover:border-sapphire/60 hover:bg-sapphire-soft/30"
                        }`}
                      >
                        {value ? risk.yes : risk.no}
                      </button>
                    );
                  })}
                </div>
              </li>
            );
          })}
        </ol>

        {allAnswered && (
          <div className="mt-2 border-t border-border pt-5">
            <Button
              type="button"
              variant="action"
              size="lg"
              data-risk-submit
              onClick={onQuickResolve}
              className="w-full sm:w-auto"
            >
              {risk.submit}
            </Button>
          </div>
        )}
      </div>
    );
  }

  const tone = LEVEL_TONE[level];
  const filled = level === "low" ? 1 : level === "moderate" ? 2 : 3;

  return (
    <div>
      <h2 className={stepHeading}>{risk.resultHeading}</h2>

      <div className="mt-5">
        <p className="flex items-baseline justify-between gap-3 text-body text-muted-foreground">
          <span>{risk.levelLabel}</span>
          <span className={`text-body font-semibold ${tone.text}`}>{risk.levels[level]}</span>
        </p>
        <div className="mt-2 flex h-1.5 gap-1.5" aria-hidden="true">
          {[1, 2, 3].map((segment) => (
            <div key={segment} className={`flex-1 rounded-sm ${segment <= filled ? tone.bar : "bg-muted"}`} />
          ))}
        </div>
      </div>

      <p className="mt-5 max-w-(--measure-reading) text-body text-foreground">{risk.messages[level]}</p>

      <h3 className={`mt-6 ${subHeading}`}>{risk.nextHeading}</h3>
      <ul className="mt-3 space-y-2.5">
        {risk.nextSteps.map((item) => (
          <li key={item} className="flex items-start gap-2.5 text-body text-foreground">
            <CheckCircleIcon className="mt-1 h-4.5 w-4.5 shrink-0 text-sapphire dark:text-sapphire-border" />
            <span>{item}</span>
          </li>
        ))}
      </ul>

      <UniversalDoctorExit pathway="risk" summary={risk.summary(risk.levels[level], yesCount)} />
    </div>
  );
}
