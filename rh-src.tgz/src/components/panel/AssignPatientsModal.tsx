"use client";

import { useMemo, useState } from "react";
import {
  CheckCircleIcon,
  CloseIcon,
  SearchIcon,
  StethoscopeIcon,
  UserIcon,
} from "@/components/ui/icons";
import { useLanguage } from "@/lib/i18n/language-context";
import type { PatientItem } from "@/lib/types/patient";
import type { WorkerItem } from "@/lib/types/worker";

interface AssignPatientsModalProps {
  worker: WorkerItem;
  patients: PatientItem[];
  onClose: () => void;
  onSuccess: (updatedPatients: PatientItem[]) => void;
}

export function AssignPatientsModal({
  worker,
  patients,
  onClose,
  onSuccess,
}: AssignPatientsModalProps) {
  const { lang } = useLanguage();
  const t = {
  ru: {
      errSave: "Не удалось сохранить.",
      errUnexpected: "Не удалось сохранить. Попробуйте еще раз.",
      title: "Назначение пациентов",
      assignedCount: (count: number) => `Назначенные пациенты: ${count}`,
      success: "Сохранено.",
      search: "Поиск пациентов",
      none: "Больных не обнаружено.",
      assignedTo: "Назначено",
      otherWorker: "кто-то другой",
      assigned: "Назначено",
      unassigned: "Неназначенный",
      selectedCount: (count: number) => `Выбрано: ${count}`,
      cancel: "Отмена",
      saving: "Сохранение...",
      save: "Сохранить",
    },

    en: {
      errSave: "Could not save.",
      errUnexpected: "Could not save. Try again.",
      title: "Assign patients",
      assignedCount: (count: number) => `Assigned patients: ${count}`,
      success: "Saved.",
      search: "Search patients",
      none: "No patients found.",
      assignedTo: "Assigned to",
      otherWorker: "someone else",
      assigned: "Assigned",
      unassigned: "Unassigned",
      selectedCount: (count: number) => `Selected: ${count}`,
      cancel: "Cancel",
      saving: "Saving...",
      save: "Save",
    },
    ro: {
      errSave: "Nu s-a putut salva.",
      errUnexpected: "Nu s-a putut salva. Încearcă din nou.",
      title: "Alocă pacienți",
      assignedCount: (count: number) => `Pacienți alocați: ${count}`,
      success: "Salvat.",
      search: "Caută pacienți",
      none: "Nu am găsit pacienți.",
      assignedTo: "Alocat lui",
      otherWorker: "altcuiva",
      assigned: "Alocat",
      unassigned: "Nealocat",
      selectedCount: (count: number) => `Selectați: ${count}`,
      cancel: "Anulează",
      saving: "Se salvează...",
      save: "Salvează",
    },
    sq: {
      errSave: "Nuk u ruajt.",
      errUnexpected: "Nuk u ruajt. Provo përsëri.",
      title: "Cakto pacientë",
      assignedCount: (count: number) => `Pacientë të caktuar: ${count}`,
      success: "U ruajt.",
      search: "Kërko pacientë",
      none: "Nuk u gjet asnjë pacient.",
      assignedTo: "I caktuar te",
      otherWorker: "dikush tjetër",
      assigned: "I caktuar",
      unassigned: "Pa caktim",
      selectedCount: (count: number) => `Të zgjedhur: ${count}`,
      cancel: "Anulo",
      saving: "Duke ruajtur...",
      save: "Ruaj",
    },
    it: {
      errSave: "Impossibile salvare.",
      errUnexpected: "Impossibile salvare. Riprova.",
      title: "Assegna pazienti",
      assignedCount: (count: number) => `Pazienti assegnati: ${count}`,
      success: "Salvato.",
      search: "Cerca pazienti",
      none: "Nessun paziente trovato.",
      assignedTo: "Assegnato a",
      otherWorker: "un altro operatore",
      assigned: "Assegnato",
      unassigned: "Non assegnato",
      selectedCount: (count: number) => `Selezionati: ${count}`,
      cancel: "Annulla",
      saving: "Salvataggio...",
      save: "Salva",
    },
    hr: {
      errSave: "Spremanje nije uspjelo.",
      errUnexpected: "Spremanje nije uspjelo. Pokušaj ponovno.",
      title: "Dodijeli pacijente",
      assignedCount: (count: number) => `Dodijeljeni pacijenti: ${count}`,
      success: "Spremljeno.",
      search: "Pretraži pacijente",
      none: "Nije pronađen nijedan pacijent.",
      assignedTo: "Dodijeljeno",
      otherWorker: "drugom članu osoblja",
      assigned: "Dodijeljen",
      unassigned: "Nedodijeljen",
      selectedCount: (count: number) => `Odabrano: ${count}`,
      cancel: "Odustani",
      saving: "Spremanje...",
      save: "Spremi",
    },
    rom: {
      errSave: "Nashti arakhlo.",
      errUnexpected: "Nashti arakhlo. Zumav pale.",
      title: "De pacienturya",
      assignedCount: (count: number) => `Dine pacienturya: ${count}`,
      success: "Arakhlo.",
      search: "Rode pacienturen",
      none: "Na arakhlo paciento.",
      assignedTo: "Dindo ko",
      otherWorker: "aver manush",
      assigned: "Dindo",
      unassigned: "Bi-dindo",
      selectedCount: (count: number) => `Alosarde: ${count}`,
      cancel: "Mekh",
      saving: "Arakhel...",
      save: "Arakh",
    },
  }[lang];

  const [patientList] = useState<PatientItem[]>(patients);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [assignedIds, setAssignedIds] = useState<Set<string>>(() => {
    const set = new Set<string>();
    for (const p of patients) {
      if (p.assigned_worker_id === worker.id) {
        set.add(p.id);
      }
    }
    return set;
  });

  const filteredPatients = useMemo(() => {
    if (!searchQuery.trim()) return patientList;
    const q = searchQuery.toLowerCase();
    return patientList.filter(
      (p) =>
        p.full_name.toLowerCase().includes(q) ||
        p.email.toLowerCase().includes(q) ||
        p.phone.includes(q),
    );
  }, [patientList, searchQuery]);

  function togglePatientAssignment(patientId: string) {
    setAssignedIds((prev) => {
      const next = new Set(prev);
      if (next.has(patientId)) {
        next.delete(patientId);
      } else {
        next.add(patientId);
      }
      return next;
    });
  }

  async function handleSaveAssignments() {
    setIsSaving(true);
    setErrorMessage(null);
    setSaveSuccess(false);

    const toAssign: string[] = [];
    const toUnassign: string[] = [];

    for (const p of patientList) {
      const isCurrentlyAssigned = p.assigned_worker_id === worker.id;
      const isSelectedInModal = assignedIds.has(p.id);

      if (!isCurrentlyAssigned && isSelectedInModal) {
        toAssign.push(p.id);
      } else if (isCurrentlyAssigned && !isSelectedInModal) {
        toUnassign.push(p.id);
      }
    }

    try {
      const response = await fetch("/api/workers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: worker.id,
          assign_patient_ids: toAssign,
          unassign_patient_ids: toUnassign,
        }),
      });

      if (!response.ok) {
        const data = (await response.json()) as { error?: string };
        setErrorMessage(data.error || t.errSave);
        return;
      }

      setSaveSuccess(true);

      const updatedPatients = patientList.map((p) => {
        if (toAssign.includes(p.id)) {
          return {
            ...p,
            assigned_worker_id: worker.id,
            assigned_worker_name: worker.full_name,
          };
        }
        if (toUnassign.includes(p.id)) {
          return {
            ...p,
            assigned_worker_id: null,
            assigned_worker_name: null,
          };
        }
        return p;
      });

      onSuccess(updatedPatients);

      setTimeout(() => {
        onClose();
      }, 1000);
    } catch {
      setErrorMessage(t.errUnexpected);
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="panel-scrim fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 p-0 sm:p-4">
      <div className="app-sheet-slide-up relative w-full max-w-xl rounded-t-xl sm:rounded-xl border-t sm:border border-border bg-card p-5 sm:p-6 shadow-2xl max-h-[92dvh] sm:max-h-[90vh] flex flex-col care-panel-bottom-bar">
        {/* Mobile bottom sheet drag handle */}
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-border sm:hidden" />
        <div className="flex items-center justify-between border-b border-border pb-4">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-soft text-primary">
              <StethoscopeIcon className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-foreground sm:text-lg">
                {t.title}
              </h2>
              <p className="text-xs text-muted-foreground">
                {worker.full_name} ({worker.role}) &bull; {t.assignedCount(assignedIds.size)}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        {errorMessage ? (
          <div className="mt-4 rounded-xl bg-red-500/10 border border-red-500/20 p-3 text-xs font-medium text-red-600 dark:text-red-400">
            {errorMessage}
          </div>
        ) : null}

        {saveSuccess ? (
          <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 p-3 text-xs font-medium text-emerald-700 dark:text-emerald-400">
            <CheckCircleIcon className="h-4 w-4" />
            <span>{t.success}</span>
          </div>
        ) : null}

        <div className="mt-4 relative">
          <SearchIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search}
            className="w-full rounded-lg border border-border bg-background pl-10 pr-4 py-2 text-xs text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </div>

        <div className="mt-4 flex-1 overflow-y-auto space-y-2 border border-border rounded-xl p-3 bg-muted/20 min-h-[220px] max-h-[360px]">
          {filteredPatients.length === 0 ? (
            <div className="p-8 text-center text-xs text-muted-foreground">
              <UserIcon className="mx-auto h-6 w-6 text-muted-foreground mb-2" />
              <span>{t.none}</span>
            </div>
          ) : (
            filteredPatients.map((patient) => {
              const isChecked = assignedIds.has(patient.id);
              const isAssignedToOther =
                patient.assigned_worker_id &&
                patient.assigned_worker_id !== worker.id;

              return (
                <label
                  key={patient.id}
                  className={`flex items-center justify-between gap-3 p-3 rounded-xl border transition-colors cursor-pointer ${
                    isChecked
                      ? "bg-primary-soft/50 border-primary/40 text-foreground"
                      : "bg-card border-border hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => togglePatientAssignment(patient.id)}
                      className="rounded border-border text-primary focus:ring-ring h-4 w-4"
                    />
                    <div>
                      <p className="text-xs font-bold text-foreground">
                        {patient.full_name}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {patient.phone} &bull; {patient.email}
                      </p>
                    </div>
                  </div>

                  {isAssignedToOther ? (
                    <span className="text-[10px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                      {t.assignedTo} {patient.assigned_worker_name || t.otherWorker}
                    </span>
                  ) : isChecked ? (
                    <span className="text-[10px] font-bold text-primary bg-primary-soft border border-primary/20 px-2 py-0.5 rounded-md">
                      {t.assigned}
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground">{t.unassigned}</span>
                  )}
                </label>
              );
            })
          )}
        </div>

        <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
          <span className="text-xs font-medium text-muted-foreground">
            {t.selectedCount(assignedIds.size)}
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-border bg-card px-4 py-2 text-xs font-semibold text-foreground hover:bg-muted transition-colors"
            >
              {t.cancel}
            </button>
            <button
              type="button"
              disabled={isSaving}
              onClick={handleSaveAssignments}
              className="rounded-lg bg-primary px-5 py-2 text-xs font-bold text-white hover:bg-primary-hover disabled:bg-muted disabled:text-muted-foreground shadow-2xs transition-colors"
            >
              {isSaving ? t.saving : t.save}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
